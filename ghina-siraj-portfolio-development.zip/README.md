# Ghina Siraj — Professional Portfolio & Business Website

Production-ready, fully multilingual (English / Français / العربية) portfolio and business
website for **Ghina Siraj — Web & E-commerce Developer (Temara, Morocco)**, including a complete
secure admin dashboard, real PostgreSQL persistence and working WhatsApp integration.

Tagline: _“Turning Ideas Into Powerful Digital Experiences.”_

---

## 1. Tech stack

| Layer | Technology |
| --- | --- |
| Framework | Next.js 16 (App Router, Server Components, Server Actions) |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS v4 (custom dark design system, glass + gradient utilities) |
| Database | PostgreSQL + Drizzle ORM (`src/db/schema.ts`) |
| Auth | Node `crypto` scrypt password hashing + HMAC-signed session cookies stored in the `admin_sessions` table |
| Icons | lucide-react (+ inline SVG brand icons) |
| Images | `next/image` for static assets, DB-backed media endpoint (`/api/images/[id]`) for uploads |

## 2. Features

### Public website (`/en`, `/fr`, `/ar`)
- **Home** — hero with custom illustrated avatar, tagline, introduction, CTA buttons, animated
  visual elements, featured projects, services preview, skills preview, “why work with me”, final CTA.
- **About** — professional profile, 3 years of experience, approach, interests, highlights, client process.
- **Skills** — categorised skill cards (Frontend / Backend / Tools / Design) with proficiency bars.
- **Services** — 8 services, each with a full detail page: description, features, benefits,
  starting price (MAD), delivery time, *Get a Quote* (WhatsApp with prefilled service) and contact options.
- **Projects** — gallery with category filters, project detail pages (screenshots, technologies,
  features, URL). Seeded with the confirmed **Bella Pizza** project.
- **Pricing** — Basic / Standard / Premium packages in MAD with delivery time and revisions.
- **FAQ** — interactive accordion, fully translated and editable.
- **Contact** — validated form (name, email, phone, service, budget, message) saved to PostgreSQL,
  plus WhatsApp / email cards and professional contact info.
- **Footer** — identity, navigation, services, contact, socials, copyright, language support.

### Multilingual system
- Only `en`, `fr`, `ar`; Arabic switches the whole document to **RTL** (`dir="rtl"` + logical CSS).
- Centralised dictionaries in `src/lib/i18n/{en,fr,ar}.ts` — `fr` and `ar` are type-checked against
  the English dictionary, so a missing key fails the TypeScript build (no untranslated sections).
- Language selector in the navbar (desktop + mobile), preference persisted in the `gs_locale` cookie
  and restored by `src/proxy.ts` on the next visit.
- Admin-editable content overrides live in the `content_blocks` table per language.

### Admin dashboard (`/admin`)
Email + password sign-in (no public registration), session cookies (HttpOnly, SameSite=Lax, signed),
logout, role-based check on every server action and every page.

| Section | Capabilities |
| --- | --- |
| Overview | Totals for projects / services / messages, unread counter, recent submissions, quick actions |
| Projects | Create, edit, delete, publish/unpublish, cover image upload, technologies, per-language translations |
| Services | Create, edit, delete, prices, icon, features, benefits, delivery time, visibility |
| Pricing | Price, popular flag, enabled flag, features, delivery time, revisions (per language) |
| Content | Homepage, About, brand, SEO and contact copy in EN / FR / AR |
| FAQ | Create, edit, delete, reorder, publish, per-language questions & answers |
| Skills | Create, edit, delete, categorise, proficiency level, visibility |
| Messages | Inbox, full message view, mark read/unread, delete, reply by email or WhatsApp |
| Settings | Email, WhatsApp number, avatar, OG image, SEO keywords, site URL, socials, feature switches |

### WhatsApp integration
All buttons open `https://wa.me/212723657384` with a prefilled professional message
(general enquiry, per-service quote request, package quote, floating chat button).

### SEO & performance
Per-page titles/descriptions, Open Graph + Twitter cards, canonical + `hreflang` alternates,
`/sitemap.xml`, `/robots.txt` (admin and API disallowed), semantic HTML, accessible focus states,
`prefers-reduced-motion` support, lazy-loaded images.

## 3. Local setup

```bash
npm install
cp .env.example .env          # then fill in the values
npx drizzle-kit push          # create the tables in PostgreSQL
npm run dev                   # http://localhost:3000  → redirects to /en
```

### Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string |
| `ADMIN_EMAIL` | Admin login email (account is created on first boot) |
| `ADMIN_PASSWORD` | Admin password (hashed with scrypt, never stored in plain text) |
| `ADMIN_NAME` | Display name of the admin account |
| `AUTH_SECRET` | Random string used to sign admin session cookies |

### Database
Tables (see `src/db/schema.ts`): `admin_users`, `admin_sessions`, `media`, `projects`,
`project_translations`, `project_images`, `services`, `service_translations`, `pricing_packages`,
`pricing_translations`, `faqs`, `faq_translations`, `skills`, `content_blocks`, `site_settings`,
`contact_messages`.

`npx drizzle-kit push` applies the schema. On the first request the app also runs an idempotent seed
(`src/lib/bootstrap.ts`) that inserts the admin account and the initial multilingual content
(8 services, Bella Pizza, 3 packages, 9 FAQs, 15 skills). Uploaded images are stored in the `media`
table and served from `/api/images/[id]`, so the app works on read-only serverless filesystems.

### Admin account
1. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD` and `AUTH_SECRET` in `.env`.
2. Start the app (or restart it) — the account is created automatically if it does not exist.
3. Open `/admin`, sign in, and you are redirected to `/admin/dashboard`.
4. To change the password later, update `ADMIN_PASSWORD`, delete the row in `admin_users`
   (and its sessions) and restart — a fresh hashed account is created.

## 4. Production build

```bash
npm run build
npm run start
```

## 5. Deploying to Vercel

1. Push the repository to GitHub and import it in Vercel.
2. Add a PostgreSQL database (Vercel Postgres, Neon, Supabase…) and copy its connection string.
3. Set the environment variables: `DATABASE_URL`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`,
   `AUTH_SECRET`, and set `siteUrl` (Admin → Settings) to your production domain.
4. Run `npx drizzle-kit push` once against the production database (locally with the production
   `DATABASE_URL`, or from a one-off job).
5. Deploy. The first request seeds the default content and the admin account.

## 6. Still requires configuration

- **Final prices** — the Basic / Standard / Premium prices are clearly marked configurable examples;
  edit them in Admin → Pricing.
- **Project link & screenshots** — Bella Pizza uses editable placeholders until the client approves
  the release (Admin → Projects).
- **Social profile URLs** — placeholders pointing to the platform home pages; update in Admin → Settings.
- **Production domain** — update `siteUrl` in Admin → Settings so the sitemap/canonical URLs are correct.
- **Google Analytics (optional)** — paste a measurement ID in Admin → Settings and add the script tag
  if you want analytics enabled.
- **Email delivery** — the contact form stores messages in the database (no SMTP account is required).
  If you also want email notifications, connect an SMTP/Resend account and call it from
  `src/app/api/contact/route.ts`.
