"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BadgeDollarSign,
  FileText,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Mail,
  Settings,
  Shapes,
  Sparkles,
  FolderKanban,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { logoutAction } from "@/app/admin/actions";

const LINKS = [
  { href: "/admin/dashboard", label: "Overview", Icon: LayoutDashboard },
  { href: "/admin/projects", label: "Projects", Icon: FolderKanban },
  { href: "/admin/services", label: "Services", Icon: Shapes },
  { href: "/admin/pricing", label: "Pricing", Icon: BadgeDollarSign },
  { href: "/admin/content", label: "Content", Icon: FileText },
  { href: "/admin/faqs", label: "FAQ", Icon: LifeBuoy },
  { href: "/admin/skills", label: "Skills", Icon: Sparkles },
  { href: "/admin/messages", label: "Messages", Icon: Mail },
  { href: "/admin/settings", label: "Settings", Icon: Settings },
];

export function AdminSidebar({ admin }: { admin: { name: string; email: string; role: string } }) {
  const pathname = usePathname() || "";

  return (
    <aside className="lg:fixed lg:inset-y-0 lg:start-0 lg:z-30 lg:flex lg:w-64 lg:flex-col lg:border-e lg:border-slate-800 lg:bg-slate-900/70 lg:backdrop-blur">
      <div className="flex items-center gap-3 border-b border-slate-800 px-5 py-5">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 text-sm font-semibold text-white">
          GS
        </span>
        <div className="leading-tight">
          <p className="text-sm font-semibold text-white">{admin.name}</p>
          <p className="text-[11px] uppercase tracking-widest text-slate-500">{admin.role}</p>
        </div>
      </div>

      <nav className="hide-scrollbar flex gap-1 overflow-x-auto px-3 py-3 lg:flex-1 lg:flex-col lg:overflow-y-auto">
        {LINKS.map(({ href, label, Icon }) => {
          const active = pathname === href || pathname.startsWith(`${href}/`);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "inline-flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm transition",
                active
                  ? "bg-blue-600/15 text-white ring-1 ring-inset ring-blue-500/40"
                  : "text-slate-400 hover:bg-slate-800/60 hover:text-white",
              )}
            >
              <Icon className="h-4 w-4" aria-hidden />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="flex flex-col gap-2 border-t border-slate-800 px-3 py-4">
        <Link
          href="/en"
          className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-400 transition hover:bg-slate-800/60 hover:text-white"
        >
          <Sparkles className="h-4 w-4" aria-hidden />
          View public site
        </Link>
        <form action={logoutAction}>
          <button
            type="submit"
            className="inline-flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-red-300 transition hover:bg-red-500/10"
          >
            <LogOut className="h-4 w-4" aria-hidden />
            Sign out
          </button>
        </form>
      </div>
    </aside>
  );
}
