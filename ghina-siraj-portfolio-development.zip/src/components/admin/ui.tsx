import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export const adminInput =
  "h-10 w-full rounded-lg border border-slate-700 bg-slate-900/70 px-3 text-sm text-white placeholder:text-slate-500 transition focus:border-sky-500 focus:outline-none";

export const adminTextarea =
  "w-full rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-white placeholder:text-slate-500 transition focus:border-sky-500 focus:outline-none";

export function AdminCard({
  title,
  description,
  children,
  actions,
  className,
}: {
  title?: string;
  description?: string;
  children: ReactNode;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-2xl border border-slate-800 bg-slate-900/50 p-6 shadow-[0_20px_60px_-40px_rgba(2,6,23,0.9)]",
        className,
      )}
    >
      {title || actions ? (
        <header className="mb-5 flex flex-wrap items-start justify-between gap-3">
          <div>
            {title ? <h2 className="text-base font-semibold text-white">{title}</h2> : null}
            {description ? <p className="mt-1 text-sm text-slate-400">{description}</p> : null}
          </div>
          {actions}
        </header>
      ) : null}
      {children}
    </section>
  );
}

export function Field({
  label,
  htmlFor,
  hint,
  children,
  className,
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="text-xs font-medium uppercase tracking-wider text-slate-400">
        {label}
      </label>
      {children}
      {hint ? <p className="text-xs text-slate-500">{hint}</p> : null}
    </div>
  );
}

export function Toggle({
  name,
  label,
  defaultChecked,
}: {
  name: string;
  label: string;
  defaultChecked?: boolean;
}) {
  return (
    <label className="inline-flex cursor-pointer select-none items-center gap-2.5 rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-slate-200">
      <input
        type="checkbox"
        name={name}
        defaultChecked={defaultChecked}
        className="h-4 w-4 rounded border-slate-600 bg-slate-800 accent-sky-500"
      />
      {label}
    </label>
  );
}

export function AdminButton({
  children,
  variant = "primary",
  ...rest
}: React.ComponentProps<"button"> & { variant?: "primary" | "secondary" | "danger" }) {
  const styles = {
    primary:
      "bg-gradient-to-r from-blue-600 to-sky-500 text-white hover:brightness-110 shadow-[0_12px_30px_-16px_rgba(37,99,235,0.9)]",
    secondary: "border border-slate-700 bg-slate-900 text-slate-200 hover:border-sky-500/60",
    danger: "border border-red-500/40 bg-red-500/10 text-red-200 hover:bg-red-500/20",
  } as const;
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition disabled:opacity-60",
        styles[variant],
        rest.className,
      )}
    >
      {children}
    </button>
  );
}

export function AdminLink({
  children,
  href,
  variant = "secondary",
  ...rest
}: React.ComponentProps<"a"> & { variant?: "primary" | "secondary" | "danger" }) {
  const styles = {
    primary: "bg-blue-600 text-white hover:bg-blue-500",
    secondary: "border border-slate-700 bg-slate-900 text-slate-200 hover:border-sky-500/60",
    danger: "border border-red-500/40 bg-red-500/10 text-red-200 hover:bg-red-500/20",
  } as const;
  return (
    <a
      {...rest}
      href={href}
      className={cn(
        "inline-flex h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition",
        styles[variant],
        rest.className,
      )}
    >
      {children}
    </a>
  );
}

export function Alert({
  tone = "info",
  children,
}: {
  tone?: "info" | "success" | "error";
  children: ReactNode;
}) {
  const tones = {
    info: "border-sky-500/30 bg-sky-500/10 text-sky-100",
    success: "border-emerald-500/30 bg-emerald-500/10 text-emerald-100",
    error: "border-red-500/30 bg-red-500/10 text-red-100",
  } as const;
  return (
    <div className={cn("rounded-xl border px-4 py-3 text-sm", tones[tone])} role="status">
      {children}
    </div>
  );
}

export function LocaleBadge({ locale }: { locale: string }) {
  return (
    <span className="rounded-md border border-slate-700 bg-slate-800/70 px-2 py-0.5 text-[10px] uppercase tracking-widest text-slate-300">
      {locale}
    </span>
  );
}
