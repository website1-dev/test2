"use client";

import { useState, type ReactNode } from "react";
import { ImagePlus, Link2, Loader2 } from "lucide-react";
import { cn } from "@/lib/cn";
import { adminInput } from "@/components/admin/ui";

const LOCALE_TABS: { locale: "en" | "fr" | "ar"; label: string }[] = [
  { locale: "en", label: "English" },
  { locale: "fr", label: "Français" },
  { locale: "ar", label: "العربية" },
];

/**
 * Renders every locale panel in the DOM (so all values submit together) and
 * toggles their visibility client-side.
 */
export function LocaleTabs({
  panels,
}: {
  panels: { locale: "en" | "fr" | "ar"; node: ReactNode }[];
}) {
  const [active, setActive] = useState<"en" | "fr" | "ar">("en");
  const ordered = LOCALE_TABS.map((tab) => {
    const found = panels.find((panel) => panel.locale === tab.locale);
    return found ? { ...tab, node: found.node } : null;
  }).filter((item): item is { locale: "en" | "fr" | "ar"; label: string; node: ReactNode } => !!item);

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
      <div className="mb-4 flex flex-wrap gap-1 rounded-lg border border-slate-800 bg-slate-900/70 p-1">
        {ordered.map((tab) => (
          <button
            key={tab.locale}
            type="button"
            onClick={() => setActive(tab.locale)}
            className={cn(
              "rounded-md px-3 py-1.5 text-sm transition",
              active === tab.locale
                ? "bg-blue-600 text-white"
                : "text-slate-400 hover:text-white",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>
      {ordered.map((tab) => (
        <div key={tab.locale} hidden={active !== tab.locale} dir={tab.locale === "ar" ? "rtl" : "ltr"}>
          {tab.node}
        </div>
      ))}
    </div>
  );
}

export function ImageField({
  name,
  defaultValue,
  label = "Image",
  hint,
}: {
  name: string;
  defaultValue?: string;
  label?: string;
  hint?: string;
}) {
  const [value, setValue] = useState(defaultValue ?? "");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  async function upload(file: File) {
    setUploading(true);
    setError("");
    try {
      const body = new FormData();
      body.append("file", file);
      const response = await fetch("/api/upload", { method: "POST", body });
      const payload = (await response.json()) as { ok?: boolean; url?: string; error?: string };
      if (!response.ok || !payload.ok || !payload.url) {
        setError(payload.error ?? "Upload failed");
        return;
      }
      setValue(payload.url);
    } catch {
      setError("Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <span className="text-xs font-medium uppercase tracking-wider text-slate-400">{label}</span>
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="text"
          name={name}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder="/images/example.jpg or https://…"
          className={cn(adminInput, "flex-1 min-w-[220px]")}
        />
        <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3 text-sm text-slate-200 transition hover:border-sky-500/60">
          {uploading ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
          ) : (
            <ImagePlus className="h-4 w-4" aria-hidden />
          )}
          Upload
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void upload(file);
            }}
          />
        </label>
      </div>
      {value ? (
        <span className="flex items-center gap-2 text-xs text-slate-500">
          <Link2 className="h-3.5 w-3.5" aria-hidden />
          {value}
        </span>
      ) : null}
      {hint ? <p className="text-xs text-slate-500">{hint}</p> : null}
      {error ? <p className="text-xs text-red-300">{error}</p> : null}
    </div>
  );
}
