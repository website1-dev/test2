import {
  Building2,
  Code2,
  Globe,
  LayoutDashboard,
  Palette,
  RefreshCw,
  Rocket,
  Shirt,
  ShoppingBag,
  Sparkles,
  UtensilsCrossed,
  Wrench,
  type LucideIcon,
} from "lucide-react";

const icons: Record<string, LucideIcon> = {
  Building2,
  ShoppingBag,
  UtensilsCrossed,
  Shirt,
  Rocket,
  RefreshCw,
  LayoutDashboard,
  Wrench,
  Globe,
  Code2,
  Palette,
  Sparkles,
};

export function ServiceIcon({ name, className }: { name: string; className?: string }) {
  const Icon = icons[name] ?? Sparkles;
  return <Icon className={className ?? "h-6 w-6"} aria-hidden />;
}

export const ICON_OPTIONS = Object.keys(icons);
