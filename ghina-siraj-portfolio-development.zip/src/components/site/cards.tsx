import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Check, Clock, ExternalLink, RefreshCw, Sparkles, Star } from "lucide-react";
import { Card, buttonClass } from "@/components/ui/kit";
import { ServiceIcon } from "@/components/site/service-icon";
import { cn } from "@/lib/cn";
import { categoryLabel, type PackageView, type ProjectView, type ServiceView } from "@/lib/data";
import type { Dictionary, Locale } from "@/lib/i18n";
import { formatPrice } from "@/lib/settings";

export function ServiceCard({
  locale,
  dict,
  service,
}: {
  locale: Locale;
  dict: Dictionary;
  service: ServiceView;
}) {
  return (
    <Card className="flex h-full flex-col gap-4">
      <span className="grid h-12 w-12 place-items-center rounded-xl border border-accent/20 bg-accent/10 text-accent">
        <ServiceIcon name={service.icon} className="h-6 w-6" />
      </span>
      <h3 className="text-lg font-semibold text-white">{service.title}</h3>
      <p className="flex-1 text-sm leading-relaxed text-muted">{service.summary}</p>
      <div className="flex items-center justify-between gap-3 border-t border-white/8 pt-4">
        <span className="flex flex-col">
          <span className="text-[11px] uppercase tracking-widest text-muted">
            {dict.common.startingAt}
          </span>
          <span className="text-sm font-semibold text-accent">
            {formatPrice(service.startingPrice, service.currency)}
          </span>
        </span>
        <Link
          href={`/${locale}/services/${service.slug}`}
          className={buttonClass("secondary", "sm")}
          aria-label={`${dict.common.learnMore}: ${service.title}`}
        >
          {dict.common.learnMore}
          <ArrowRight className="h-4 w-4 flip-x" aria-hidden />
        </Link>
      </div>
    </Card>
  );
}

export function ProjectCard({
  locale,
  dict,
  project,
}: {
  locale: Locale;
  dict: Dictionary;
  project: ProjectView;
}) {
  return (
    <Card className="flex h-full flex-col overflow-hidden p-0">
      <Link
        href={`/${locale}/projects/${project.slug}`}
        className="relative block aspect-[16/10] w-full overflow-hidden bg-surface-2"
      >
        {project.coverImageUrl ? (
          <Image
            src={project.coverImageUrl}
            alt={`${project.title} — ${categoryLabel(dict, project.category)}`}
            fill
            sizes="(max-width: 768px) 100vw, 33vw"
            className="object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <span className="grid h-full w-full place-items-center text-muted">
            <Sparkles className="h-10 w-10" aria-hidden />
          </span>
        )}
        <span className="absolute start-3 top-3 rounded-full border border-white/15 bg-base/80 px-3 py-1 text-[11px] font-medium text-white backdrop-blur">
          {categoryLabel(dict, project.category)}
        </span>
      </Link>
      <div className="flex flex-1 flex-col gap-3 p-6">
        <h3 className="text-lg font-semibold text-white">{project.title}</h3>
        <p className="flex-1 text-sm leading-relaxed text-muted">{project.summary}</p>
        <ul className="flex flex-wrap gap-1.5">
          {project.technologies.slice(0, 4).map((tech) => (
            <li
              key={tech}
              className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[11px] text-muted"
            >
              {tech}
            </li>
          ))}
        </ul>
        <Link
          href={`/${locale}/projects/${project.slug}`}
          className={buttonClass("secondary", "sm", "mt-1 w-fit")}
        >
          {dict.projects.visitLabel}
          <ArrowRight className="h-4 w-4 flip-x" aria-hidden />
        </Link>
      </div>
    </Card>
  );
}

export function PackageCard({
  dict,
  pack,
  whatsappHref,
  contactHref,
}: {
  dict: Dictionary;
  pack: PackageView;
  whatsappHref: string;
  contactHref: string;
}) {
  return (
    <div
      className={cn(
        "relative flex h-full flex-col gap-5 rounded-2xl border p-7 transition-all duration-500 hover:-translate-y-1",
        pack.popular
          ? "border-accent/40 bg-gradient-to-b from-brand/20 via-surface-2/70 to-surface/95 shadow-[0_35px_80px_-45px_rgba(56,189,248,0.85)]"
          : "border-white/10 bg-gradient-to-b from-surface-2/70 to-surface/90 hover:border-accent/30",
      )}
    >
      {pack.popular ? (
        <span className="absolute -top-3 start-7 inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-accent px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
          <Star className="h-3 w-3" aria-hidden />
          {dict.pricing.mostPopular}
        </span>
      ) : null}
      <div className="flex flex-col gap-2">
        <h3 className="text-xl font-semibold text-white">{pack.name}</h3>
        <p className="text-sm leading-relaxed text-muted">{pack.description}</p>
      </div>
      <div className="flex items-end gap-2">
        <span className="text-4xl font-semibold tracking-tight text-white">
          {formatPrice(pack.price, pack.currency)}
        </span>
        <span className="pb-1.5 text-xs text-muted">{dict.pricing.perProject}</span>
      </div>
      <div className="grid gap-2 text-sm">
        <span className="flex items-center gap-2 text-muted">
          <Clock className="h-4 w-4 text-accent" aria-hidden />
          <span className="text-white/90">{dict.pricing.deliveryLabel}:</span> {pack.deliveryTime}
        </span>
        <span className="flex items-center gap-2 text-muted">
          <RefreshCw className="h-4 w-4 text-accent" aria-hidden />
          <span className="text-white/90">{dict.pricing.revisionsLabel}:</span> {pack.revisions}
        </span>
      </div>
      <ul className="flex flex-col gap-2.5 border-t border-white/8 pt-5">
        {pack.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2.5 text-sm text-muted">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      <div className="mt-auto flex flex-col gap-2">
        <a
          href={whatsappHref}
          target="_blank"
          rel="noopener noreferrer"
          className={buttonClass("primary", "md")}
        >
          {dict.pricing.chooseCta}
        </a>
        <Link href={contactHref} className={buttonClass("secondary", "sm")}>
          {dict.common.contactMe}
        </Link>
      </div>
    </div>
  );
}

export function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-center">
      <p className="text-3xl font-semibold gradient-text">{value}</p>
      <p className="mt-1 text-xs uppercase tracking-widest text-muted">{label}</p>
    </div>
  );
}

export function ExternalLinkBadge({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={buttonClass("secondary", "sm")}
    >
      {label}
      <ExternalLink className="h-4 w-4" aria-hidden />
    </a>
  );
}
