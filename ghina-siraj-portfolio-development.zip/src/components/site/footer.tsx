import Link from "next/link";
import { ArrowUp, Mail, MapPin, MessageCircle } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";
import type { SiteSettings } from "@/lib/settings";
import { whatsappLink } from "@/lib/settings";
import { GithubIcon, InstagramIcon, LinkedinIcon, XIcon } from "@/components/ui/brand-icons";

export function Footer({
  locale,
  dict,
  settings,
  services,
}: {
  locale: Locale;
  dict: Dictionary;
  settings: SiteSettings;
  services: { slug: string; title: string }[];
}) {
  const year = new Date().getFullYear();
  const nav = [
    { href: `/${locale}`, label: dict.nav.home },
    { href: `/${locale}/about`, label: dict.nav.about },
    { href: `/${locale}/skills`, label: dict.nav.skills },
    { href: `/${locale}/projects`, label: dict.nav.projects },
    { href: `/${locale}/pricing`, label: dict.nav.pricing },
    { href: `/${locale}/contact`, label: dict.nav.contact },
  ];
  const socials = [
    { href: settings.socialGithub, label: "GitHub", Icon: GithubIcon },
    { href: settings.socialLinkedin, label: "LinkedIn", Icon: LinkedinIcon },
    { href: settings.socialInstagram, label: "Instagram", Icon: InstagramIcon },
    { href: settings.socialX, label: "X", Icon: XIcon },
  ].filter((item) => item.href);

  return (
    <footer className="relative mt-24 border-t border-white/8 bg-base-soft/80">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/40 to-transparent" />
      <div className="container-page grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div className="flex flex-col gap-4">
          <Link href={`/${locale}`} className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand to-accent text-sm font-semibold">
              GS
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-sm font-semibold text-white">{dict.home.name}</span>
              <span className="text-[11px] text-muted">{dict.home.badge.split("·")[0]}</span>
            </span>
          </Link>
          <p className="text-sm leading-relaxed text-muted">{dict.footer.about}</p>
          <div className="flex items-center gap-2">
            {socials.map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 bg-white/[0.03] text-muted transition hover:border-accent/40 hover:text-white"
              >
                <Icon className="h-4 w-4" aria-hidden />
              </a>
            ))}
          </div>
        </div>

        <nav aria-label={dict.footer.navigation} className="flex flex-col gap-3">
          <h3 className="text-sm font-semibold uppercase tracking-widest text-white/80">
            {dict.footer.navigation}
          </h3>
          <ul className="flex flex-col gap-2">
            {nav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-sm text-muted transition hover:text-white">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-semibold uppercase tracking-widest text-white/80">
            {dict.footer.servicesTitle}
          </h3>
          <ul className="flex flex-col gap-2">
            {services.slice(0, 6).map((service) => (
              <li key={service.slug}>
                <Link
                  href={`/${locale}/services/${service.slug}`}
                  className="text-sm text-muted transition hover:text-white"
                >
                  {service.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-semibold uppercase tracking-widest text-white/80">
            {dict.footer.contactTitle}
          </h3>
          <ul className="flex flex-col gap-3 text-sm text-muted">
            <li>
              <a
                className="flex items-center gap-2 transition hover:text-white"
                href={`mailto:${settings.contactEmail}`}
              >
                <Mail className="h-4 w-4 text-accent" aria-hidden />
                {settings.contactEmail}
              </a>
            </li>
            <li>
              <a
                className="flex items-center gap-2 transition hover:text-white"
                href={whatsappLink(settings.whatsappNumber, dict.contact.whatsappPrefill)}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="h-4 w-4 text-accent" aria-hidden />
                {settings.whatsappNumber}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-accent" aria-hidden />
              {settings.locationLabel}
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/8">
        <div className="container-page flex flex-col items-center justify-between gap-3 py-6 text-xs text-muted sm:flex-row">
          <p>
            © {year} {dict.home.name}. {dict.footer.rights}
          </p>
          <p className="text-center">{dict.footer.builtWith}</p>
          <a
            href="#top"
            className="inline-flex items-center gap-1.5 transition hover:text-white"
          >
            {dict.footer.backToTop}
            <ArrowUp className="h-3.5 w-3.5" aria-hidden />
          </a>
        </div>
      </div>
    </footer>
  );
}

export function WhatsAppFloat({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="group fixed bottom-6 end-6 z-40 flex items-center gap-3 rounded-full bg-[#1faa53] px-4 py-3 text-sm font-medium text-white shadow-[0_20px_45px_-20px_rgba(31,170,83,0.9)] transition hover:-translate-y-0.5"
    >
      <span className="relative grid h-6 w-6 place-items-center">
        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-white/40" aria-hidden />
        <MessageCircle className="relative h-5 w-5" aria-hidden />
      </span>
      <span className="hidden max-w-0 overflow-hidden whitespace-nowrap transition-all duration-500 group-hover:max-w-[12rem] sm:inline">
        {label}
      </span>
    </a>
  );
}
