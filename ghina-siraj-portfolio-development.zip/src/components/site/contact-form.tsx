"use client";

import { useState } from "react";
import { AlertTriangle, CheckCircle2, Loader2, Send } from "lucide-react";
import { Button, buttonClass } from "@/components/ui/kit";
import { cn } from "@/lib/cn";
import type { Dictionary } from "@/lib/i18n";

type Status = "idle" | "loading" | "success" | "error";

export type ContactFormDict = {
  formTitle: string;
  name: string;
  namePlaceholder: string;
  email: string;
  emailPlaceholder: string;
  phone: string;
  phonePlaceholder: string;
  service: string;
  servicePlaceholder: string;
  budget: string;
  budgetPlaceholder: string;
  message: string;
  messagePlaceholder: string;
  submit: string;
  sending: string;
  successTitle: string;
  successText: string;
  errorTitle: string;
  errorText: string;
  validationName: string;
  validationEmail: string;
  validationMessage: string;
  validationService: string;
};

export function ContactForm({
  dict,
  services,
  locale,
}: {
  dict: ContactFormDict;
  services: { slug: string; title: string }[];
  locale: string;
}) {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string>("");
  const [selectedService, setSelectedService] = useState<string>("");

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);

    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const body = String(data.get("message") ?? "").trim();

    if (name.length < 2) return fail(dict.validationName);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return fail(dict.validationEmail);
    if (body.length < 10) return fail(dict.validationMessage);
    if (!selectedService) return fail(dict.validationService);

    setStatus("loading");
    setMessage("");
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          phone: String(data.get("phone") ?? "").trim(),
          service: selectedService,
          budget: String(data.get("budget") ?? "").trim(),
          message: body,
          locale,
        }),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        setStatus("error");
        setMessage(
          payload.error === "RATE_LIMITED" ? "" : dict.errorText,
        );
        return;
      }
      setStatus("success");
      form.reset();
      setSelectedService("");
    } catch {
      setStatus("error");
      setMessage(dict.errorText);
    }
  }

  function fail(text: string) {
    setStatus("error");
    setMessage(text);
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="flex flex-col gap-5 rounded-2xl border border-white/10 bg-gradient-to-b from-surface-2/70 to-surface/90 p-6 sm:p-8"
    >
      <h2 className="text-xl font-semibold text-white">{dict.formTitle}</h2>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={dict.name} htmlFor="name">
          <input
            id="name"
            name="name"
            type="text"
            required
            autoComplete="name"
            placeholder={dict.namePlaceholder}
            className={inputClass}
          />
        </Field>
        <Field label={dict.email} htmlFor="email">
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="email"
            placeholder={dict.emailPlaceholder}
            className={inputClass}
          />
        </Field>
        <Field label={dict.phone} htmlFor="phone">
          <input
            id="phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            placeholder={dict.phonePlaceholder}
            className={inputClass}
          />
        </Field>
        <Field label={dict.service} htmlFor="service">
          <select
            id="service"
            name="service"
            required
            value={selectedService}
            onChange={(event) => setSelectedService(event.target.value)}
            className={cn(inputClass, "appearance-none")}
          >
            <option value="">{dict.servicePlaceholder}</option>
            {services.map((service) => (
              <option key={service.slug} value={service.slug}>
                {service.title}
              </option>
            ))}
          </select>
        </Field>
        <Field label={dict.budget} htmlFor="budget" className="sm:col-span-2">
          <input
            id="budget"
            name="budget"
            type="text"
            placeholder={dict.budgetPlaceholder}
            className={inputClass}
          />
        </Field>
        <Field label={dict.message} htmlFor="message" className="sm:col-span-2">
          <textarea id="message" name="message" required rows={5} placeholder={dict.messagePlaceholder} className={cn(inputClass, "resize-y")} />
        </Field>
      </div>

      {status === "success" ? (
        <Notification tone="success" title={dict.successTitle} text={dict.successText} />
      ) : null}
      {status === "error" ? (
        <Notification
          tone="error"
          title={dict.errorTitle}
          text={message || dict.errorText}
        />
      ) : null}

      <Button type="submit" size="lg" disabled={status === "loading"} className="w-full sm:w-fit">
        {status === "loading" ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            {dict.sending}
          </>
        ) : (
          <>
            <Send className="h-4 w-4" aria-hidden />
            {dict.submit}
          </>
        )}
      </Button>
      <p className="text-xs text-muted">
        <AlertTriangle className="me-1 inline h-3.5 w-3.5" aria-hidden />
        {dict.errorText}
      </p>
    </form>
  );
}

const inputClass =
  "h-11 w-full rounded-xl border border-white/12 bg-white/[0.03] px-4 text-sm text-white placeholder:text-muted/70 transition focus:border-accent/60 focus:bg-white/[0.06] focus:outline-none";

function Field({
  label,
  htmlFor,
  children,
  className,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <label htmlFor={htmlFor} className="text-sm font-medium text-white/90">
        {label}
      </label>
      {children}
    </div>
  );
}

function Notification({
  tone,
  title,
  text,
}: {
  tone: "success" | "error";
  title: string;
  text: string;
}) {
  return (
    <div
      role="status"
      className={cn(
        "flex items-start gap-3 rounded-xl border p-4 text-sm",
        tone === "success"
          ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-100"
          : "border-red-400/30 bg-red-400/10 text-red-100",
      )}
    >
      {tone === "success" ? (
        <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
      ) : (
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
      )}
      <span>
        <strong className="block font-semibold">{title}</strong>
        {text}
      </span>
    </div>
  );
}

export { buttonClass };
