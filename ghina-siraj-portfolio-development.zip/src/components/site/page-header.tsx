import { Pill } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden pt-36 pb-14">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-[radial-gradient(60%_100%_at_50%_0%,rgba(37,99,235,0.28),transparent_70%)]"
        aria-hidden
      />
      <div className="container-page relative flex flex-col items-center gap-5 text-center">
        <Reveal>
          {eyebrow ? <Pill>{eyebrow}</Pill> : null}
        </Reveal>
        <Reveal delay={80}>
          <h1 className="max-w-4xl text-4xl font-semibold leading-[1.1] tracking-tight text-white sm:text-5xl">
            {title}
          </h1>
        </Reveal>
        {subtitle ? (
          <Reveal delay={140}>
            <p className="max-w-2xl text-base leading-relaxed text-muted sm:text-lg">{subtitle}</p>
          </Reveal>
        ) : null}
        {children ? <Reveal delay={200}>{children}</Reveal> : null}
      </div>
    </section>
  );
}
