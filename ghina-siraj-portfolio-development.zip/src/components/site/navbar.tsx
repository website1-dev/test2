"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ChevronDown, Globe, Menu, X } from "lucide-react";
import { cn } from "@/lib/cn";
import { localeLabels, locales, LOCALE_COOKIE, type Locale } from "@/lib/i18n/config";

export type NavLabels = {
  home: string;
  about: string;
  skills: string;
  services: string;
  projects: string;
  pricing: string;
  faq: string;
  contact: string;
  openMenu: string;
  closeMenu: string;
  language: string;
  switchLanguage: string;
};

export function LanguageSwitcher({
  locale,
  label,
  ariaLabel,
  compact,
}: {
  locale: Locale;
  label: string;
  ariaLabel: string;
  compact?: boolean;
}) {
  const pathname = usePathname() || `/${locale}`;
  const [open, setOpen] = useState(false);

  function switchTo(next: Locale) {
    const segments = pathname.split("/");
    segments[1] = next;
    document.cookie = `${LOCALE_COOKIE}=${next}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
    setOpen(false);
    window.location.assign(segments.join("/") || `/${next}`);
  }

  return (
    <div className="relative" onMouseLeave={() => setOpen(false)}>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label={ariaLabel}
        aria-expanded={open}
        className={cn(
          "inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.04] text-sm font-medium text-white/90 transition hover:border-accent/45 hover:text-white",
          compact ? "h-10 px-3" : "h-10 px-4",
        )}
      >
        <Globe className="h-4 w-4 text-accent" aria-hidden />
        <span>{localeLabels[locale]}</span>
        <ChevronDown
          className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")}
          aria-hidden
        />
      </button>
      <span className="sr-only">{label}</span>
      {open ? (
        <div
          className="absolute end-0 z-50 mt-2 w-44 overflow-hidden rounded-xl border border-white/10 bg-surface/95 p-1 shadow-2xl backdrop-blur-xl"
          role="menu"
        >
          {locales.map((item) => (
            <button
              key={item}
              type="button"
              role="menuitem"
              lang={item}
              dir={item === "ar" ? "rtl" : "ltr"}
              onClick={() => switchTo(item)}
              className={cn(
                "flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-sm transition",
                item === locale
                  ? "bg-brand/20 text-white"
                  : "text-muted hover:bg-white/5 hover:text-white",
              )}
            >
              <span>{localeLabels[item]}</span>
              <span className="text-[10px] uppercase tracking-widest text-muted">{item}</span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function Navbar({
  locale,
  labels,
  whatsappHref,
  whatsappLabel,
}: {
  locale: Locale;
  labels: NavLabels;
  whatsappHref: string;
  whatsappLabel: string;
}) {
  const pathname = usePathname() || `/${locale}`;
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const links = [
    { href: `/${locale}`, label: labels.home },
    { href: `/${locale}/about`, label: labels.about },
    { href: `/${locale}/skills`, label: labels.skills },
    { href: `/${locale}/services`, label: labels.services },
    { href: `/${locale}/projects`, label: labels.projects },
    { href: `/${locale}/pricing`, label: labels.pricing },
    { href: `/${locale}/faq`, label: labels.faq },
  ];

  const isActive = (href: string) =>
    href === `/${locale}` ? pathname === href : pathname.startsWith(href);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "border-b border-white/8 bg-base/85 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <nav className="container-page flex h-18 items-center justify-between gap-4 py-4">
        <Link href={`/${locale}`} className="group flex items-center gap-3">
          <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand to-accent text-sm font-semibold text-white shadow-[0_10px_30px_-12px_rgba(56,189,248,0.8)]">
            GS
          </span>
          <span className="hidden flex-col leading-tight sm:flex">
            <span className="text-sm font-semibold text-white">Ghina Siraj</span>
            <span className="text-[11px] text-muted">Web &amp; E-commerce Developer</span>
          </span>
        </Link>

        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                aria-current={isActive(link.href) ? "page" : undefined}
                className={cn(
                  "relative rounded-full px-3.5 py-2 text-sm transition-colors",
                  isActive(link.href)
                    ? "text-white"
                    : "text-muted hover:text-white",
                )}
              >
                {isActive(link.href) ? (
                  <span className="absolute inset-0 -z-10 rounded-full border border-accent/25 bg-accent/10" />
                ) : null}
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <LanguageSwitcher
            locale={locale}
            label={labels.language}
            ariaLabel={labels.switchLanguage}
            compact
          />
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden h-10 items-center rounded-full bg-gradient-to-r from-brand to-accent px-5 text-sm font-medium text-white shadow-[0_14px_30px_-14px_rgba(37,99,235,0.9)] transition hover:-translate-y-0.5 md:inline-flex"
          >
            {whatsappLabel}
          </a>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-label={open ? labels.closeMenu : labels.openMenu}
            aria-expanded={open}
            className="grid h-10 w-10 place-items-center rounded-full border border-white/12 bg-white/[0.04] text-white lg:hidden"
          >
            {open ? <X className="h-5 w-5" aria-hidden /> : <Menu className="h-5 w-5" aria-hidden />}
          </button>
        </div>
      </nav>

      {open ? (
        <div className="border-t border-white/8 bg-base/95 backdrop-blur-xl lg:hidden">
          <div className="container-page flex flex-col gap-1 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "rounded-xl px-4 py-3 text-sm transition",
                  isActive(link.href)
                    ? "bg-accent/10 text-white"
                    : "text-muted hover:bg-white/5 hover:text-white",
                )}
              >
                {link.label}
              </Link>
            ))}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 rounded-xl bg-gradient-to-r from-brand to-accent px-4 py-3 text-center text-sm font-medium text-white"
            >
              {labels.contact}
            </a>
          </div>
        </div>
      ) : null}
    </header>
  );
}
