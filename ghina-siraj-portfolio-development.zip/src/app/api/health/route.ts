import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  let database = "unknown";
  try {
    await db.execute(sql`select 1`);
    database = "ok";
  } catch (error) {
    console.error("[health] database check failed:", error);
    database = "error";
  }
  return NextResponse.json({
    status: database === "ok" ? "ok" : "degraded",
    database,
    timestamp: new Date().toISOString(),
  });
}
