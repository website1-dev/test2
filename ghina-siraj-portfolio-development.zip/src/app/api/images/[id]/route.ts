import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const numericId = Number.parseInt(id, 10);
  if (!Number.isFinite(numericId)) {
    return new Response("Not found", { status: 404 });
  }
  try {
    const rows = await db.select().from(media).where(eq(media.id, numericId)).limit(1);
    const record = rows[0];
    if (!record) return new Response("Not found", { status: 404 });
    const body = new Uint8Array(record.data);
    return new Response(body, {
      status: 200,
      headers: {
        "Content-Type": record.mimeType,
        "Content-Length": String(record.data.byteLength ?? body.byteLength),
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch {
    return new Response("Server error", { status: 500 });
  }
}
