import { NextResponse } from "next/server";
import { and, desc, eq, gt } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { ensureSeeded } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

const schema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(180),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  service: z.string().trim().min(1).max(120),
  budget: z.string().trim().max(80).optional().or(z.literal("")),
  message: z.string().trim().min(10).max(4000),
  locale: z.enum(["en", "fr", "ar"]).default("en"),
});

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const json = await request.json().catch(() => null);
    const parsed = schema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION_ERROR", issues: parsed.error.flatten().fieldErrors },
        { status: 422 },
      );
    }
    const data = parsed.data;

    const recent = await db
      .select({ id: contactMessages.id, submittedAt: contactMessages.submittedAt })
      .from(contactMessages)
      .where(
        and(
          eq(contactMessages.email, data.email.toLowerCase()),
          gt(contactMessages.submittedAt, new Date(Date.now() - 45_000)),
        ),
      )
      .orderBy(desc(contactMessages.submittedAt))
      .limit(1);

    if (recent[0]) {
      return NextResponse.json({ ok: false, error: "RATE_LIMITED" }, { status: 429 });
    }

    const inserted = await db
      .insert(contactMessages)
      .values({
        name: data.name,
        email: data.email.toLowerCase(),
        phone: data.phone || null,
        service: data.service,
        budget: data.budget || null,
        message: data.message,
        locale: data.locale,
        status: "new",
      })
      .returning({ id: contactMessages.id, submittedAt: contactMessages.submittedAt });

    if (!inserted[0]) {
      return NextResponse.json({ ok: false, error: "INSERT_FAILED" }, { status: 500 });
    }

    return NextResponse.json({ ok: true, id: inserted[0].id }, { status: 201 });
  } catch (error) {
    console.error("[contact] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
