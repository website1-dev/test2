import { NextResponse } from "next/server";
import { db } from "@/db";
import { media } from "@/db/schema";
import { getCurrentAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX_BYTES = 6 * 1024 * 1024;
const ALLOWED = ["image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml"];

export async function POST(request: Request) {
  const admin = await getCurrentAdmin();
  if (!admin) {
    return NextResponse.json({ ok: false, error: "UNAUTHORIZED" }, { status: 401 });
  }
  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ ok: false, error: "NO_FILE" }, { status: 400 });
    }
    if (!ALLOWED.includes(file.type)) {
      return NextResponse.json({ ok: false, error: "UNSUPPORTED_TYPE" }, { status: 415 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ ok: false, error: "TOO_LARGE" }, { status: 413 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const inserted = await db
      .insert(media)
      .values({
        filename: file.name.slice(0, 180) || "upload",
        mimeType: file.type,
        size: buffer.byteLength,
        data: buffer,
      })
      .returning({ id: media.id });

    if (!inserted[0]) {
      return NextResponse.json({ ok: false, error: "INSERT_FAILED" }, { status: 500 });
    }
    return NextResponse.json({ ok: true, id: inserted[0].id, url: `/api/images/${inserted[0].id}` });
  } catch (error) {
    console.error("[upload] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
