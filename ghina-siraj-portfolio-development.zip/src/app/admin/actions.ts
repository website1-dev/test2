"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import {
  contactMessages,
  faqTranslations,
  faqs,
  pricingPackages,
  pricingTranslations,
  projectTranslations,
  projects,
  serviceTranslations,
  services,
  skills,
} from "@/db/schema";
import { authenticate, createSession, destroySession, getCurrentAdmin } from "@/lib/auth";
import { ensureSeeded } from "@/lib/bootstrap";
import { CONTENT_KEYS, saveContentEntry } from "@/lib/content";
import { saveSettings } from "@/lib/settings";
import { parseList, slugify } from "@/lib/cn";
import { locales } from "@/lib/i18n/config";
import type { Locale } from "@/lib/i18n/config";

const LOCALES = locales;

async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin");
  return admin;
}

function refreshPublic() {
  revalidatePath("/", "layout");
}

function str(form: FormData, key: string): string {
  const value = form.get(key);
  return typeof value === "string" ? value.trim() : "";
}

function num(form: FormData, key: string, fallback = 0): number {
  const value = Number.parseInt(str(form, key), 10);
  return Number.isFinite(value) ? value : fallback;
}

function bool(form: FormData, key: string): boolean {
  return form.get(key) === "on" || form.get(key) === "true";
}

/* ------------------------------- auth actions ------------------------------ */

export async function loginAction(formData: FormData): Promise<void> {
  await ensureSeeded();
  const email = str(formData, "email");
  const password = str(formData, "password");
  const next = str(formData, "next") || "/admin/dashboard";

  if (!email || !password) redirect("/admin?error=missing");
  const result = await authenticate(email, password);
  if (!result.ok) redirect("/admin?error=invalid");

  const headerList = await headers();
  await createSession(result.user.id, headerList.get("user-agent"));
  redirect(next.startsWith("/admin") ? next : "/admin/dashboard");
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/admin");
}

/* --------------------------------- projects -------------------------------- */

const projectSchema = z.object({
  slug: z.string().min(1).max(80),
  category: z.string().min(1).max(40),
  technologies: z.array(z.string().min(1).max(40)).max(20).default([]),
  externalUrl: z.string().max(400).optional().nullable(),
  repositoryUrl: z.string().max(400).optional().nullable(),
  coverImageUrl: z.string().max(600).optional().nullable(),
  featured: z.boolean().default(false),
  published: z.boolean().default(true),
  sortOrder: z.number().int().min(0).max(999).default(0),
  translations: z.array(
    z.object({
      locale: z.enum(["en", "fr", "ar"]),
      title: z.string().min(1).max(160),
      summary: z.string().max(400).default(""),
      description: z.string().max(6000).default(""),
      features: z.array(z.string().max(200)).max(20).default([]),
    }),
  ),
});

export async function saveProjectAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const titleFallback = str(formData, "title_en") || "New project";
  const slug = slugify(str(formData, "slug") || titleFallback) || `project-${Date.now()}`;

  const payload = projectSchema.safeParse({
    slug,
    category: str(formData, "category") || "website",
    technologies: str(formData, "technologies")
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean),
    externalUrl: str(formData, "externalUrl") || null,
    repositoryUrl: str(formData, "repositoryUrl") || null,
    coverImageUrl: str(formData, "coverImageUrl") || null,
    featured: bool(formData, "featured"),
    published: bool(formData, "published"),
    sortOrder: num(formData, "sortOrder", 0),
    translations: LOCALES.map((locale) => ({
      locale,
      title: str(formData, `title_${locale}`) || titleFallback,
      summary: str(formData, `summary_${locale}`),
      description: str(formData, `description_${locale}`),
      features: parseList(str(formData, `features_${locale}`)),
    })),
  });

  if (!payload.success) redirect(`/admin/projects?error=validation`);
  const data = payload.data;

  if (id > 0) {
    await db
      .update(projects)
      .set({
        slug: data.slug,
        category: data.category,
        technologies: data.technologies,
        externalUrl: data.externalUrl,
        repositoryUrl: data.repositoryUrl,
        coverImageUrl: data.coverImageUrl,
        featured: data.featured,
        published: data.published,
        sortOrder: data.sortOrder,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id));
    for (const translation of data.translations) {
      await db
        .insert(projectTranslations)
        .values({ projectId: id, ...translation })
        .onConflictDoUpdate({
          target: [projectTranslations.projectId, projectTranslations.locale],
          set: {
            title: translation.title,
            summary: translation.summary,
            description: translation.description,
            features: translation.features,
          },
        });
    }
  } else {
    const inserted = await db
      .insert(projects)
      .values({
        slug: data.slug,
        category: data.category,
        technologies: data.technologies,
        externalUrl: data.externalUrl,
        repositoryUrl: data.repositoryUrl,
        coverImageUrl: data.coverImageUrl,
        featured: data.featured,
        published: data.published,
        sortOrder: data.sortOrder,
      })
      .returning({ id: projects.id });
    const projectId = inserted[0]?.id;
    if (projectId) {
      await db
        .insert(projectTranslations)
        .values(data.translations.map((translation) => ({ projectId, ...translation })))
        .onConflictDoNothing();
    }
  }
  refreshPublic();
  redirect("/admin/projects?saved=1");
}

export async function deleteProjectAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id > 0) await db.delete(projects).where(eq(projects.id, id));
  refreshPublic();
  redirect("/admin/projects?deleted=1");
}

export async function toggleProjectAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const published = bool(formData, "published");
  if (id > 0) {
    await db
      .update(projects)
      .set({ published, updatedAt: new Date() })
      .where(eq(projects.id, id));
  }
  refreshPublic();
  redirect("/admin/projects");
}

/* --------------------------------- services -------------------------------- */

export async function saveServiceAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const titleFallback = str(formData, "title_en") || "New service";
  const slug = slugify(str(formData, "slug") || titleFallback) || `service-${Date.now()}`;

  const values = {
    slug,
    icon: str(formData, "icon") || "Globe",
    startingPrice: Math.max(0, num(formData, "startingPrice", 0)),
    currency: str(formData, "currency") || "MAD",
    visible: bool(formData, "visible"),
    sortOrder: num(formData, "sortOrder", 0),
    updatedAt: new Date(),
  };

  const translations = LOCALES.map((locale) => ({
    locale,
    title: str(formData, `title_${locale}`) || titleFallback,
    summary: str(formData, `summary_${locale}`),
    description: str(formData, `description_${locale}`),
    features: parseList(str(formData, `features_${locale}`)),
    benefits: parseList(str(formData, `benefits_${locale}`)),
    deliveryTime: str(formData, `deliveryTime_${locale}`),
  }));

  if (id > 0) {
    await db.update(services).set(values).where(eq(services.id, id));
    for (const translation of translations) {
      await db
        .insert(serviceTranslations)
        .values({ serviceId: id, ...translation })
        .onConflictDoUpdate({
          target: [serviceTranslations.serviceId, serviceTranslations.locale],
          set: {
            title: translation.title,
            summary: translation.summary,
            description: translation.description,
            features: translation.features,
            benefits: translation.benefits,
            deliveryTime: translation.deliveryTime,
          },
        });
    }
  } else {
    const inserted = await db.insert(services).values(values).returning({ id: services.id });
    const serviceId = inserted[0]?.id;
    if (serviceId) {
      await db
        .insert(serviceTranslations)
        .values(translations.map((translation) => ({ serviceId, ...translation })))
        .onConflictDoNothing();
    }
  }
  refreshPublic();
  redirect("/admin/services?saved=1");
}

export async function deleteServiceAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id > 0) await db.delete(services).where(eq(services.id, id));
  refreshPublic();
  redirect("/admin/services?deleted=1");
}

/* ---------------------------------- pricing -------------------------------- */

export async function savePackageAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id <= 0) redirect("/admin/pricing?error=validation");

  await db
    .update(pricingPackages)
    .set({
      price: Math.max(0, num(formData, "price", 0)),
      currency: str(formData, "currency") || "MAD",
      popular: bool(formData, "popular"),
      enabled: bool(formData, "enabled"),
      sortOrder: num(formData, "sortOrder", 0),
      updatedAt: new Date(),
    })
    .where(eq(pricingPackages.id, id));

  for (const locale of LOCALES) {
    const translation = {
      locale,
      name: str(formData, `name_${locale}`) || str(formData, `name_en`) || "Package",
      description: str(formData, `description_${locale}`),
      features: parseList(str(formData, `features_${locale}`)),
      deliveryTime: str(formData, `deliveryTime_${locale}`),
      revisions: str(formData, `revisions_${locale}`),
    };
    await db
      .insert(pricingTranslations)
      .values({ packageId: id, ...translation })
      .onConflictDoUpdate({
        target: [pricingTranslations.packageId, pricingTranslations.locale],
        set: {
          name: translation.name,
          description: translation.description,
          features: translation.features,
          deliveryTime: translation.deliveryTime,
          revisions: translation.revisions,
        },
      });
  }
  refreshPublic();
  redirect("/admin/pricing?saved=1");
}

/* ------------------------------------ faq ---------------------------------- */

export async function saveFaqAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const published = bool(formData, "published");
  const sortOrder = num(formData, "sortOrder", 0);

  let faqId = id;
  if (id > 0) {
    await db.update(faqs).set({ published, sortOrder }).where(eq(faqs.id, id));
  } else {
    const inserted = await db
      .insert(faqs)
      .values({ published, sortOrder })
      .returning({ id: faqs.id });
    faqId = inserted[0]?.id ?? 0;
  }
  if (!faqId) redirect("/admin/faqs?error=validation");

  for (const locale of LOCALES) {
    const translation = {
      locale,
      question: str(formData, `question_${locale}`) || str(formData, "question_en") || "…",
      answer: str(formData, `answer_${locale}`),
    };
    await db
      .insert(faqTranslations)
      .values({ faqId, ...translation })
      .onConflictDoUpdate({
        target: [faqTranslations.faqId, faqTranslations.locale],
        set: { question: translation.question, answer: translation.answer },
      });
  }
  refreshPublic();
  redirect("/admin/faqs?saved=1");
}

export async function deleteFaqAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id > 0) await db.delete(faqs).where(eq(faqs.id, id));
  refreshPublic();
  redirect("/admin/faqs?deleted=1");
}

/* ----------------------------------- skills -------------------------------- */

export async function saveSkillAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const values = {
    category: str(formData, "category") || "frontend",
    name: str(formData, "name") || "Skill",
    level: Math.min(100, Math.max(0, num(formData, "level", 0))),
    description: str(formData, "description"),
    visible: bool(formData, "visible"),
    sortOrder: num(formData, "sortOrder", 0),
  };
  if (id > 0) {
    await db.update(skills).set(values).where(eq(skills.id, id));
  } else {
    await db.insert(skills).values(values);
  }
  refreshPublic();
  redirect("/admin/skills?saved=1");
}

export async function deleteSkillAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id > 0) await db.delete(skills).where(eq(skills.id, id));
  refreshPublic();
  redirect("/admin/skills?deleted=1");
}

/* ------------------------------- site content ------------------------------ */

export async function saveContentAction(formData: FormData): Promise<void> {
  await requireAdmin();
  for (const key of CONTENT_KEYS) {
    for (const locale of LOCALES) {
      const field = `${key}_${locale}`;
      if (!formData.has(field)) continue;
      await saveContentEntry(key, locale as Locale, str(formData, field));
    }
  }
  refreshPublic();
  redirect("/admin/content?saved=1");
}

export async function saveSettingsAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const entries: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value !== "string") continue;
    if (key.startsWith("setting_")) {
      entries[key.replace("setting_", "")] = value.trim();
    }
  }
  await saveSettings(entries);
  refreshPublic();
  redirect("/admin/settings?saved=1");
}

/* --------------------------------- messages -------------------------------- */

export async function markMessageAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  const status = str(formData, "status") || "read";
  if (id > 0) {
    await db
      .update(contactMessages)
      .set({ status, readAt: status === "new" ? null : new Date() })
      .where(eq(contactMessages.id, id));
  }
  revalidatePath("/admin/messages");
  revalidatePath("/admin/dashboard");
  redirect("/admin/messages");
}

export async function deleteMessageAction(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id", 0);
  if (id > 0) await db.delete(contactMessages).where(eq(contactMessages.id, id));
  revalidatePath("/admin/messages");
  revalidatePath("/admin/dashboard");
  redirect("/admin/messages?deleted=1");
}
