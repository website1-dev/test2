import Link from "next/link";
import { redirect } from "next/navigation";
import { AlertTriangle, LockKeyhole, ShieldCheck } from "lucide-react";
import { AdminButton, Alert, Field, adminInput } from "@/components/admin/ui";
import { loginAction } from "@/app/admin/actions";
import { getCurrentAdmin } from "@/lib/auth";
import { ensureSeeded } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid: "Invalid email or password. Please try again.",
  missing: "Please enter both your email address and your password.",
};

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  await ensureSeeded();
  const admin = await getCurrentAdmin();
  if (admin) redirect("/admin/dashboard");
  const { error, next } = await searchParams;

  return (
    <main className="relative grid min-h-screen place-items-center px-5 py-16">
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_60%_at_50%_0%,rgba(37,99,235,0.22),transparent_70%)]"
        aria-hidden
      />
      <div className="relative w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-blue-600 to-sky-500 text-white shadow-[0_20px_50px_-25px_rgba(37,99,235,0.9)]">
            <ShieldCheck className="h-7 w-7" aria-hidden />
          </span>
          <h1 className="text-2xl font-semibold text-white">Admin sign in</h1>
          <p className="text-sm text-slate-400">
            Private area for managing the portfolio of Ghina Siraj.
          </p>
        </div>

        <form
          action={loginAction}
          className="flex flex-col gap-5 rounded-2xl border border-slate-800 bg-slate-900/60 p-7 backdrop-blur"
        >
          <input type="hidden" name="next" value={next ?? "/admin/dashboard"} />
          {error && ERRORS[error] ? <Alert tone="error">{ERRORS[error]}</Alert> : null}
          <Field label="Email address" htmlFor="email">
            <input
              id="email"
              name="email"
              type="email"
              required
              autoComplete="username"
              placeholder="admin@example.com"
              className={adminInput}
            />
          </Field>
          <Field label="Password" htmlFor="password">
            <input
              id="password"
              name="password"
              type="password"
              required
              autoComplete="current-password"
              placeholder="••••••••"
              className={adminInput}
            />
          </Field>
          <AdminButton type="submit" className="w-full">
            <LockKeyhole className="h-4 w-4" aria-hidden />
            Sign in securely
          </AdminButton>
          <p className="flex items-start gap-2 text-xs text-slate-500">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
            There is no public registration. Admin accounts are created from the
            ADMIN_EMAIL / ADMIN_PASSWORD environment variables.
          </p>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          <Link href="/en" className="transition hover:text-slate-200">
            ← Back to website
          </Link>
        </p>
      </div>
    </main>
  );
}
