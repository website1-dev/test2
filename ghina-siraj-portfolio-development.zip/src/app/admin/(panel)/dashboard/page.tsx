import Link from "next/link";
import { ArrowUpRight, FolderKanban, Mail, Shapes, Sparkles } from "lucide-react";
import { AdminCard, AdminLink, Alert } from "@/components/admin/ui";
import { getDashboardStats } from "@/lib/data";
import { formatDate } from "@/lib/cn";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  await requireAdminPage();
  const stats = await getDashboardStats();

  const cards = [
    { label: "Projects", value: stats.projects, Icon: FolderKanban, href: "/admin/projects" },
    { label: "Services", value: stats.services, Icon: Shapes, href: "/admin/services" },
    { label: "Messages", value: stats.messages, Icon: Mail, href: "/admin/messages" },
    { label: "Unread", value: stats.unread, Icon: Sparkles, href: "/admin/messages" },
  ];

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-white">Dashboard overview</h1>
          <p className="mt-1 text-sm text-slate-400">
            Everything you publish here is reflected immediately on the public website.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <AdminLink href="/admin/projects" variant="secondary">
            New project
          </AdminLink>
          <AdminLink href="/admin/services" variant="secondary">
            New service
          </AdminLink>
          <AdminLink href="/admin/content">Edit content</AdminLink>
        </div>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map(({ label, value, Icon, href }) => (
          <Link
            key={label}
            href={href}
            className="group rounded-2xl border border-slate-800 bg-slate-900/50 p-5 transition hover:border-sky-500/50"
          >
            <div className="flex items-center justify-between">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-blue-600/15 text-sky-400">
                <Icon className="h-5 w-5" aria-hidden />
              </span>
              <ArrowUpRight
                className="h-4 w-4 text-slate-600 transition group-hover:text-sky-400"
                aria-hidden
              />
            </div>
            <p className="mt-4 text-3xl font-semibold text-white">{value}</p>
            <p className="text-xs uppercase tracking-widest text-slate-500">{label}</p>
          </Link>
        ))}
      </div>

      {stats.unread > 0 ? (
        <Alert tone="info">
          You have {stats.unread} unread contact message{stats.unread > 1 ? "s" : ""}.{" "}
          <Link href="/admin/messages" className="underline">
            Open the inbox
          </Link>
          .
        </Alert>
      ) : null}

      <AdminCard
        title="Recent submissions"
        description="The latest contact requests saved in the database."
        actions={<AdminLink href="/admin/messages">View all</AdminLink>}
      >
        {stats.recent.length === 0 ? (
          <p className="text-sm text-slate-400">No messages yet.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {stats.recent.map((message) => (
              <li key={message.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div>
                  <p className="text-sm font-medium text-white">{message.name}</p>
                  <p className="text-xs text-slate-500">
                    {message.email} · {message.service ?? "—"} · {message.locale.toUpperCase()}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-500">
                    {formatDate(message.submittedAt, "en")}
                  </span>
                  <span
                    className={`rounded-full px-2.5 py-1 text-[11px] uppercase tracking-widest ${
                      message.status === "new"
                        ? "bg-sky-500/15 text-sky-300"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {message.status}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </AdminCard>
    </div>
  );
}
