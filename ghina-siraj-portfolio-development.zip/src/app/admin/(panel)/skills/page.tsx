import { Pencil, Trash2 } from "lucide-react";
import {
  AdminButton,
  AdminCard,
  AdminLink,
  Alert,
  Field,
  Toggle,
  adminInput,
  adminTextarea,
} from "@/components/admin/ui";
import { deleteSkillAction, saveSkillAction } from "@/app/admin/actions";
import { getSkills } from "@/lib/data";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Skills · Admin" };

const CATEGORIES = ["frontend", "backend", "tools", "design"] as const;

export default async function AdminSkillsPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; saved?: string; deleted?: string }>;
}) {
  await requireAdminPage();
  const { id, saved, deleted } = await searchParams;
  const editId = id ? Number.parseInt(id, 10) : 0;
  const skills = await getSkills({ includeHidden: true });
  const editing = editId > 0 ? skills.find((skill) => skill.id === editId) : undefined;

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-white">Skill management</h1>
          <p className="mt-1 text-sm text-slate-400">
            Skill names are language independent; the category labels are translated in the
            dictionary.
          </p>
        </div>
        {editing ? <AdminLink href="/admin/skills">+ New skill</AdminLink> : null}
      </header>

      {saved ? <Alert tone="success">Skill saved.</Alert> : null}
      {deleted ? <Alert tone="info">Skill deleted.</Alert> : null}

      <AdminCard title={editing ? "Edit skill" : "Add a skill"}>
        <form action={saveSkillAction} className="flex flex-col gap-5">
          {editing ? <input type="hidden" name="id" value={editing.id} /> : null}
          <div className="grid gap-5 md:grid-cols-4">
            <Field label="Name" htmlFor="name">
              <input id="name" name="name" defaultValue={editing?.name ?? ""} className={adminInput} />
            </Field>
            <Field label="Category" htmlFor="category">
              <select
                id="category"
                name="category"
                defaultValue={editing?.category ?? "frontend"}
                className={adminInput}
              >
                {CATEGORIES.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Level (0 – 100)" htmlFor="level">
              <input
                id="level"
                name="level"
                type="number"
                min={0}
                max={100}
                defaultValue={editing?.level ?? 80}
                className={adminInput}
              />
            </Field>
            <Field label="Sort order" htmlFor="sortOrder">
              <input
                id="sortOrder"
                name="sortOrder"
                type="number"
                min={0}
                defaultValue={editing?.sortOrder ?? skills.length + 1}
                className={adminInput}
              />
            </Field>
          </div>
          <Field label="Internal note (not published)" htmlFor="description">
            <textarea
              id="description"
              name="description"
              rows={2}
              defaultValue={editing ? (editing as { description?: string }).description ?? "" : ""}
              className={adminTextarea}
            />
          </Field>
          <Toggle name="visible" label="Visible on website" defaultChecked={editing?.visible ?? true} />
          <div className="flex flex-wrap gap-3">
            <AdminButton type="submit">{editing ? "Update skill" : "Add skill"}</AdminButton>
            {editing ? <AdminLink href="/admin/skills" variant="secondary">Cancel</AdminLink> : null}
          </div>
        </form>
      </AdminCard>

      <AdminCard title={`All skills (${skills.length})`}>
        <ul className="flex flex-col divide-y divide-slate-800">
          {skills.map((skill) => (
            <li key={skill.id} className="flex flex-wrap items-center gap-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-white">
                  {skill.name}{" "}
                  <span className="ms-2 rounded-md bg-slate-800 px-2 py-0.5 text-[10px] uppercase tracking-widest text-slate-400">
                    {skill.category}
                  </span>
                </p>
                <p className="text-xs text-slate-500">Level {skill.level}%</p>
              </div>
              <AdminLink href={`/admin/skills?id=${skill.id}`} variant="secondary">
                <Pencil className="h-4 w-4" aria-hidden />
                Edit
              </AdminLink>
              <form action={deleteSkillAction}>
                <input type="hidden" name="id" value={skill.id} />
                <AdminButton type="submit" variant="danger">
                  <Trash2 className="h-4 w-4" aria-hidden />
                  Delete
                </AdminButton>
              </form>
            </li>
          ))}
        </ul>
      </AdminCard>
    </div>
  );
}
