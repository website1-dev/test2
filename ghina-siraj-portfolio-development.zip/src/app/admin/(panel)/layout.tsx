import type { ReactNode } from "react";
import { AdminSidebar } from "@/components/admin/sidebar";
import { getCurrentAdmin } from "@/lib/auth";
import { ensureSeeded } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export default async function AdminPanelLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const admin = await getCurrentAdmin();
  if (!admin) {
    return (
      <main className="grid min-h-screen place-items-center px-6 text-center">
        <div className="max-w-md rounded-2xl border border-slate-800 bg-slate-900/60 p-8">
          <h1 className="text-xl font-semibold text-white">Session required</h1>
          <p className="mt-2 text-sm text-slate-400">
            Your session expired or you do not have access to this area. Please sign in again.
          </p>
          <a
            href="/admin"
            className="mt-6 inline-flex h-10 items-center rounded-lg bg-blue-600 px-4 text-sm font-medium text-white transition hover:bg-blue-500"
          >
            Go to sign in
          </a>
        </div>
      </main>
    );
  }

  return (
    <div className="min-h-screen lg:ps-64">
      <AdminSidebar admin={admin} />
      <main className="px-5 py-8 lg:px-10">{children}</main>
    </div>
  );
}
