import { AdminButton, AdminCard, Alert, Field, adminInput, adminTextarea } from "@/components/admin/ui";
import { LocaleTabs } from "@/components/admin/form-controls";
import { saveContentAction } from "@/app/admin/actions";
import { CONTENT_GROUPS, contentDefaultValue, getAllContent } from "@/lib/content";
import { locales } from "@/lib/i18n/config";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Content · Admin" };

export default async function AdminContentPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  await requireAdminPage();
  const { saved } = await searchParams;
  const stored = await getAllContent();

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Website content</h1>
        <p className="mt-1 text-sm text-slate-400">
          Every field can be written in English, French and Arabic. Empty fields fall back to the
          built-in English copy, so the site is never left untranslated.
        </p>
      </header>

      {saved ? <Alert tone="success">Content saved and published to the website.</Alert> : null}

      <form action={saveContentAction} className="flex flex-col gap-6">
        <div className="grid gap-6 xl:grid-cols-2">
          {CONTENT_GROUPS.map((group) => (
            <AdminCard key={group.id} title={group.title} description={group.description}>
              <div className="flex flex-col gap-4">
                {group.fields.map((field) => (
                  <div key={field.key} className="rounded-xl border border-slate-800 bg-slate-950/30 p-3">
                    <p className="mb-2 text-[11px] uppercase tracking-widest text-slate-500">
                      {field.key}
                    </p>
                    <LocaleTabs
                      panels={locales.map((locale) => ({
                        locale,
                        node: (
                          <Field
                            label={`${field.label} (${locale})`}
                            htmlFor={`${field.key}_${locale}`}
                            hint={field.help}
                          >
                            {field.type === "textarea" ? (
                              <textarea
                                id={`${field.key}_${locale}`}
                                name={`${field.key}_${locale}`}
                                rows={4}
                                placeholder={contentDefaultValue(field.key)}
                                defaultValue={stored[field.key]?.[locale] ?? ""}
                                className={adminTextarea}
                              />
                            ) : (
                              <input
                                id={`${field.key}_${locale}`}
                                name={`${field.key}_${locale}`}
                                placeholder={contentDefaultValue(field.key)}
                                defaultValue={stored[field.key]?.[locale] ?? ""}
                                className={adminInput}
                              />
                            )}
                          </Field>
                        ),
                      }))}
                    />
                  </div>
                ))}
              </div>
            </AdminCard>
          ))}
        </div>

        <div className="sticky bottom-4 flex justify-end">
          <AdminButton type="submit">Save all content</AdminButton>
        </div>
      </form>
    </div>
  );
}
