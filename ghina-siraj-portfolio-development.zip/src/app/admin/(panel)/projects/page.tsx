import { inArray } from "drizzle-orm";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { db } from "@/db";
import { projectTranslations, projects } from "@/db/schema";
import {
  AdminButton,
  AdminCard,
  AdminLink,
  Alert,
  Field,
  LocaleBadge,
  Toggle,
  adminInput,
  adminTextarea,
} from "@/components/admin/ui";
import { ImageField, LocaleTabs } from "@/components/admin/form-controls";
import {
  deleteProjectAction,
  saveProjectAction,
  toggleProjectAction,
} from "@/app/admin/actions";
import { CATEGORY_KEYS } from "@/lib/data";
import { locales } from "@/lib/i18n/config";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Translation = typeof projectTranslations.$inferSelect;

export default async function AdminProjectsPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; saved?: string; deleted?: string; error?: string }>;
}) {
  await requireAdminPage();
  const { id, saved, deleted, error } = await searchParams;
  const editId = id ? Number.parseInt(id, 10) : 0;

  const list = await db
    .select()
    .from(projects)
    .orderBy(projects.sortOrder, projects.id)
    .catch(() => []);
  const translations =
    list.length > 0
      ? await db
          .select()
          .from(projectTranslations)
          .where(
            inArray(
              projectTranslations.projectId,
              list.map((project) => project.id),
            ),
          )
          .catch(() => [] as Translation[])
      : ([] as Translation[]);

  const editing = editId > 0 ? list.find((project) => project.id === editId) : undefined;
  const editingTranslations = editing
    ? translations.filter((row) => row.projectId === editing.id)
    : [];

  function translationFor(locale: string): Partial<Translation> {
    return editingTranslations.find((row) => row.locale === locale) ?? {};
  }

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-white">Project management</h1>
          <p className="mt-1 text-sm text-slate-400">
            Create, translate, publish and delete portfolio projects.
          </p>
        </div>
        {editing ? (
          <AdminLink href="/admin/projects">+ New project</AdminLink>
        ) : (
          <span className="text-sm text-slate-500">
            <Plus className="me-1 inline h-4 w-4" aria-hidden />
            Use the form below to add a project
          </span>
        )}
      </header>

      {saved ? <Alert tone="success">Project saved successfully.</Alert> : null}
      {deleted ? <Alert tone="info">Project deleted.</Alert> : null}
      {error ? <Alert tone="error">Please check the form values and try again.</Alert> : null}

      <AdminCard
        title={editing ? `Edit project · ${editing.slug}` : "Create a new project"}
        description="Every field is stored per language. Leave a language empty to reuse the English title."
      >
        <form action={saveProjectAction} className="flex flex-col gap-6">
          {editing ? <input type="hidden" name="id" value={editing.id} /> : null}

          <div className="grid gap-5 md:grid-cols-3">
            <Field label="Slug (URL)" htmlFor="slug">
              <input
                id="slug"
                name="slug"
                defaultValue={editing?.slug ?? ""}
                placeholder="bella-pizza"
                className={adminInput}
              />
            </Field>
            <Field label="Category" htmlFor="category">
              <select
                id="category"
                name="category"
                defaultValue={editing?.category ?? "website"}
                className={adminInput}
              >
                {CATEGORY_KEYS.map((key) => (
                  <option key={key} value={key}>
                    {key}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Sort order" htmlFor="sortOrder">
              <input
                id="sortOrder"
                name="sortOrder"
                type="number"
                min={0}
                defaultValue={editing?.sortOrder ?? 0}
                className={adminInput}
              />
            </Field>
            <Field label="Technologies (comma separated)" htmlFor="technologies" className="md:col-span-3">
              <input
                id="technologies"
                name="technologies"
                defaultValue={(editing?.technologies ?? []).join(", ")}
                placeholder="Next.js, TypeScript, Tailwind CSS"
                className={adminInput}
              />
            </Field>
            <Field label="Project URL (public link)" htmlFor="externalUrl">
              <input
                id="externalUrl"
                name="externalUrl"
                defaultValue={editing?.externalUrl ?? ""}
                placeholder="https://… (leave empty for a placeholder)"
                className={adminInput}
              />
            </Field>
            <Field label="Repository URL" htmlFor="repositoryUrl">
              <input
                id="repositoryUrl"
                name="repositoryUrl"
                defaultValue={editing?.repositoryUrl ?? ""}
                placeholder="https://github.com/…"
                className={adminInput}
              />
            </Field>
            <div className="md:col-span-3">
              <ImageField
                name="coverImageUrl"
                label="Cover image"
                defaultValue={editing?.coverImageUrl ?? ""}
                hint="Upload a screenshot or paste an image URL. Shown on the project card and detail page."
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <Toggle name="featured" label="Featured on homepage" defaultChecked={editing?.featured ?? false} />
            <Toggle name="published" label="Published" defaultChecked={editing?.published ?? true} />
          </div>

          <LocaleTabs
            panels={locales.map((locale) => {
              const row = translationFor(locale);
              return {
                locale,
                node: (
                  <div className="grid gap-4">
                    <Field label={`Title (${locale})`} htmlFor={`title_${locale}`}>
                      <input
                        id={`title_${locale}`}
                        name={`title_${locale}`}
                        defaultValue={row.title ?? ""}
                        className={adminInput}
                      />
                    </Field>
                    <Field label={`Short summary (${locale})`} htmlFor={`summary_${locale}`}>
                      <textarea
                        id={`summary_${locale}`}
                        name={`summary_${locale}`}
                        rows={2}
                        defaultValue={row.summary ?? ""}
                        className={adminTextarea}
                      />
                    </Field>
                    <Field label={`Description (${locale})`} htmlFor={`description_${locale}`}>
                      <textarea
                        id={`description_${locale}`}
                        name={`description_${locale}`}
                        rows={6}
                        defaultValue={row.description ?? ""}
                        className={adminTextarea}
                      />
                    </Field>
                    <Field
                      label={`Features (${locale}) — one per line`}
                      htmlFor={`features_${locale}`}
                    >
                      <textarea
                        id={`features_${locale}`}
                        name={`features_${locale}`}
                        rows={5}
                        defaultValue={(row.features ?? []).join("\n")}
                        className={adminTextarea}
                      />
                    </Field>
                  </div>
                ),
              };
            })}
          />

          <div className="flex flex-wrap gap-3">
            <AdminButton type="submit">{editing ? "Update project" : "Create project"}</AdminButton>
            {editing ? (
              <AdminLink href="/admin/projects" variant="secondary">
                Cancel
              </AdminLink>
            ) : null}
          </div>
        </form>
      </AdminCard>

      <AdminCard title={`All projects (${list.length})`}>
        {list.length === 0 ? (
          <p className="text-sm text-slate-400">No projects yet.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-slate-800">
            {list.map((project) => {
              const english =
                translations.find((row) => row.projectId === project.id && row.locale === "en") ??
                translations.find((row) => row.projectId === project.id);
              return (
                <li key={project.id} className="flex flex-wrap items-center gap-4 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-white">
                      {english?.title ?? project.slug}
                      <LocaleBadge locale={project.category} />
                      {project.featured ? (
                        <span className="rounded-md bg-amber-500/15 px-2 py-0.5 text-[10px] uppercase tracking-widest text-amber-300">
                          featured
                        </span>
                      ) : null}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      /{project.slug} · {project.technologies.join(", ") || "no technologies"}
                    </p>
                  </div>
                  <form action={toggleProjectAction}>
                    <input type="hidden" name="id" value={project.id} />
                    <input type="hidden" name="published" value={project.published ? "false" : "true"} />
                    <AdminButton type="submit" variant="secondary">
                      {project.published ? "Unpublish" : "Publish"}
                    </AdminButton>
                  </form>
                  <AdminLink href={`/admin/projects?id=${project.id}`} variant="secondary">
                    <Pencil className="h-4 w-4" aria-hidden />
                    Edit
                  </AdminLink>
                  <form action={deleteProjectAction}>
                    <input type="hidden" name="id" value={project.id} />
                    <AdminButton type="submit" variant="danger">
                      <Trash2 className="h-4 w-4" aria-hidden />
                      Delete
                    </AdminButton>
                  </form>
                </li>
              );
            })}
          </ul>
        )}
      </AdminCard>
    </div>
  );
}
