import { inArray } from "drizzle-orm";
import { Pencil, Trash2 } from "lucide-react";
import { db } from "@/db";
import { serviceTranslations, services } from "@/db/schema";
import {
  AdminButton,
  AdminCard,
  AdminLink,
  Alert,
  Field,
  LocaleBadge,
  Toggle,
  adminInput,
  adminTextarea,
} from "@/components/admin/ui";
import { LocaleTabs } from "@/components/admin/form-controls";
import { deleteServiceAction, saveServiceAction } from "@/app/admin/actions";
import { ICON_OPTIONS } from "@/components/site/service-icon";
import { locales } from "@/lib/i18n/config";
import { formatPrice } from "@/lib/settings";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Services · Admin" };

export default async function AdminServicesPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; saved?: string; deleted?: string }>;
}) {
  await requireAdminPage();
  const { id, saved, deleted } = await searchParams;
  const editId = id ? Number.parseInt(id, 10) : 0;

  const list = await db.select().from(services).orderBy(services.sortOrder, services.id).catch(() => []);
  const translations =
    list.length > 0
      ? await db
          .select()
          .from(serviceTranslations)
          .where(
            inArray(
              serviceTranslations.serviceId,
              list.map((service) => service.id),
            ),
          )
          .catch(() => [])
      : [];

  const editing = editId > 0 ? list.find((service) => service.id === editId) : undefined;
  const editingTranslations = editing
    ? translations.filter((row) => row.serviceId === editing.id)
    : [];

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-white">Service management</h1>
          <p className="mt-1 text-sm text-slate-400">
            Control prices, descriptions, features and visibility of every service.
          </p>
        </div>
        {editing ? <AdminLink href="/admin/services">+ New service</AdminLink> : null}
      </header>

      {saved ? <Alert tone="success">Service saved successfully.</Alert> : null}
      {deleted ? <Alert tone="info">Service deleted.</Alert> : null}

      <AdminCard
        title={editing ? `Edit service · ${editing.slug}` : "Create a new service"}
        description="Prices are shown in Moroccan Dirhams (MAD) on the public website."
      >
        <form action={saveServiceAction} className="flex flex-col gap-6">
          {editing ? <input type="hidden" name="id" value={editing.id} /> : null}

          <div className="grid gap-5 md:grid-cols-4">
            <Field label="Slug (URL)" htmlFor="slug">
              <input id="slug" name="slug" defaultValue={editing?.slug ?? ""} className={adminInput} />
            </Field>
            <Field label="Icon" htmlFor="icon">
              <select id="icon" name="icon" defaultValue={editing?.icon ?? "Globe"} className={adminInput}>
                {ICON_OPTIONS.map((icon) => (
                  <option key={icon} value={icon}>
                    {icon}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Starting price (MAD)" htmlFor="startingPrice">
              <input
                id="startingPrice"
                name="startingPrice"
                type="number"
                min={0}
                defaultValue={editing?.startingPrice ?? 0}
                className={adminInput}
              />
            </Field>
            <Field label="Sort order" htmlFor="sortOrder">
              <input
                id="sortOrder"
                name="sortOrder"
                type="number"
                min={0}
                defaultValue={editing?.sortOrder ?? 0}
                className={adminInput}
              />
            </Field>
          </div>

          <div className="flex flex-wrap gap-3">
            <Toggle name="visible" label="Visible on website" defaultChecked={editing?.visible ?? true} />
            <input type="hidden" name="currency" value="MAD" />
          </div>

          <LocaleTabs
            panels={locales.map((locale) => {
              const row = editingTranslations.find((item) => item.locale === locale);
              return {
                locale,
                node: (
                  <div className="grid gap-4">
                    <Field label={`Title (${locale})`} htmlFor={`title_${locale}`}>
                      <input
                        id={`title_${locale}`}
                        name={`title_${locale}`}
                        defaultValue={row?.title ?? ""}
                        className={adminInput}
                      />
                    </Field>
                    <Field label={`Summary (${locale})`} htmlFor={`summary_${locale}`}>
                      <textarea
                        id={`summary_${locale}`}
                        name={`summary_${locale}`}
                        rows={2}
                        defaultValue={row?.summary ?? ""}
                        className={adminTextarea}
                      />
                    </Field>
                    <Field label={`Description (${locale})`} htmlFor={`description_${locale}`}>
                      <textarea
                        id={`description_${locale}`}
                        name={`description_${locale}`}
                        rows={6}
                        defaultValue={row?.description ?? ""}
                        className={adminTextarea}
                      />
                    </Field>
                    <div className="grid gap-4 md:grid-cols-2">
                      <Field label={`Features (${locale}) — one per line`} htmlFor={`features_${locale}`}>
                        <textarea
                          id={`features_${locale}`}
                          name={`features_${locale}`}
                          rows={6}
                          defaultValue={(row?.features ?? []).join("\n")}
                          className={adminTextarea}
                        />
                      </Field>
                      <Field label={`Benefits (${locale}) — one per line`} htmlFor={`benefits_${locale}`}>
                        <textarea
                          id={`benefits_${locale}`}
                          name={`benefits_${locale}`}
                          rows={6}
                          defaultValue={(row?.benefits ?? []).join("\n")}
                          className={adminTextarea}
                        />
                      </Field>
                    </div>
                    <Field label={`Delivery time (${locale})`} htmlFor={`deliveryTime_${locale}`}>
                      <input
                        id={`deliveryTime_${locale}`}
                        name={`deliveryTime_${locale}`}
                        defaultValue={row?.deliveryTime ?? ""}
                        className={adminInput}
                      />
                    </Field>
                  </div>
                ),
              };
            })}
          />

          <div className="flex flex-wrap gap-3">
            <AdminButton type="submit">{editing ? "Update service" : "Create service"}</AdminButton>
            {editing ? <AdminLink href="/admin/services" variant="secondary">Cancel</AdminLink> : null}
          </div>
        </form>
      </AdminCard>

      <AdminCard title={`All services (${list.length})`}>
        {list.length === 0 ? (
          <p className="text-sm text-slate-400">No services yet.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-slate-800">
            {list.map((service) => {
              const english =
                translations.find((row) => row.serviceId === service.id && row.locale === "en") ??
                translations.find((row) => row.serviceId === service.id);
              return (
                <li key={service.id} className="flex flex-wrap items-center gap-4 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-white">
                      {english?.title ?? service.slug}
                      <LocaleBadge locale={service.icon} />
                      {service.visible ? null : (
                        <span className="rounded-md bg-slate-800 px-2 py-0.5 text-[10px] uppercase tracking-widest text-slate-400">
                          hidden
                        </span>
                      )}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      /{service.slug} · {formatPrice(service.startingPrice, service.currency)}
                    </p>
                  </div>
                  <AdminLink href={`/admin/services?id=${service.id}`} variant="secondary">
                    <Pencil className="h-4 w-4" aria-hidden />
                    Edit
                  </AdminLink>
                  <form action={deleteServiceAction}>
                    <input type="hidden" name="id" value={service.id} />
                    <AdminButton type="submit" variant="danger">
                      <Trash2 className="h-4 w-4" aria-hidden />
                      Delete
                    </AdminButton>
                  </form>
                </li>
              );
            })}
          </ul>
        )}
      </AdminCard>
    </div>
  );
}
