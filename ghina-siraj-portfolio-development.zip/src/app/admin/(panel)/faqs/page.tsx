import { inArray } from "drizzle-orm";
import { Pencil, Trash2 } from "lucide-react";
import { db } from "@/db";
import { faqTranslations, faqs } from "@/db/schema";
import {
  AdminButton,
  AdminCard,
  AdminLink,
  Alert,
  Field,
  Toggle,
  adminInput,
  adminTextarea,
} from "@/components/admin/ui";
import { LocaleTabs } from "@/components/admin/form-controls";
import { deleteFaqAction, saveFaqAction } from "@/app/admin/actions";
import { locales } from "@/lib/i18n/config";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "FAQ · Admin" };

export default async function AdminFaqsPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; saved?: string; deleted?: string }>;
}) {
  await requireAdminPage();
  const { id, saved, deleted } = await searchParams;
  const editId = id ? Number.parseInt(id, 10) : 0;

  const list = await db.select().from(faqs).orderBy(faqs.sortOrder, faqs.id).catch(() => []);
  const translations =
    list.length > 0
      ? await db
          .select()
          .from(faqTranslations)
          .where(
            inArray(
              faqTranslations.faqId,
              list.map((faq) => faq.id),
            ),
          )
          .catch(() => [])
      : [];

  const editing = editId > 0 ? list.find((faq) => faq.id === editId) : undefined;
  const editingTranslations = editing
    ? translations.filter((row) => row.faqId === editing.id)
    : [];

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-white">FAQ management</h1>
          <p className="mt-1 text-sm text-slate-400">
            Questions are shown on the public FAQ page in the selected language.
          </p>
        </div>
        {editing ? <AdminLink href="/admin/faqs">+ New question</AdminLink> : null}
      </header>

      {saved ? <Alert tone="success">Question saved.</Alert> : null}
      {deleted ? <Alert tone="info">Question deleted.</Alert> : null}

      <AdminCard title={editing ? "Edit question" : "Add a question"}>
        <form action={saveFaqAction} className="flex flex-col gap-5">
          {editing ? <input type="hidden" name="id" value={editing.id} /> : null}
          <div className="flex flex-wrap items-end gap-4">
            <Field label="Sort order" htmlFor="sortOrder" className="w-40">
              <input
                id="sortOrder"
                name="sortOrder"
                type="number"
                min={0}
                defaultValue={editing?.sortOrder ?? list.length + 1}
                className={adminInput}
              />
            </Field>
            <Toggle name="published" label="Published" defaultChecked={editing?.published ?? true} />
          </div>

          <LocaleTabs
            panels={locales.map((locale) => {
              const row = editingTranslations.find((item) => item.locale === locale);
              return {
                locale,
                node: (
                  <div className="grid gap-4">
                    <Field label={`Question (${locale})`} htmlFor={`question_${locale}`}>
                      <input
                        id={`question_${locale}`}
                        name={`question_${locale}`}
                        defaultValue={row?.question ?? ""}
                        className={adminInput}
                      />
                    </Field>
                    <Field label={`Answer (${locale})`} htmlFor={`answer_${locale}`}>
                      <textarea
                        id={`answer_${locale}`}
                        name={`answer_${locale}`}
                        rows={5}
                        defaultValue={row?.answer ?? ""}
                        className={adminTextarea}
                      />
                    </Field>
                  </div>
                ),
              };
            })}
          />

          <div className="flex flex-wrap gap-3">
            <AdminButton type="submit">{editing ? "Update question" : "Add question"}</AdminButton>
            {editing ? <AdminLink href="/admin/faqs" variant="secondary">Cancel</AdminLink> : null}
          </div>
        </form>
      </AdminCard>

      <AdminCard title={`All questions (${list.length})`}>
        {list.length === 0 ? (
          <p className="text-sm text-slate-400">No questions yet.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-slate-800">
            {list.map((faq) => {
              const english =
                translations.find((row) => row.faqId === faq.id && row.locale === "en") ??
                translations.find((row) => row.faqId === faq.id);
              return (
                <li key={faq.id} className="flex flex-wrap items-center gap-4 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-white">{english?.question ?? "—"}</p>
                    <p className="mt-1 line-clamp-1 text-xs text-slate-500">{english?.answer ?? ""}</p>
                  </div>
                  <span className="text-xs uppercase tracking-widest text-slate-500">
                    {faq.published ? "published" : "hidden"}
                  </span>
                  <AdminLink href={`/admin/faqs?id=${faq.id}`} variant="secondary">
                    <Pencil className="h-4 w-4" aria-hidden />
                    Edit
                  </AdminLink>
                  <form action={deleteFaqAction}>
                    <input type="hidden" name="id" value={faq.id} />
                    <AdminButton type="submit" variant="danger">
                      <Trash2 className="h-4 w-4" aria-hidden />
                      Delete
                    </AdminButton>
                  </form>
                </li>
              );
            })}
          </ul>
        )}
      </AdminCard>
    </div>
  );
}
