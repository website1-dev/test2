import { AdminButton, AdminCard, Alert, Field, Toggle, adminInput, adminTextarea } from "@/components/admin/ui";
import { LocaleTabs } from "@/components/admin/form-controls";
import { savePackageAction } from "@/app/admin/actions";
import { getAllPackagesWithTranslations } from "@/lib/data";
import { locales } from "@/lib/i18n/config";
import { formatPrice } from "@/lib/settings";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Pricing · Admin" };

export default async function AdminPricingPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  await requireAdminPage();
  const { saved } = await searchParams;
  const packages = await getAllPackagesWithTranslations();

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Pricing management</h1>
        <p className="mt-1 text-sm text-slate-400">
          Edit the Basic, Standard and Premium packages shown on the public pricing page. Prices are
          displayed in Moroccan Dirhams (MAD).
        </p>
      </header>

      {saved ? <Alert tone="success">Package updated successfully.</Alert> : null}

      {packages.length === 0 ? (
        <AdminCard title="No packages">
          <p className="text-sm text-slate-400">
            No pricing packages found. Re-run the database seed to create the three default packages.
          </p>
        </AdminCard>
      ) : (
        <div className="grid gap-6 xl:grid-cols-3">
          {packages.map((pack) => (
            <AdminCard
              key={pack.id}
              title={pack.planKey}
              description={`Current price: ${formatPrice(pack.price, pack.currency)}`}
            >
              <form action={savePackageAction} className="flex flex-col gap-4">
                <input type="hidden" name="id" value={pack.id} />
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Price (MAD)" htmlFor={`price_${pack.id}`}>
                    <input
                      id={`price_${pack.id}`}
                      name="price"
                      type="number"
                      min={0}
                      defaultValue={pack.price}
                      className={adminInput}
                    />
                  </Field>
                  <Field label="Sort order" htmlFor={`sort_${pack.id}`}>
                    <input
                      id={`sort_${pack.id}`}
                      name="sortOrder"
                      type="number"
                      min={0}
                      defaultValue={pack.sortOrder}
                      className={adminInput}
                    />
                  </Field>
                </div>
                <div className="flex flex-wrap gap-3">
                  <Toggle name="popular" label="Most popular" defaultChecked={pack.popular} />
                  <Toggle name="enabled" label="Enabled" defaultChecked={pack.enabled} />
                </div>
                <input type="hidden" name="currency" value={pack.currency} />

                <LocaleTabs
                  panels={locales.map((locale) => {
                    const row = pack.translations.find((item) => item.locale === locale);
                    return {
                      locale,
                      node: (
                        <div className="grid gap-4">
                          <Field label={`Name (${locale})`} htmlFor={`name_${locale}_${pack.id}`}>
                            <input
                              id={`name_${locale}_${pack.id}`}
                              name={`name_${locale}`}
                              defaultValue={row?.name ?? ""}
                              className={adminInput}
                            />
                          </Field>
                          <Field
                            label={`Description (${locale})`}
                            htmlFor={`description_${locale}_${pack.id}`}
                          >
                            <textarea
                              id={`description_${locale}_${pack.id}`}
                              name={`description_${locale}`}
                              rows={3}
                              defaultValue={row?.description ?? ""}
                              className={adminTextarea}
                            />
                          </Field>
                          <Field
                            label={`Included features (${locale}) — one per line`}
                            htmlFor={`features_${locale}_${pack.id}`}
                          >
                            <textarea
                              id={`features_${locale}_${pack.id}`}
                              name={`features_${locale}`}
                              rows={6}
                              defaultValue={(row?.features ?? []).join("\n")}
                              className={adminTextarea}
                            />
                          </Field>
                          <div className="grid gap-4 sm:grid-cols-2">
                            <Field
                              label={`Delivery (${locale})`}
                              htmlFor={`delivery_${locale}_${pack.id}`}
                            >
                              <input
                                id={`delivery_${locale}_${pack.id}`}
                                name={`deliveryTime_${locale}`}
                                defaultValue={row?.deliveryTime ?? ""}
                                className={adminInput}
                              />
                            </Field>
                            <Field
                              label={`Revisions (${locale})`}
                              htmlFor={`revisions_${locale}_${pack.id}`}
                            >
                              <input
                                id={`revisions_${locale}_${pack.id}`}
                                name={`revisions_${locale}`}
                                defaultValue={row?.revisions ?? ""}
                                className={adminInput}
                              />
                            </Field>
                          </div>
                        </div>
                      ),
                    };
                  })}
                />

                <AdminButton type="submit">Save package</AdminButton>
              </form>
            </AdminCard>
          ))}
        </div>
      )}
    </div>
  );
}
