import { AdminButton, AdminCard, Alert, Field, Toggle, adminInput, adminTextarea } from "@/components/admin/ui";
import { ImageField } from "@/components/admin/form-controls";
import { saveSettingsAction } from "@/app/admin/actions";
import { getSettings } from "@/lib/settings";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Settings · Admin" };

export default async function AdminSettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  await requireAdminPage();
  const { saved } = await searchParams;
  const settings = await getSettings();

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Website settings</h1>
        <p className="mt-1 text-sm text-slate-400">
          Contact details, social profiles, SEO metadata and feature switches used across the site.
        </p>
      </header>

      {saved ? <Alert tone="success">Settings saved.</Alert> : null}

      <form action={saveSettingsAction} className="flex flex-col gap-6">
        <AdminCard title="Contact details" description="Used by every WhatsApp and email button.">
          <div className="grid gap-5 md:grid-cols-2">
            <Field label="Contact email" htmlFor="setting_contactEmail">
              <input
                id="setting_contactEmail"
                name="setting_contactEmail"
                type="email"
                defaultValue={settings.contactEmail}
                className={adminInput}
              />
            </Field>
            <Field
              label="WhatsApp number"
              htmlFor="setting_whatsappNumber"
              hint="International format, digits only or with +."
            >
              <input
                id="setting_whatsappNumber"
                name="setting_whatsappNumber"
                defaultValue={settings.whatsappNumber}
                className={adminInput}
              />
            </Field>
            <Field label="Location label" htmlFor="setting_locationLabel">
              <input
                id="setting_locationLabel"
                name="setting_locationLabel"
                defaultValue={settings.locationLabel}
                className={adminInput}
              />
            </Field>
            <Field label="Availability label" htmlFor="setting_availabilityLabel">
              <input
                id="setting_availabilityLabel"
                name="setting_availabilityLabel"
                defaultValue={settings.availabilityLabel}
                className={adminInput}
              />
            </Field>
          </div>
        </AdminCard>

        <AdminCard title="Branding & images" description="Avatar and social sharing artwork.">
          <div className="grid gap-5 md:grid-cols-2">
            <ImageField
              name="setting_avatarUrl"
              label="Developer avatar"
              defaultValue={settings.avatarUrl}
              hint="Custom illustrated avatar shown in the hero and about page."
            />
            <ImageField
              name="setting_ogImageUrl"
              label="Open Graph image"
              defaultValue={settings.ogImageUrl}
              hint="Used for social media previews (1200×630 recommended)."
            />
          </div>
        </AdminCard>

        <AdminCard title="SEO & metadata" description="Applied to metadata, sitemap and robots.txt.">
          <div className="flex flex-col gap-5">
            <Field label="Site URL" htmlFor="setting_siteUrl" hint="Used as canonical base for the sitemap.">
              <input
                id="setting_siteUrl"
                name="setting_siteUrl"
                defaultValue={settings.siteUrl}
                className={adminInput}
              />
            </Field>
            <Field label="SEO keywords (comma separated)" htmlFor="setting_seoKeywords">
              <textarea
                id="setting_seoKeywords"
                name="setting_seoKeywords"
                rows={3}
                defaultValue={settings.seoKeywords}
                className={adminTextarea}
              />
            </Field>
            <Field
              label="Analytics measurement ID (optional)"
              htmlFor="setting_analyticsId"
              hint="Example: G-XXXXXXX. Requires a Google Analytics property."
            >
              <input
                id="setting_analyticsId"
                name="setting_analyticsId"
                defaultValue={settings.analyticsId}
                className={adminInput}
              />
            </Field>
          </div>
        </AdminCard>

        <AdminCard title="Social profiles" description="Empty links are hidden automatically.">
          <div className="grid gap-5 md:grid-cols-2">
            <Field label="GitHub" htmlFor="setting_socialGithub">
              <input
                id="setting_socialGithub"
                name="setting_socialGithub"
                defaultValue={settings.socialGithub}
                className={adminInput}
              />
            </Field>
            <Field label="LinkedIn" htmlFor="setting_socialLinkedin">
              <input
                id="setting_socialLinkedin"
                name="setting_socialLinkedin"
                defaultValue={settings.socialLinkedin}
                className={adminInput}
              />
            </Field>
            <Field label="Instagram" htmlFor="setting_socialInstagram">
              <input
                id="setting_socialInstagram"
                name="setting_socialInstagram"
                defaultValue={settings.socialInstagram}
                className={adminInput}
              />
            </Field>
            <Field label="X / Twitter" htmlFor="setting_socialX">
              <input
                id="setting_socialX"
                name="setting_socialX"
                defaultValue={settings.socialX}
                className={adminInput}
              />
            </Field>
          </div>
        </AdminCard>

        <AdminCard title="Feature switches" description="Turn public sections on or off.">
          <div className="flex flex-wrap gap-3">
            <input type="hidden" name="setting_featurePricing" value="0" />
            <Toggle
              name="setting_featurePricing"
              label="Show pricing values"
              defaultChecked={settings.featurePricing !== "0"}
            />
            <input type="hidden" name="setting_featureFaq" value="0" />
            <Toggle
              name="setting_featureFaq"
              label="Show FAQ page"
              defaultChecked={settings.featureFaq !== "0"}
            />
            <input type="hidden" name="setting_featureWhatsAppFloat" value="0" />
            <Toggle
              name="setting_featureWhatsAppFloat"
              label="Show floating WhatsApp button"
              defaultChecked={settings.featureWhatsAppFloat !== "0"}
            />
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Toggles submit the value “on” when enabled. Save once after changing them to persist the
            new state.
          </p>
        </AdminCard>

        <div className="sticky bottom-4 flex justify-end">
          <AdminButton type="submit">Save settings</AdminButton>
        </div>
      </form>
    </div>
  );
}
