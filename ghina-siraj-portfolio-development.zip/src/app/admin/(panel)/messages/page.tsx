import Link from "next/link";
import { Mail, MessageCircle, Trash2 } from "lucide-react";
import { AdminButton, AdminCard, AdminLink, Alert, LocaleBadge } from "@/components/admin/ui";
import { deleteMessageAction, markMessageAction } from "@/app/admin/actions";
import { getContactMessages } from "@/lib/data";
import { formatDate } from "@/lib/cn";
import { mailtoLink, whatsappLink } from "@/lib/settings";
import { getServiceTitle } from "@/lib/admin-helpers";
import { requireAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Messages · Admin" };

export default async function AdminMessagesPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; deleted?: string }>;
}) {
  await requireAdminPage();
  const { id, deleted } = await searchParams;
  const messages = await getContactMessages(200);
  const detailId = id ? Number.parseInt(id, 10) : 0;
  const selected = detailId > 0 ? messages.find((message) => message.id === detailId) : undefined;
  const serviceMap = await getServiceTitle();

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Contact messages</h1>
        <p className="mt-1 text-sm text-slate-400">
          Every website submission is stored in PostgreSQL with its submission date.
        </p>
      </header>

      {deleted ? <Alert tone="info">Message deleted.</Alert> : null}

      {selected ? (
        <AdminCard
          title={`Message #${selected.id}`}
          description={`${selected.name} · ${selected.email}`}
          actions={<AdminLink href="/admin/messages" variant="secondary">Close</AdminLink>}
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm">
              <p className="text-slate-500">Submitted</p>
              <p className="text-white">{formatDate(selected.submittedAt, "en")}</p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm">
              <p className="text-slate-500">Language</p>
              <p className="text-white">{selected.locale.toUpperCase()}</p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm">
              <p className="text-slate-500">Service</p>
              <p className="text-white">
                {selected.service ? serviceMap[selected.service] ?? selected.service : "—"}
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm">
              <p className="text-slate-500">Budget</p>
              <p className="text-white">{selected.budget || "—"}</p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm sm:col-span-2">
              <p className="text-slate-500">Message</p>
              <p className="mt-1 whitespace-pre-line text-white">{selected.message}</p>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <a
              href={whatsappLink(
                selected.phone || "",
                `Hello ${selected.name}, thank you for your message about ${
                  selected.service ? serviceMap[selected.service] ?? selected.service : "your project"
                }.`,
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#1faa53] px-4 text-sm font-medium text-white"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Reply on WhatsApp
            </a>
            <a
              href={mailtoLink(
                selected.email,
                `Re: your project request (${selected.service ?? "website"})`,
              )}
              className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 text-sm text-slate-200"
            >
              <Mail className="h-4 w-4" aria-hidden />
              Reply by email
            </a>
            <form action={markMessageAction}>
              <input type="hidden" name="id" value={selected.id} />
              <input type="hidden" name="status" value={selected.status === "new" ? "read" : "new"} />
              <AdminButton type="submit" variant="secondary">
                Mark as {selected.status === "new" ? "read" : "unread"}
              </AdminButton>
            </form>
            <form action={deleteMessageAction}>
              <input type="hidden" name="id" value={selected.id} />
              <AdminButton type="submit" variant="danger">
                <Trash2 className="h-4 w-4" aria-hidden />
                Delete
              </AdminButton>
            </form>
          </div>
        </AdminCard>
      ) : null}

      <AdminCard title={`Inbox (${messages.length})`}>
        {messages.length === 0 ? (
          <p className="text-sm text-slate-400">No messages yet.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-slate-800">
            {messages.map((message) => (
              <li key={message.id} className="flex flex-wrap items-center gap-4 py-4">
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-white">
                    {message.name}
                    <LocaleBadge locale={message.locale} />
                    {message.status === "new" ? (
                      <span className="rounded-md bg-sky-500/15 px-2 py-0.5 text-[10px] uppercase tracking-widest text-sky-300">
                        new
                      </span>
                    ) : null}
                  </p>
                  <p className="mt-1 line-clamp-1 text-xs text-slate-500">
                    {message.service ? serviceMap[message.service] ?? message.service : "—"} ·{" "}
                    {message.message}
                  </p>
                  <p className="mt-1 text-xs text-slate-600">
                    {message.email} · {formatDate(message.submittedAt, "en")}
                  </p>
                </div>
                <Link
                  href={`/admin/messages?id=${message.id}`}
                  className="text-sm text-sky-400 transition hover:text-sky-300"
                >
                  Read
                </Link>
                <form action={markMessageAction}>
                  <input type="hidden" name="id" value={message.id} />
                  <input type="hidden" name="status" value={message.status === "new" ? "read" : "new"} />
                  <AdminButton type="submit" variant="secondary">
                    {message.status === "new" ? "Mark read" : "Mark unread"}
                  </AdminButton>
                </form>
                <form action={deleteMessageAction}>
                  <input type="hidden" name="id" value={message.id} />
                  <AdminButton type="submit" variant="danger">
                    <Trash2 className="h-4 w-4" aria-hidden />
                    Delete
                  </AdminButton>
                </form>
              </li>
            ))}
          </ul>
        )}
      </AdminCard>
    </div>
  );
}
