import { Card, Pill, SectionHeading } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { Code2, Database, Palette, Wrench } from "lucide-react";
import { getSkills, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import type { LucideIcon } from "lucide-react";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.skillsTitle, description: dict.skills.subtitle };
}

const CATEGORY_ICONS: Record<string, LucideIcon> = {
  frontend: Code2,
  backend: Database,
  tools: Wrench,
  design: Palette,
};

const CATEGORY_ORDER = ["frontend", "backend", "tools", "design"] as const;

export default async function SkillsPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict } = await loadLocaleData(locale);
  const skills = await getSkills();

  const grouped = CATEGORY_ORDER.map((category) => ({
    category,
    items: skills.filter((skill) => skill.category === category),
  })).filter((group) => group.items.length > 0);

  return (
    <>
      <PageHeader eyebrow={dict.nav.skills} title={dict.skills.title} subtitle={dict.skills.subtitle} />

      <section className="container-page py-12">
        <div className="grid gap-6 lg:grid-cols-2">
          {grouped.map((group, index) => {
            const Icon = CATEGORY_ICONS[group.category] ?? Code2;
            const label =
              dict.skills.categories[group.category as keyof typeof dict.skills.categories] ??
              group.category;
            const description =
              dict.skills.categoryDescriptions[
                group.category as keyof typeof dict.skills.categoryDescriptions
              ] ?? "";
            return (
              <Reveal key={group.category} delay={index * 80}>
                <Card className="h-full">
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-xl border border-accent/20 bg-accent/10 text-accent">
                      <Icon className="h-5 w-5" aria-hidden />
                    </span>
                    <div>
                      <h2 className="text-lg font-semibold text-white">{label}</h2>
                      <p className="text-xs text-muted">{description}</p>
                    </div>
                  </div>
                  <ul className="mt-6 flex flex-col gap-4">
                    {group.items.map((skill) => (
                      <li key={skill.id}>
                        <div className="flex items-center justify-between gap-3 text-sm">
                          <span className="text-white/90">{skill.name}</span>
                          <span className="text-xs text-muted">
                            {skill.level > 0 ? `${skill.level}%` : ""}
                          </span>
                        </div>
                        {skill.level > 0 ? (
                          <div
                            className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]"
                            role="img"
                            aria-label={`${skill.name} ${dict.skills.proficiency} ${skill.level}%`}
                          >
                            <span
                              className="block h-full rounded-full bg-gradient-to-r from-brand to-accent"
                              style={{ width: `${skill.level}%` }}
                            />
                          </div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                </Card>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={120}>
          <div className="mt-10 flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-6 text-center">
            <Pill>{dict.nav.skills}</Pill>
            <p className="max-w-2xl text-sm text-muted">{dict.skills.learningNote}</p>
          </div>
        </Reveal>
      </section>

      <section className="container-page py-12">
        <SectionHeading title={dict.home.ctaTitle} subtitle={dict.home.ctaText} />
        <div className="mt-8 flex justify-center">
          <a
            href={`/${locale}/services`}
            className="inline-flex h-12 items-center rounded-full bg-gradient-to-r from-brand to-accent px-7 text-sm font-medium text-white transition hover:-translate-y-0.5"
          >
            {dict.home.ctaServices}
          </a>
        </div>
      </section>
    </>
  );
}
