import Link from "next/link";
import { Info } from "lucide-react";
import { PackageCard } from "@/components/site/cards";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { SectionHeading, buttonClass } from "@/components/ui/kit";
import { getPackages, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { whatsappLink } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.pricingTitle, description: dict.pricing.subtitle };
}

export default async function PricingPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict, settings } = await loadLocaleData(locale);
  const packages = await getPackages(locale);

  return (
    <>
      <PageHeader eyebrow={dict.nav.pricing} title={dict.pricing.title} subtitle={dict.pricing.subtitle} />

      <section className="container-page py-12">
        <Reveal>
          <div className="mx-auto mb-10 flex max-w-3xl items-start gap-3 rounded-2xl border border-accent/20 bg-accent/[0.06] p-4 text-sm text-muted">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden />
            <p>{dict.pricing.exampleNote}</p>
          </div>
        </Reveal>

        {packages.length > 0 ? (
          <div className="grid gap-6 lg:grid-cols-3">
            {packages.map((pack, index) => (
              <Reveal key={pack.id} delay={index * 80}>
                <PackageCard
                  dict={dict}
                  pack={pack}
                  whatsappHref={whatsappLink(
                    settings.whatsappNumber,
                    `${dict.common.getQuote}: ${pack.name}`,
                  )}
                  contactHref={`/${locale}/contact`}
                />
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-12 text-center text-muted">
            {dict.pricing.customText}
          </div>
        )}
      </section>

      <section className="container-page py-16">
        <Reveal>
          <SectionHeading title={dict.pricing.customTitle} subtitle={dict.pricing.customText} />
        </Reveal>
        <Reveal delay={100}>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a
              href={whatsappLink(settings.whatsappNumber, dict.whatsapp.quotePrefill)}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonClass("primary", "lg")}
            >
              {dict.common.getQuote}
            </a>
            <Link href={`/${locale}/contact`} className={buttonClass("secondary", "lg")}>
              {dict.common.contactMe}
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
