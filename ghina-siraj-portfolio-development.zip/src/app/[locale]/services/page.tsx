import Link from "next/link";
import { ArrowRight, Check, Clock, MessageCircle } from "lucide-react";
import { Card, Pill } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { ServiceIcon } from "@/components/site/service-icon";
import { buttonClass } from "@/components/ui/kit";
import { getServices, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { formatPrice, whatsappLink } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.servicesTitle, description: dict.services.subtitle };
}

export default async function ServicesPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict, settings } = await loadLocaleData(locale);
  const services = await getServices(locale);

  return (
    <>
      <PageHeader eyebrow={dict.nav.services} title={dict.services.title} subtitle={dict.services.subtitle} />

      <section className="container-page py-12">
        {services.length === 0 ? (
          <Card className="text-center">
            <h2 className="text-lg font-semibold text-white">{dict.services.emptyTitle}</h2>
            <p className="mt-2 text-sm text-muted">{dict.services.emptyText}</p>
          </Card>
        ) : (
          <div className="grid gap-6 lg:grid-cols-2">
            {services.map((service, index) => (
              <Reveal key={service.id} delay={index * 60}>
                <Card className="flex h-full flex-col gap-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className="grid h-12 w-12 place-items-center rounded-xl border border-accent/20 bg-accent/10 text-accent">
                        <ServiceIcon name={service.icon} className="h-6 w-6" />
                      </span>
                      <div>
                        <h2 className="text-lg font-semibold text-white">{service.title}</h2>
                        <span className="text-xs text-muted">
                          {dict.common.startingAt} {formatPrice(service.startingPrice, service.currency)}
                        </span>
                      </div>
                    </div>
                    {service.deliveryTime ? (
                      <span className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[11px] text-muted sm:inline-flex">
                        <Clock className="h-3.5 w-3.5 text-accent" aria-hidden />
                        {service.deliveryTime}
                      </span>
                    ) : null}
                  </div>

                  <p className="text-sm leading-relaxed text-muted">{service.summary}</p>

                  <ul className="grid gap-2 sm:grid-cols-2">
                    {service.features.slice(0, 4).map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-muted">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-auto flex flex-wrap gap-2 border-t border-white/8 pt-5">
                    <a
                      href={whatsappLink(
                        settings.whatsappNumber,
                        `${dict.services.requestText}${service.title}`,
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={buttonClass("primary", "sm")}
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden />
                      {dict.services.quoteCta}
                    </a>
                    <Link href={`/${locale}/services/${service.slug}`} className={buttonClass("secondary", "sm")}>
                      {dict.common.learnMore}
                      <ArrowRight className="h-4 w-4 flip-x" aria-hidden />
                    </Link>
                    <Link href={`/${locale}/contact`} className={buttonClass("ghost", "sm")}>
                      {dict.services.contactCta}
                    </Link>
                  </div>
                </Card>
              </Reveal>
            ))}
          </div>
        )}
      </section>

      <section className="container-page pb-20">
        <Reveal>
          <div className="flex flex-col items-center gap-4 rounded-3xl border border-accent/20 bg-gradient-to-br from-brand/20 via-surface-2/70 to-surface p-10 text-center">
            <Pill>{dict.common.getQuote}</Pill>
            <h2 className="text-2xl font-semibold text-white sm:text-3xl">{dict.pricing.customTitle}</h2>
            <p className="max-w-2xl text-sm text-muted">{dict.pricing.customText}</p>
            <Link href={`/${locale}/contact`} className={buttonClass("primary", "lg")}>
              {dict.common.contactMe}
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
