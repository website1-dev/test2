import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Check, Clock, MessageCircle, Sparkles, TrendingUp } from "lucide-react";
import { Card, Pill, buttonClass } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { ServiceIcon } from "@/components/site/service-icon";
import { getServiceBySlug, getServices, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { formatPrice, whatsappLink } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>;
}) {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  const { dict } = await loadLocaleData(locale);
  const service = await getServiceBySlug(slug, locale);
  if (!service) return { title: dict.notFound.title };
  return {
    title: service.title,
    description: service.summary || service.description.slice(0, 160),
    openGraph: { title: service.title, description: service.summary },
  };
}

export default async function ServiceDetailPage({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>;
}) {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  const { dict, settings } = await loadLocaleData(locale);
  const [service, all] = await Promise.all([
    getServiceBySlug(slug, locale),
    getServices(locale),
  ]);
  if (!service) notFound();

  const others = all.filter((item) => item.slug !== service.slug).slice(0, 4);
  const quoteHref = whatsappLink(settings.whatsappNumber, `${dict.services.requestText}${service.title}`);

  return (
    <>
      <section className="relative overflow-hidden pt-36 pb-10">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-80 bg-[radial-gradient(55%_100%_at_50%_0%,rgba(37,99,235,0.3),transparent_70%)]"
          aria-hidden
        />
        <div className="container-page relative flex flex-col items-center gap-5 text-center">
          <span className="grid h-16 w-16 place-items-center rounded-2xl border border-accent/25 bg-accent/10 text-accent">
            <ServiceIcon name={service.icon} className="h-8 w-8" />
          </span>
          <Pill>{dict.nav.services}</Pill>
          <h1 className="max-w-3xl text-3xl font-semibold leading-tight tracking-tight text-white sm:text-5xl">
            {service.title}
          </h1>
          <p className="max-w-2xl text-base leading-relaxed text-muted sm:text-lg">{service.summary}</p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a href={quoteHref} target="_blank" rel="noopener noreferrer" className={buttonClass("primary", "lg")}>
              <MessageCircle className="h-5 w-5" aria-hidden />
              {dict.services.quoteCta}
            </a>
            <Link href={`/${locale}/contact`} className={buttonClass("secondary", "lg")}>
              {dict.services.contactCta}
            </Link>
          </div>
        </div>
      </section>

      <section className="container-page grid gap-6 py-12 lg:grid-cols-[1.4fr_0.6fr]">
        <Reveal>
          <Card className="h-full">
            <h2 className="text-xl font-semibold text-white">{dict.services.detailsTitle}</h2>
            <p className="mt-4 whitespace-pre-line text-base leading-relaxed text-muted">
              {service.description}
            </p>

            {service.features.length > 0 ? (
              <div className="mt-8">
                <h3 className="text-sm font-semibold uppercase tracking-widest text-accent">
                  {dict.services.featuresLabel}
                </h3>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-sm text-muted">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {service.benefits.length > 0 ? (
              <div className="mt-8">
                <h3 className="text-sm font-semibold uppercase tracking-widest text-accent">
                  {dict.services.benefitsLabel}
                </h3>
                <ul className="mt-4 grid gap-3">
                  {service.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2.5 text-sm text-muted">
                      <TrendingUp className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Card>
        </Reveal>

        <Reveal delay={100}>
          <Card className="sticky top-28 h-fit">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted">
              {dict.services.priceLabel}
            </h3>
            <p className="mt-2 text-3xl font-semibold text-white">
              {formatPrice(service.startingPrice, service.currency)}
            </p>
            {service.deliveryTime ? (
              <p className="mt-4 flex items-center gap-2 text-sm text-muted">
                <Clock className="h-4 w-4 text-accent" aria-hidden />
                <span>
                  <span className="text-white/90">{dict.services.deliveryLabel}:</span>{" "}
                  {service.deliveryTime}
                </span>
              </p>
            ) : null}
            <a
              href={quoteHref}
              target="_blank"
              rel="noopener noreferrer"
              className={`${buttonClass("primary", "md")} mt-6 w-full`}
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              {dict.services.quoteCta}
            </a>
            <a
              href={`mailto:${settings.contactEmail}?subject=${encodeURIComponent(service.title)}`}
              className={`${buttonClass("secondary", "sm")} mt-2 w-full`}
            >
              {dict.common.email}
            </a>
            <p className="mt-4 text-xs leading-relaxed text-muted">{dict.common.placeholderNote}</p>
          </Card>
        </Reveal>
      </section>

      {others.length > 0 ? (
        <section className="container-page py-12">
          <h2 className="text-2xl font-semibold text-white">{dict.services.otherTitle}</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {others.map((item, index) => (
              <Reveal key={item.id} delay={index * 60}>
                <Link
                  href={`/${locale}/services/${item.slug}`}
                  className="group flex h-full flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-5 transition hover:-translate-y-1 hover:border-accent/40"
                >
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent">
                    <ServiceIcon name={item.icon} className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-semibold text-white">{item.title}</span>
                  <span className="line-clamp-2 text-xs text-muted">{item.summary}</span>
                  <span className="mt-auto inline-flex items-center gap-1.5 text-xs text-accent">
                    {dict.common.learnMore}
                    <ArrowRight className="h-3.5 w-3.5 flip-x" aria-hidden />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
          <div className="mt-10 flex items-center justify-center gap-2 text-sm text-muted">
            <Sparkles className="h-4 w-4 text-accent" aria-hidden />
            {dict.pricing.exampleNote}
          </div>
        </section>
      ) : null}
    </>
  );
}
