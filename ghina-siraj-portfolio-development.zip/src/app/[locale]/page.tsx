import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Code2, Layers, MessageCircle, Sparkles } from "lucide-react";
import { ButtonLink, Card, Pill, SectionHeading } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PackageCard, ProjectCard, ServiceCard, StatCard } from "@/components/site/cards";
import { getProjects, getServices, getSkills, loadLocaleData } from "@/lib/data";
import { whatsappLink } from "@/lib/settings";
import { dirFor } from "@/lib/i18n/config";
import { toLocale } from "@/lib/params";

export const dynamic = "force-dynamic";

export default async function HomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  const locale = toLocale(raw);
  const { dict, settings } = await loadLocaleData(locale);
  const [services, projects, skills] = await Promise.all([
    getServices(locale),
    getProjects(locale, { featuredOnly: true, limit: 3 }),
    getSkills(),
  ]);
  const rtl = dirFor(locale) === "rtl";
  const categories = Array.from(new Set(skills.map((skill) => skill.category)));

  return (
    <>
      {/* ------------------------------- hero ------------------------------- */}
      <section className="relative overflow-hidden pt-32 pb-20 sm:pt-40">
        <div
          className="pointer-events-none absolute -start-32 top-24 h-80 w-80 rounded-full bg-brand/25 blur-[120px]"
          aria-hidden
        />
        <div
          className="pointer-events-none absolute -end-24 top-10 h-96 w-96 rounded-full bg-accent/15 blur-[130px]"
          aria-hidden
        />
        <div className="container-page grid items-center gap-14 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="flex flex-col items-start gap-6">
            <Reveal>
              <Pill>
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                {dict.home.badge}
              </Pill>
            </Reveal>
            <Reveal delay={80}>
              <p className="text-sm uppercase tracking-[0.3em] text-accent">{dict.home.greeting}</p>
            </Reveal>
            <Reveal delay={140}>
              <h1 className="text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
                {dict.home.name}
              </h1>
            </Reveal>
            <Reveal delay={200}>
              <p className="max-w-xl text-xl font-medium leading-snug gradient-text sm:text-2xl">
                {dict.home.tagline}
              </p>
            </Reveal>
            <Reveal delay={260}>
              <p className="max-w-xl text-base leading-relaxed text-muted">{dict.home.intro}</p>
            </Reveal>
            <Reveal delay={320}>
              <div className="flex flex-wrap items-center gap-3">
                <ButtonLink href={`/${locale}/projects`} size="lg">
                  {dict.home.ctaProjects}
                  <ArrowRight className={rtl ? "h-4 w-4 rotate-180" : "h-4 w-4"} aria-hidden />
                </ButtonLink>
                <ButtonLink href={`/${locale}/services`} variant="secondary" size="lg">
                  {dict.home.ctaServices}
                </ButtonLink>
                <ButtonLink href={`/${locale}/contact`} variant="ghost" size="lg">
                  {dict.home.ctaContact}
                </ButtonLink>
              </div>
            </Reveal>
            <Reveal delay={380}>
              <div className="mt-2 grid w-full gap-3 sm:grid-cols-4">
                <StatCard value="3" label={dict.common.yearsExperience} />
                <StatCard value={String(services.length)} label={dict.common.servicesLabel} />
                <StatCard value={String(projects.length)} label={dict.common.projectsLabel} />
                <StatCard value="3" label={dict.common.languagesLabel} />
              </div>
            </Reveal>
          </div>

          <Reveal delay={200} className="relative mx-auto w-full max-w-sm">
            <div
              className="absolute inset-0 -z-10 animate-float-slow rounded-[2.5rem] bg-gradient-to-br from-brand/40 via-accent/20 to-transparent blur-2xl"
              aria-hidden
            />
            <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-surface/70 p-6 backdrop-blur-xl">
              <div
                className="absolute -top-24 start-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-accent/25 blur-3xl"
                aria-hidden
              />
              <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-base">
                <Image
                  src={settings.avatarUrl || "/images/avatar.png"}
                  alt={`${dict.home.name} — ${dict.meta.siteTitle}`}
                  width={480}
                  height={480}
                  priority
                  sizes="(max-width: 1024px) 80vw, 380px"
                  className="h-auto w-full object-cover"
                />
              </div>
              <div className="mt-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/15 text-accent">
                  <Code2 className="h-5 w-5" aria-hidden />
                </span>
                <div className="flex flex-col leading-tight">
                  <span className="text-sm font-medium text-white">
                    {dict.common.availability}
                  </span>
                  <span className="text-xs text-muted">{settings.locationLabel}</span>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ----------------------------- services ----------------------------- */}
      <section className="container-page py-20" id="services">
        <Reveal>
          <SectionHeading
            eyebrow={dict.nav.services}
            title={dict.home.servicesTitle}
            subtitle={dict.home.servicesSubtitle}
          />
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 6).map((service, index) => (
            <Reveal key={service.id} delay={index * 70}>
              <ServiceCard locale={locale} dict={dict} service={service} />
            </Reveal>
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <ButtonLink href={`/${locale}/services`} variant="secondary" size="lg">
            {dict.common.viewAll}
            <ArrowRight className={rtl ? "h-4 w-4 rotate-180" : "h-4 w-4"} aria-hidden />
          </ButtonLink>
        </div>
      </section>

      {/* ----------------------------- projects ----------------------------- */}
      <section className="container-page py-20" id="projects">
        <Reveal>
          <SectionHeading
            eyebrow={dict.nav.projects}
            title={dict.home.projectsTitle}
            subtitle={dict.home.projectsSubtitle}
          />
        </Reveal>
        {projects.length > 0 ? (
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((project, index) => (
              <Reveal key={project.id} delay={index * 80}>
                <ProjectCard locale={locale} dict={dict} project={project} />
              </Reveal>
            ))}
          </div>
        ) : (
          <Card className="mt-12 text-center">
            <h3 className="text-lg font-semibold text-white">{dict.projects.emptyTitle}</h3>
            <p className="mt-2 text-sm text-muted">{dict.projects.emptyText}</p>
          </Card>
        )}
        <div className="mt-10 flex justify-center">
          <ButtonLink href={`/${locale}/projects`} variant="secondary" size="lg">
            {dict.common.viewAll}
            <ArrowRight className={rtl ? "h-4 w-4 rotate-180" : "h-4 w-4"} aria-hidden />
          </ButtonLink>
        </div>
      </section>

      {/* ------------------------------ skills ------------------------------ */}
      <section className="container-page py-20">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <Reveal>
            <SectionHeading
              align="start"
              eyebrow={dict.nav.skills}
              title={dict.home.skillsTitle}
              subtitle={dict.home.skillsSubtitle}
            />
            <div className="mt-8 flex flex-wrap gap-2">
              {categories.map((category) => (
                <span
                  key={category}
                  className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs text-muted"
                >
                  {dict.skills.categories[category as keyof typeof dict.skills.categories]}
                </span>
              ))}
            </div>
            <div className="mt-8">
              <ButtonLink href={`/${locale}/skills`} variant="secondary">
                {dict.common.viewAll}
              </ButtonLink>
            </div>
          </Reveal>
          <div className="grid gap-4 sm:grid-cols-2">
            {skills.slice(0, 8).map((skill, index) => (
              <Reveal key={skill.id} delay={index * 50}>
                <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
                  <span className="text-sm text-white">{skill.name}</span>
                  <span className="text-xs text-accent">{skill.level}%</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------- why -------------------------------- */}
      <section className="container-page py-20">
        <Reveal>
          <SectionHeading title={dict.home.whyTitle} subtitle={dict.home.whySubtitle} />
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {dict.home.why.map((item, index) => (
            <Reveal key={item.title} delay={index * 70}>
              <Card className="h-full">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand/30 to-accent/20 text-accent">
                  <Layers className="h-5 w-5" aria-hidden />
                </span>
                <h3 className="mt-4 text-base font-semibold text-white">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------- cta -------------------------------- */}
      <section className="container-page py-20">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-accent/25 bg-gradient-to-br from-brand/25 via-surface-2/80 to-surface p-10 text-center sm:p-16">
            <div
              className="pointer-events-none absolute -top-24 start-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-accent/20 blur-3xl"
              aria-hidden
            />
            <h2 className="relative text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              {dict.home.ctaTitle}
            </h2>
            <p className="relative mx-auto mt-4 max-w-2xl text-base text-muted">
              {dict.home.ctaText}
            </p>
            <div className="relative mt-8 flex flex-wrap justify-center gap-3">
              <a
                href={whatsappLink(settings.whatsappNumber, dict.whatsapp.quotePrefill)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-13 items-center gap-2 rounded-full bg-gradient-to-r from-brand to-accent px-8 text-base font-medium text-white transition hover:-translate-y-0.5"
              >
                <MessageCircle className="h-5 w-5" aria-hidden />
                {dict.home.ctaButton}
              </a>
              <Link href={`/${locale}/contact`} className="inline-flex h-13 items-center rounded-full border border-white/15 bg-white/[0.04] px-8 text-base text-white transition hover:border-accent/50">
                {dict.common.contactMe}
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
