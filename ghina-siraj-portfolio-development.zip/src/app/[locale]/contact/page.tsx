import { Clock, Mail, MapPin, MessageCircle } from "lucide-react";
import { Card, Pill } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { ContactForm } from "@/components/site/contact-form";
import { getServices, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { mailtoLink, whatsappLink } from "@/lib/settings";
import { buttonClass } from "@/components/ui/kit";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.contactTitle, description: dict.contact.subtitle };
}

export default async function ContactPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict, settings } = await loadLocaleData(locale);
  const services = await getServices(locale);

  return (
    <>
      <PageHeader eyebrow={dict.nav.contact} title={dict.contact.title} subtitle={dict.contact.subtitle} />

      <section className="container-page grid gap-8 py-12 lg:grid-cols-[1.15fr_0.85fr]">
        <Reveal>
          <ContactForm
            locale={locale}
            dict={{
              formTitle: dict.contact.formTitle,
              name: dict.contact.name,
              namePlaceholder: dict.contact.namePlaceholder,
              email: dict.contact.email,
              emailPlaceholder: dict.contact.emailPlaceholder,
              phone: dict.contact.phone,
              phonePlaceholder: dict.contact.phonePlaceholder,
              service: dict.contact.service,
              servicePlaceholder: dict.contact.servicePlaceholder,
              budget: dict.contact.budget,
              budgetPlaceholder: dict.contact.budgetPlaceholder,
              message: dict.contact.message,
              messagePlaceholder: dict.contact.messagePlaceholder,
              submit: dict.contact.submit,
              sending: dict.contact.sending,
              successTitle: dict.contact.successTitle,
              successText: dict.contact.successText,
              errorTitle: dict.contact.errorTitle,
              errorText: dict.contact.errorText,
              validationName: dict.contact.validationName,
              validationEmail: dict.contact.validationEmail,
              validationMessage: dict.contact.validationMessage,
              validationService: dict.contact.validationService,
            }}
            services={services.map((service) => ({ slug: service.slug, title: service.title }))}
          />
        </Reveal>

        <div className="flex flex-col gap-5">
          <Reveal delay={80}>
            <Card className="flex flex-col gap-3">
              <Pill>{dict.contact.infoTitle}</Pill>
              <h2 className="text-lg font-semibold text-white">{dict.contact.whatsappTitle}</h2>
              <p className="text-sm leading-relaxed text-muted">{dict.contact.whatsappText}</p>
              <a
                href={whatsappLink(settings.whatsappNumber, dict.contact.whatsappPrefill)}
                target="_blank"
                rel="noopener noreferrer"
                className={buttonClass("whatsapp", "md", "mt-1")}
              >
                <MessageCircle className="h-4 w-4" aria-hidden />
                {settings.whatsappNumber}
              </a>
            </Card>
          </Reveal>

          <Reveal delay={130}>
            <Card className="flex flex-col gap-3">
              <h2 className="flex items-center gap-2 text-lg font-semibold text-white">
                <Mail className="h-5 w-5 text-accent" aria-hidden />
                {dict.contact.emailTitle}
              </h2>
              <p className="text-sm leading-relaxed text-muted">{dict.contact.emailText}</p>
              <a
                href={mailtoLink(settings.contactEmail, dict.meta.siteTitle)}
                className={`${buttonClass("secondary", "md")} break-all`}
              >
                {settings.contactEmail}
              </a>
            </Card>
          </Reveal>

          <Reveal delay={180}>
            <Card className="flex flex-col gap-3">
              <span className="flex items-center gap-2 text-sm text-muted">
                <MapPin className="h-4 w-4 text-accent" aria-hidden />
                {dict.contact.locationText}
              </span>
              <span className="flex items-center gap-2 text-sm text-muted">
                <Clock className="h-4 w-4 text-accent" aria-hidden />
                <span>
                  <strong className="text-white/90">{dict.contact.responseTitle}:</strong>{" "}
                  {dict.contact.responseText}
                </span>
              </span>
            </Card>
          </Reveal>
        </div>
      </section>
    </>
  );
}
