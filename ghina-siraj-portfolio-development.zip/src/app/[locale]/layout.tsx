import type { Metadata } from "next";
import type { ReactNode } from "react";
import { notFound } from "next/navigation";
import "@/app/globals.css";
import { dirFor, isLocale, locales, type Locale } from "@/lib/i18n/config";
import { ensureSeeded } from "@/lib/bootstrap";
import { loadLocaleData, getServices } from "@/lib/data";
import { whatsappLink } from "@/lib/settings";
import { Navbar } from "@/components/site/navbar";
import { Footer, WhatsAppFloat } from "@/components/site/footer";

export const dynamic = "force-dynamic";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale: raw } = await params;
  if (!isLocale(raw)) return {};
  const { dict, settings } = await loadLocaleData(raw);
  const siteUrl = settings.siteUrl?.startsWith("http") ? settings.siteUrl : undefined;
  return {
    metadataBase: siteUrl ? new URL(siteUrl) : undefined,
    title: {
      default: dict.meta.siteTitle,
      template: `%s · ${dict.home.name}`,
    },
    description: dict.meta.siteDescription,
    keywords: settings.seoKeywords?.split(",").map((k) => k.trim()).filter(Boolean),
    applicationName: dict.meta.siteTitle,
    authors: [{ name: dict.home.name }],
    creator: dict.home.name,
    alternates: {
      canonical: `/${raw}`,
      languages: Object.fromEntries(locales.map((l) => [l, `/${l}`])),
    },
    openGraph: {
      type: "website",
      title: dict.meta.siteTitle,
      description: dict.meta.siteDescription,
      locale: raw,
      alternateLocale: locales.filter((l) => l !== raw),
      images: settings.ogImageUrl ? [{ url: settings.ogImageUrl }] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title: dict.meta.siteTitle,
      description: dict.meta.siteDescription,
      images: settings.ogImageUrl ? [settings.ogImageUrl] : undefined,
    },
    robots: { index: true, follow: true },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw as Locale;
  await ensureSeeded();
  const { dict, settings } = await loadLocaleData(locale);
  const services = await getServices(locale);

  return (
    <html lang={locale} dir={dirFor(locale)} suppressHydrationWarning>
      <body id="top" className="min-h-screen overflow-x-hidden bg-base text-white antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-brand focus:px-4 focus:py-2 focus:text-sm focus:text-white"
        >
          {dict.nav.home}
        </a>
        <div className="pointer-events-none fixed inset-0 -z-10 grid-glow opacity-70" aria-hidden />
        <Navbar
          locale={locale}
          labels={dict.nav}
          whatsappHref={whatsappLink(settings.whatsappNumber, dict.contact.whatsappPrefill)}
          whatsappLabel={dict.common.getQuote}
        />
        <main id="main">{children}</main>
        <Footer
          locale={locale}
          dict={dict}
          settings={settings}
          services={services.map((service) => ({ slug: service.slug, title: service.title }))}
        />
        {settings.featureWhatsAppFloat !== "0" ? (
          <WhatsAppFloat
            href={whatsappLink(settings.whatsappNumber, dict.contact.whatsappPrefill)}
            label={dict.whatsapp.float}
          />
        ) : null}
      </body>
    </html>
  );
}
