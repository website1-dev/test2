import Image from "next/image";
import { CheckCircle2, Compass, Heart, Sparkles } from "lucide-react";
import { ButtonLink, Card, Pill, SectionHeading } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return {
    title: dict.meta.aboutTitle,
    description: dict.about.profileText.slice(0, 160),
  };
}

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict, settings } = await loadLocaleData(locale);

  return (
    <>
      <PageHeader eyebrow={dict.nav.about} title={dict.about.title} subtitle={dict.about.subtitle} />

      <section className="container-page py-12">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-surface/70 p-5">
              <div
                className="pointer-events-none absolute -top-20 start-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-accent/25 blur-3xl"
                aria-hidden
              />
              <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-base">
                <Image
                  src={settings.avatarUrl || "/images/avatar.png"}
                  alt={`${dict.home.name} illustrated avatar`}
                  width={480}
                  height={480}
                  sizes="(max-width: 1024px) 80vw, 320px"
                  className="h-auto w-full"
                />
              </div>
              <div className="mt-5 flex flex-col gap-2 text-sm">
                <span className="flex items-center gap-2 text-muted">
                  <Sparkles className="h-4 w-4 text-accent" aria-hidden />
                  {dict.about.experienceYears} {dict.about.experienceLabel}
                </span>
                <span className="flex items-center gap-2 text-muted">
                  <Compass className="h-4 w-4 text-accent" aria-hidden />
                  {settings.locationLabel}
                </span>
              </div>
              <div className="mt-5">
                <ButtonLink href={`/${locale}/contact`} className="w-full">
                  {dict.about.downloadCta}
                </ButtonLink>
              </div>
            </div>
          </Reveal>

          <div className="flex flex-col gap-8">
            <Reveal>
              <Card>
                <Pill>{dict.about.profileTitle}</Pill>
                <p className="mt-4 text-base leading-relaxed text-muted">{dict.about.profileText}</p>
              </Card>
            </Reveal>
            <Reveal delay={80}>
              <Card>
                <h2 className="text-xl font-semibold text-white">{dict.about.storyTitle}</h2>
                <p className="mt-3 text-base leading-relaxed text-muted">{dict.about.storyText}</p>
              </Card>
            </Reveal>
            <Reveal delay={140}>
              <Card>
                <h2 className="flex items-center gap-2 text-xl font-semibold text-white">
                  <Heart className="h-5 w-5 text-accent" aria-hidden />
                  {dict.about.interestsTitle}
                </h2>
                <p className="mt-3 text-base leading-relaxed text-muted">{dict.about.interestsText}</p>
              </Card>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="container-page py-16">
        <Reveal>
          <SectionHeading eyebrow={dict.about.highlightsTitle} title={dict.about.highlightsTitle} />
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {dict.about.highlights.map((item, index) => (
            <Reveal key={item.title} delay={index * 70}>
              <Card className="h-full">
                <h3 className="text-lg font-semibold text-white">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="container-page py-16">
        <Reveal>
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-surface-2/70 to-surface/90 p-8 sm:p-12">
            <h2 className="text-2xl font-semibold text-white sm:text-3xl">{dict.about.valuesTitle}</h2>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {dict.about.values.map((value, index) => (
                <Reveal as="li" key={value} delay={index * 60}>
                  <span className="flex items-start gap-3 text-sm leading-relaxed text-muted">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden />
                    {value}
                  </span>
                </Reveal>
              ))}
            </ul>
          </div>
        </Reveal>
      </section>
    </>
  );
}
