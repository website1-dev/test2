"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { dictionaries, isLocale } from "@/lib/i18n";

export default function LocaleNotFound() {
  const pathname = usePathname() || "";
  const segment = pathname.split("/")[1];
  const locale = isLocale(segment) ? segment : "en";
  const dict = dictionaries[locale];

  return (
    <section className="container-page flex min-h-[70vh] flex-col items-center justify-center gap-6 py-32 text-center">
      <span className="text-7xl font-semibold gradient-text">404</span>
      <h1 className="text-3xl font-semibold text-white sm:text-4xl">{dict.notFound.title}</h1>
      <p className="max-w-md text-base text-muted">{dict.notFound.text}</p>
      <Link
        href={`/${locale}`}
        className="inline-flex h-12 items-center gap-2 rounded-full bg-gradient-to-r from-brand to-accent px-7 text-sm font-medium text-white transition hover:-translate-y-0.5"
      >
        <ArrowLeft className="h-4 w-4 flip-x" aria-hidden />
        {dict.notFound.cta}
      </Link>
    </section>
  );
}
