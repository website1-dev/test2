import { HelpCircle } from "lucide-react";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { SectionHeading, buttonClass } from "@/components/ui/kit";
import { getFaqs, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { whatsappLink } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.faqTitle, description: dict.faq.subtitle };
}

export default async function FaqPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = toLocale((await params).locale);
  const { dict, settings } = await loadLocaleData(locale);
  const items = await getFaqs(locale);

  return (
    <>
      <PageHeader eyebrow={dict.nav.faq} title={dict.faq.title} subtitle={dict.faq.subtitle} />

      <section className="container-page py-12">
        {items.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-12 text-center">
            <h2 className="text-lg font-semibold text-white">{dict.faq.emptyTitle}</h2>
            <p className="mt-2 text-sm text-muted">{dict.faq.stillText}</p>
          </div>
        ) : (
          <Reveal>
            <div className="mx-auto max-w-3xl">
              <FaqAccordion items={items} />
            </div>
          </Reveal>
        )}
      </section>

      <section className="container-page py-16">
        <Reveal>
          <SectionHeading title={dict.faq.stillTitle} subtitle={dict.faq.stillText} />
        </Reveal>
        <Reveal delay={80}>
          <div className="mt-8 flex justify-center">
            <a
              href={whatsappLink(settings.whatsappNumber, dict.contact.whatsappPrefill)}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonClass("whatsapp", "lg")}
            >
              <HelpCircle className="h-5 w-5" aria-hidden />
              {dict.contact.whatsappCta}
            </a>
          </div>
        </Reveal>
      </section>
    </>
  );
}
