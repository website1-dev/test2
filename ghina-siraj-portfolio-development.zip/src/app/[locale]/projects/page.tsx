import Link from "next/link";
import { FolderOpen } from "lucide-react";
import { Card, Pill } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { PageHeader } from "@/components/site/page-header";
import { ProjectCard } from "@/components/site/cards";
import { CATEGORY_KEYS, getProjects, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";
import { cn } from "@/lib/cn";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const { dict } = await loadLocaleData(toLocale(locale));
  return { title: dict.meta.projectsTitle, description: dict.projects.subtitle };
}

export default async function ProjectsPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ category?: string }>;
}) {
  const { locale: rawLocale } = await params;
  const locale = toLocale(rawLocale);
  const { category } = await searchParams;
  const { dict } = await loadLocaleData(locale);
  const all = await getProjects(locale);
  const projects =
    category && CATEGORY_KEYS.includes(category as never)
      ? all.filter((project) => project.category === category)
      : all;

  return (
    <>
      <PageHeader eyebrow={dict.nav.projects} title={dict.projects.title} subtitle={dict.projects.subtitle} />

      <section className="container-page py-10">
        <div className="hide-scrollbar -mx-1 mb-10 flex gap-2 overflow-x-auto px-1 pb-2">
          <Link
            href={`/${locale}/projects`}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-sm transition",
              !category
                ? "border-accent/40 bg-accent/10 text-white"
                : "border-white/10 bg-white/[0.02] text-muted hover:text-white",
            )}
          >
            {dict.common.all}
          </Link>
          {CATEGORY_KEYS.map((key) => (
            <Link
              key={key}
              href={`/${locale}/projects?category=${key}`}
              className={cn(
                "shrink-0 rounded-full border px-4 py-2 text-sm transition",
                category === key
                  ? "border-accent/40 bg-accent/10 text-white"
                  : "border-white/10 bg-white/[0.02] text-muted hover:text-white",
              )}
            >
              {dict.projects.categories[key]}
            </Link>
          ))}
        </div>

        {projects.length === 0 ? (
          <Card className="flex flex-col items-center gap-3 py-16 text-center">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-accent/10 text-accent">
              <FolderOpen className="h-7 w-7" aria-hidden />
            </span>
            <h2 className="text-lg font-semibold text-white">{dict.projects.emptyTitle}</h2>
            <p className="max-w-md text-sm text-muted">{dict.projects.emptyText}</p>
            <Pill>{dict.common.availability}</Pill>
          </Card>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((project, index) => (
              <Reveal key={project.id} delay={index * 70}>
                <ProjectCard locale={locale} dict={dict} project={project} />
              </Reveal>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
