import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Check, ExternalLink, Sparkles } from "lucide-react";
import { Card, Pill, buttonClass } from "@/components/ui/kit";
import { Reveal } from "@/components/ui/reveal";
import { ProjectCard } from "@/components/site/cards";
import { categoryLabel, getProjectBySlug, getProjects, loadLocaleData } from "@/lib/data";
import { toLocale } from "@/lib/params";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>;
}) {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  const { dict } = await loadLocaleData(locale);
  const project = await getProjectBySlug(slug, locale);
  if (!project) return { title: dict.notFound.title };
  return {
    title: project.title,
    description: project.summary || project.description.slice(0, 160),
    openGraph: {
      title: project.title,
      description: project.summary,
      images: project.coverImageUrl ? [{ url: project.coverImageUrl }] : undefined,
    },
  };
}

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>;
}) {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  const { dict } = await loadLocaleData(locale);
  const project = await getProjectBySlug(slug, locale);
  if (!project) notFound();

  const others = (await getProjects(locale)).filter((item) => item.slug !== project.slug).slice(0, 3);
  const category = categoryLabel(dict, project.category);

  return (
    <>
      <section className="relative overflow-hidden pt-36 pb-10">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-80 bg-[radial-gradient(55%_100%_at_50%_0%,rgba(37,99,235,0.28),transparent_70%)]"
          aria-hidden
        />
        <div className="container-page relative flex flex-col items-center gap-5 text-center">
          <Link
            href={`/${locale}/projects`}
            className="inline-flex items-center gap-2 text-sm text-muted transition hover:text-white"
          >
            <ArrowLeft className="h-4 w-4 flip-x" aria-hidden />
            {dict.projects.backToProjects}
          </Link>
          <Pill>{category}</Pill>
          <h1 className="max-w-3xl text-3xl font-semibold leading-tight tracking-tight text-white sm:text-5xl">
            {project.title}
          </h1>
          <p className="max-w-2xl text-base leading-relaxed text-muted">{project.summary}</p>
          {project.externalUrl ? (
            <a
              href={project.externalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonClass("primary", "md")}
            >
              {dict.projects.visitLabel}
              <ExternalLink className="h-4 w-4" aria-hidden />
            </a>
          ) : (
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs text-muted">
              <Sparkles className="h-3.5 w-3.5 text-accent" aria-hidden />
              {dict.projects.placeholderUrl}
            </span>
          )}
        </div>
      </section>

      <section className="container-page py-10">
        <Reveal>
          <div className="overflow-hidden rounded-3xl border border-white/10 bg-surface-2">
            {project.coverImageUrl ? (
              <div className="relative aspect-[16/9] w-full">
                <Image
                  src={project.coverImageUrl}
                  alt={`${project.title} — ${category}`}
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 1100px"
                  className="object-cover"
                />
              </div>
            ) : (
              <div className="grid aspect-[16/9] w-full place-items-center text-muted">
                <Sparkles className="h-12 w-12" aria-hidden />
              </div>
            )}
          </div>
        </Reveal>
      </section>

      <section className="container-page grid gap-6 pb-16 lg:grid-cols-[1.4fr_0.6fr]">
        <Reveal>
          <Card className="h-full">
            <h2 className="text-xl font-semibold text-white">{dict.projects.overviewTitle}</h2>
            <p className="mt-4 whitespace-pre-line text-base leading-relaxed text-muted">
              {project.description}
            </p>

            {project.features.length > 0 ? (
              <div className="mt-8">
                <h3 className="text-sm font-semibold uppercase tracking-widest text-accent">
                  {dict.projects.featuresLabel}
                </h3>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {project.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-sm text-muted">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Card>
        </Reveal>

        <Reveal delay={100}>
          <Card className="h-fit">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted">
              {dict.projects.technologiesLabel}
            </h3>
            <ul className="mt-4 flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <li
                  key={tech}
                  className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs text-white/85"
                >
                  {tech}
                </li>
              ))}
            </ul>
            <dl className="mt-6 flex flex-col gap-3 text-sm">
              <div className="flex flex-col">
                <dt className="text-xs uppercase tracking-widest text-muted">{dict.common.category}</dt>
                <dd className="text-white/90">{category}</dd>
              </div>
              <div className="flex flex-col">
                <dt className="text-xs uppercase tracking-widest text-muted">{dict.common.projectUrl}</dt>
                <dd className="break-all text-white/90">
                  {project.externalUrl ? (
                    <a
                      href={project.externalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-accent hover:underline"
                    >
                      {project.externalUrl}
                    </a>
                  ) : (
                    dict.projects.placeholderUrl
                  )}
                </dd>
              </div>
            </dl>
            <Link href={`/${locale}/contact`} className={`${buttonClass("secondary", "sm")} mt-6 w-full`}>
              {dict.common.contactMe}
            </Link>
          </Card>
        </Reveal>
      </section>

      {project.images.length > 0 ? (
        <section className="container-page py-10">
          <h2 className="text-2xl font-semibold text-white">{dict.projects.galleryLabel}</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            {project.images.map((image, index) => (
              <Reveal key={image.id} delay={index * 70}>
                <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-white/10 bg-surface-2">
                  <Image
                    src={image.url}
                    alt={image.alt || `${project.title} screenshot ${index + 1}`}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                  />
                </div>
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}

      {others.length > 0 ? (
        <section className="container-page py-12">
          <h2 className="text-2xl font-semibold text-white">{dict.projects.otherTitle}</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((item, index) => (
              <Reveal key={item.id} delay={index * 70}>
                <ProjectCard locale={locale} dict={dict} project={item} />
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}
