import {
  boolean,
  customType,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Raw binary column used to persist uploaded images inside PostgreSQL. */
const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

/* -------------------------------------------------------------------------- */
/*                              Admin & security                              */
/* -------------------------------------------------------------------------- */

export const adminUsers = pgTable(
  "admin_users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    name: text("name").notNull().default("Administrator"),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("admin"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  },
  (table) => [uniqueIndex("admin_users_email_unique").on(table.email)],
);

export const adminSessions = pgTable(
  "admin_sessions",
  {
    id: text("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => adminUsers.id, { onDelete: "cascade" }),
    userAgent: text("user_agent"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("admin_sessions_user_idx").on(table.userId)],
);

/* -------------------------------------------------------------------------- */
/*                                  Media                                     */
/* -------------------------------------------------------------------------- */

export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull().default(0),
  data: bytea("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*                                 Projects                                   */
/* -------------------------------------------------------------------------- */

export const projects = pgTable(
  "projects",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    category: text("category").notNull().default("website"),
    technologies: jsonb("technologies").$type<string[]>().notNull().default([]),
    externalUrl: text("external_url"),
    repositoryUrl: text("repository_url"),
    coverImageUrl: text("cover_image_url"),
    featured: boolean("featured").notNull().default(false),
    published: boolean("published").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("projects_slug_unique").on(table.slug)],
);

export const projectTranslations = pgTable(
  "project_translations",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    locale: text("locale").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull().default(""),
    description: text("description").notNull().default(""),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("project_translations_unique").on(table.projectId, table.locale),
    index("project_translations_locale_idx").on(table.locale),
  ],
);

export const projectImages = pgTable(
  "project_images",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    url: text("url").notNull(),
    alt: text("alt").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("project_images_project_idx").on(table.projectId)],
);

/* -------------------------------------------------------------------------- */
/*                                 Services                                   */
/* -------------------------------------------------------------------------- */

export const services = pgTable(
  "services",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    icon: text("icon").notNull().default("Globe"),
    startingPrice: integer("starting_price").notNull().default(0),
    currency: text("currency").notNull().default("MAD"),
    visible: boolean("visible").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("services_slug_unique").on(table.slug)],
);

export const serviceTranslations = pgTable(
  "service_translations",
  {
    id: serial("id").primaryKey(),
    serviceId: integer("service_id")
      .notNull()
      .references(() => services.id, { onDelete: "cascade" }),
    locale: text("locale").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull().default(""),
    description: text("description").notNull().default(""),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    benefits: jsonb("benefits").$type<string[]>().notNull().default([]),
    deliveryTime: text("delivery_time").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("service_translations_unique").on(table.serviceId, table.locale),
    index("service_translations_locale_idx").on(table.locale),
  ],
);

/* -------------------------------------------------------------------------- */
/*                             Pricing packages                               */
/* -------------------------------------------------------------------------- */

export const pricingPackages = pgTable(
  "pricing_packages",
  {
    id: serial("id").primaryKey(),
    planKey: text("plan_key").notNull(),
    price: integer("price").notNull().default(0),
    currency: text("currency").notNull().default("MAD"),
    popular: boolean("popular").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("pricing_packages_key_unique").on(table.planKey)],
);

export const pricingTranslations = pgTable(
  "pricing_translations",
  {
    id: serial("id").primaryKey(),
    packageId: integer("package_id")
      .notNull()
      .references(() => pricingPackages.id, { onDelete: "cascade" }),
    locale: text("locale").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    deliveryTime: text("delivery_time").notNull().default(""),
    revisions: text("revisions").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("pricing_translations_unique").on(table.packageId, table.locale)],
);

/* -------------------------------------------------------------------------- */
/*                                    FAQ                                     */
/* -------------------------------------------------------------------------- */

export const faqs = pgTable("faqs", {
  id: serial("id").primaryKey(),
  published: boolean("published").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const faqTranslations = pgTable(
  "faq_translations",
  {
    id: serial("id").primaryKey(),
    faqId: integer("faq_id")
      .notNull()
      .references(() => faqs.id, { onDelete: "cascade" }),
    locale: text("locale").notNull(),
    question: text("question").notNull(),
    answer: text("answer").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("faq_translations_unique").on(table.faqId, table.locale)],
);

/* -------------------------------------------------------------------------- */
/*                                   Skills                                   */
/* -------------------------------------------------------------------------- */

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  category: text("category").notNull().default("frontend"),
  name: text("name").notNull(),
  level: integer("level").notNull().default(0),
  description: text("description").notNull().default(""),
  visible: boolean("visible").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*                     Multilingual editable site content                     */
/* -------------------------------------------------------------------------- */

export const contentBlocks = pgTable(
  "content_blocks",
  {
    id: serial("id").primaryKey(),
    key: text("key").notNull(),
    locale: text("locale").notNull(),
    value: text("value").notNull().default(""),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("content_blocks_key_locale_unique").on(table.key, table.locale)],
);

export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*                              Contact messages                              */
/* -------------------------------------------------------------------------- */

export const contactMessages = pgTable(
  "contact_messages",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    service: text("service"),
    budget: text("budget"),
    message: text("message").notNull(),
    locale: text("locale").notNull().default("en"),
    status: text("status").notNull().default("new"),
    submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
    readAt: timestamp("read_at", { withTimezone: true }),
  },
  (table) => [index("contact_messages_status_idx").on(table.status)],
);

export type AdminUser = typeof adminUsers.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type ProjectTranslation = typeof projectTranslations.$inferSelect;
export type ProjectImage = typeof projectImages.$inferSelect;
export type Service = typeof services.$inferSelect;
export type ServiceTranslation = typeof serviceTranslations.$inferSelect;
export type PricingPackage = typeof pricingPackages.$inferSelect;
export type PricingTranslation = typeof pricingTranslations.$inferSelect;
export type Faq = typeof faqs.$inferSelect;
export type FaqTranslation = typeof faqTranslations.$inferSelect;
export type Skill = typeof skills.$inferSelect;
export type ContactMessage = typeof contactMessages.$inferSelect;
export type MediaRecord = typeof media.$inferSelect;
