/* -------------------------------------------------------------------------- *
 * Initial database content. Everything here is editable from /admin and is    *
 * inserted idempotently, so the live site always has real data to render.     *
 * -------------------------------------------------------------------------- */

export type SeedTranslation = {
  title?: string;
  summary?: string;
  description?: string;
  features?: string[];
  benefits?: string[];
  deliveryTime?: string;
  question?: string;
  answer?: string;
  name?: string;
  revisions?: string;
};

export type SeedService = {
  slug: string;
  icon: string;
  startingPrice: number;
  sortOrder: number;
  translations: Record<"en" | "fr" | "ar", SeedTranslation>;
};

export const seedServices: SeedService[] = [
  {
    slug: "business-website",
    icon: "Building2",
    startingPrice: 3500,
    sortOrder: 1,
    translations: {
      en: {
        title: "Business Website Development",
        summary: "A professional multi-section website that presents your company, services and contact channels clearly.",
        description:
          "Your website is often the first contact a client has with your company. I design and develop complete business websites: structured pages, clear messaging, fast loading and a layout that guides visitors towards contacting you. Every page is handcrafted, responsive and prepared for search engines.",
        features: [
          "Up to 6 custom-designed pages",
          "Mobile, tablet and desktop layouts",
          "Contact form saved in a secure database",
          "WhatsApp and click-to-call buttons",
          "Basic on-page SEO and metadata",
          "Google Analytics readiness",
        ],
        benefits: [
          "Look credible from the first second",
          "Turn visitors into contacted leads",
          "Own clean, documented code",
        ],
        deliveryTime: "7 – 14 days",
      },
      fr: {
        title: "Création de site vitrine",
        summary: "Un site professionnel multi-sections qui présente clairement votre entreprise, vos services et vos contacts.",
        description:
          "Votre site est souvent le premier contact d'un client avec votre entreprise. Je conçois et développe des sites vitrines complets : pages structurées, message clair, chargement rapide et une mise en page qui guide le visiteur vers le contact. Chaque page est faite main, responsive et préparée pour le référencement.",
        features: [
          "Jusqu'à 6 pages sur mesure",
          "Mises en page mobile, tablette et ordinateur",
          "Formulaire de contact enregistré en base de données",
          "Boutons WhatsApp et clic-pour-appeler",
          "SEO on-page et métadonnées",
          "Prêt pour Google Analytics",
        ],
        benefits: [
          "Inspirez confiance dès la première seconde",
          "Transformez les visiteurs en contacts",
          "Possédez un code propre et documenté",
        ],
        deliveryTime: "7 – 14 jours",
      },
      ar: {
        title: "تطوير موقع شركة",
        summary: "موقع احترافي متعدد الأقسام يعرّف بشركتك وخدماتك ووسائل التواصل بوضوح.",
        description:
          "موقعك هو غالباً أول تواصل بين العميل وشركتك. أصمّم وأطوّر مواقع شركات كاملة: صفحات منظمة، رسالة واضحة، تحميل سريع، وتصميم يوجّه الزائر نحو التواصل معك. كل صفحة مصممة يدوياً، متجاوبة، ومهيّأة لمحركات البحث.",
        features: [
          "حتى 6 صفحات بتصميم مخصص",
          "تصاميم للهاتف واللوحي والحاسوب",
          "نموذج اتصال محفوظ في قاعدة بيانات آمنة",
          "أزرار واتساب والاتصال المباشر",
          "تهيئة أساسية لمحركات البحث",
          "جاهزية لربط Google Analytics",
        ],
        benefits: ["مظهر موثوق من اللحظة الأولى", "تحويل الزوار إلى عملاء", "كود نظيف وموثّق"],
        deliveryTime: "7 – 14 يوماً",
      },
    },
  },
  {
    slug: "ecommerce-development",
    icon: "ShoppingBag",
    startingPrice: 6000,
    sortOrder: 2,
    translations: {
      en: {
        title: "E-commerce Website Development",
        summary: "A complete online store with product catalogue, cart, checkout and an order dashboard.",
        description:
          "I build e-commerce websites that are simple for your customers and manageable for you: product catalogue with categories, search and filters, cart and checkout flow, order management dashboard, and integration with the payment or delivery method you already use. The focus is on speed, clarity and conversion.",
        features: [
          "Product catalogue with categories and filters",
          "Cart, checkout and order confirmation flow",
          "Admin dashboard for products and orders",
          "Payment or cash-on-delivery integration",
          "Customer accounts and order history",
          "Inventory and stock status management",
        ],
        benefits: [
          "Sell 24/7 without a physical shop",
          "Manage products without a developer",
          "A fast checkout that reduces abandoned carts",
        ],
        deliveryTime: "3 – 5 weeks",
      },
      fr: {
        title: "Développement de boutique e-commerce",
        summary: "Une boutique en ligne complète : catalogue, panier, paiement et tableau de bord des commandes.",
        description:
          "Je crée des boutiques en ligne simples pour vos clients et faciles à gérer pour vous : catalogue avec catégories, recherche et filtres, panier et tunnel de commande, tableau de bord de gestion des commandes, et intégration du moyen de paiement ou de livraison que vous utilisez déjà. L'objectif : rapidité, clarté et conversion.",
        features: [
          "Catalogue produits avec catégories et filtres",
          "Panier, paiement et confirmation de commande",
          "Tableau de bord produits et commandes",
          "Intégration paiement ou paiement à la livraison",
          "Comptes clients et historique de commandes",
          "Gestion des stocks et disponibilités",
        ],
        benefits: [
          "Vendez 24h/24 sans local commercial",
          "Gérez vos produits sans développeur",
          "Un tunnel de paiement rapide qui réduit les abandons",
        ],
        deliveryTime: "3 – 5 semaines",
      },
      ar: {
        title: "تطوير متجر إلكتروني",
        summary: "متجر إلكتروني كامل مع كتالوج منتجات، سلة شراء، دفع، ولوحة تحكم للطلبات.",
        description:
          "أبني متاجر إلكترونية بسيطة لعملائك وسهلة الإدارة لك: كتالوج منتجات مع التصنيفات والبحث والفلاتر، سلة وخطوات الدفع، لوحة تحكم لإدارة الطلبات، وربط وسيلة الدفع أو التوصيل التي تستخدمها. التركيز على السرعة والوضوح وتحقيق المبيعات.",
        features: [
          "كتالوج منتجات مع تصنيفات وفلاتر",
          "سلة، دفع، وتأكيد الطلب",
          "لوحة تحكم للمنتجات والطلبات",
          "ربط الدفع الإلكتروني أو الدفع عند التسليم",
          "حسابات العملاء وسجل الطلبات",
          "إدارة المخزون وحالة التوفر",
        ],
        benefits: ["بيع على مدار الساعة", "إدارة المنتجات بدون مطوّر", "دفع سريع يقلّل السلال المتروكة"],
        deliveryTime: "3 – 5 أسابيع",
      },
    },
  },
  {
    slug: "restaurant-website",
    icon: "UtensilsCrossed",
    startingPrice: 4500,
    sortOrder: 3,
    translations: {
      en: {
        title: "Restaurant Website Development",
        summary: "A mouth-watering website with digital menu, photos, reservations and WhatsApp ordering.",
        description:
          "Restaurants need a website that loads instantly on a phone and shows the menu beautifully. I build restaurant websites with a structured digital menu, photo galleries, opening hours, location map, table reservation form and direct WhatsApp ordering — everything a guest needs before deciding where to eat.",
        features: [
          "Structured digital menu with categories and prices",
          "Photo gallery of dishes and interior",
          "Table reservation or order request form",
          "WhatsApp ordering button",
          "Map, opening hours and contact block",
          "Multilingual menu (FR / AR / EN)",
        ],
        benefits: [
          "More calls and reservations",
          "Menu updates without reprinting",
          "A professional image that matches your food",
        ],
        deliveryTime: "10 – 15 days",
      },
      fr: {
        title: "Création de site pour restaurant",
        summary: "Un site appétissant avec menu digital, photos, réservations et commandes WhatsApp.",
        description:
          "Un restaurant a besoin d'un site qui se charge instantanément sur mobile et met bien en valeur la carte. Je développe des sites de restaurants avec menu digital structuré, galeries photos, horaires, plan d'accès, formulaire de réservation et commande directe par WhatsApp — tout ce qu'un client cherche avant de choisir où manger.",
        features: [
          "Menu digital structuré avec catégories et prix",
          "Galerie photos des plats et de la salle",
          "Formulaire de réservation ou de commande",
          "Bouton de commande WhatsApp",
          "Plan, horaires et bloc contact",
          "Menu multilingue (FR / AR / EN)",
        ],
        benefits: [
          "Plus d'appels et de réservations",
          "Mise à jour du menu sans réimpression",
          "Une image professionnelle à la hauteur de votre cuisine",
        ],
        deliveryTime: "10 – 15 jours",
      },
      ar: {
        title: "تطوير موقع مطعم",
        summary: "موقع جاذب مع قائمة رقمية، صور، حجوزات، وطلبات عبر واتساب.",
        description:
          "يحتاج المطعم إلى موقع يفتح فوراً على الهاتف ويعرض القائمة بشكل جميل. أطوّر مواقع مطاعم مع قائمة رقمية منظمة، معرض صور، أوقات العمل، خريطة الموقع، نموذج حجز الطاولات، والطلب المباشر عبر واتساب — كل ما يحتاجه الزائر قبل اختيار المكان.",
        features: [
          "قائمة رقمية منظمة مع التصنيفات والأسعار",
          "معرض صور للأطباق والمكان",
          "نموذج حجز طاولة أو طلب",
          "زر الطلب عبر واتساب",
          "الخريطة وأوقات العمل ومعلومات الاتصال",
          "قائمة متعددة اللغات (FR / AR / EN)",
        ],
        benefits: ["مكالمات وحجوزات أكثر", "تحديث القائمة بدون طباعة", "صورة احترافية تليق بمطبخك"],
        deliveryTime: "10 – 15 يوماً",
      },
    },
  },
  {
    slug: "fashion-store",
    icon: "Shirt",
    startingPrice: 5500,
    sortOrder: 4,
    translations: {
      en: {
        title: "Fashion & Clothing Store Development",
        summary: "An elegant storefront for clothing brands: lookbook, variants, sizes and Instagram-ready design.",
        description:
          "Fashion sells through imagery and trust. I develop clothing stores where photography leads the design, with size and colour variants, stock per variant, lookbook or collection pages, and a checkout experience adapted to the Moroccan market (cash on delivery, WhatsApp confirmation) or international payments.",
        features: [
          "Visual product pages with size and colour variants",
          "Collection / lookbook pages",
          "Stock management per variant",
          "Cash on delivery and online payment options",
          "Look-first responsive design",
          "Instagram and social feed integration",
        ],
        benefits: [
          "A brand image that matches your collection",
          "Fewer size mistakes and returns",
          "Direct sales from social networks to checkout",
        ],
        deliveryTime: "3 – 4 weeks",
      },
      fr: {
        title: "Boutique mode & prêt-à-porter",
        summary: "Une vitrine élégante pour marques de vêtements : lookbook, variantes, tailles et design soigné.",
        description:
          "La mode se vend par l'image et la confiance. Je développe des boutiques de vêtements où la photographie guide le design, avec variantes de taille et de couleur, stock par variante, pages collections ou lookbook, et un paiement adapté au marché marocain (paiement à la livraison, confirmation WhatsApp) ou aux paiements internationaux.",
        features: [
          "Pages produits visuelles avec tailles et couleurs",
          "Pages collections / lookbook",
          "Gestion de stock par variante",
          "Paiement à la livraison et paiement en ligne",
          "Design responsive centré sur l'image",
          "Intégration Instagram et réseaux sociaux",
        ],
        benefits: [
          "Une image de marque fidèle à votre collection",
          "Moins d'erreurs de taille et de retours",
          "Des ventes directes depuis les réseaux sociaux",
        ],
        deliveryTime: "3 – 4 semaines",
      },
      ar: {
        title: "تطوير متجر أزياء وملابس",
        summary: "واجهة أنيقة لماركات الملابس: معرض إطلالات، مقاسات وألوان، وتصميم راقٍ.",
        description:
          "الأزياء تُباع بالصورة والثقة. أطوّر متاجر ملابس يقود فيها التصوير التصميم، مع مقاسات وألوان متعددة، مخزون لكل مقاس، صفحات مجموعات ومعارض إطلالات، ووسائل دفع مناسبة للسوق المغربي (الدفع عند التسليم وتأكيد واتساب) أو للدفع الدولي.",
        features: [
          "صفحات منتجات بصرية مع المقاسات والألوان",
          "صفحات المجموعات ومعارض الإطلالات",
          "إدارة المخزون لكل مقاس",
          "الدفع عند التسليم والدفع الإلكتروني",
          "تصميم متجاوب يركّز على الصورة",
          "ربط إنستغرام والشبكات الاجتماعية",
        ],
        benefits: ["صورة علامة تطابق مجموعتك", "أخطاء مقاسات وإرجاع أقل", "بيع مباشر من الشبكات الاجتماعية"],
        deliveryTime: "3 – 4 أسابيع",
      },
    },
  },
  {
    slug: "landing-page",
    icon: "Rocket",
    startingPrice: 1800,
    sortOrder: 5,
    translations: {
      en: {
        title: "Landing Page Development",
        summary: "A single high-converting page for a product, service, campaign or event.",
        description:
          "When you need one page that does one job — capture a lead, sell a product, promote an event — a landing page is the fastest solution. I write the structure with you, design it, develop it and connect it to your form, WhatsApp and analytics so you can measure every visit.",
        features: [
          "Conversion-focused single page",
          "Copy structure and call-to-action strategy",
          "Lead form saved in a database",
          "WhatsApp and email notifications",
          "Fast loading and mobile-first layout",
          "Campaign tracking readiness",
        ],
        benefits: [
          "Launch a campaign in days, not months",
          "A clear path from visit to contact",
          "Measurable results from day one",
        ],
        deliveryTime: "3 – 7 days",
      },
      fr: {
        title: "Création de landing page",
        summary: "Une page unique à forte conversion pour un produit, un service, une campagne ou un événement.",
        description:
          "Quand une seule page doit atteindre un seul objectif — capter un contact, vendre un produit, promouvoir un événement — la landing page est la solution la plus rapide. Je construis la structure avec vous, la designe, la développe et la connecte à votre formulaire, WhatsApp et outil de mesure.",
        features: [
          "Page unique orientée conversion",
          "Structure du texte et stratégie d'appel à l'action",
          "Formulaire enregistré en base de données",
          "Notifications WhatsApp et e-mail",
          "Chargement rapide et design mobile-first",
          "Prêt pour le suivi de campagne",
        ],
        benefits: [
          "Lancez une campagne en quelques jours",
          "Un parcours clair de la visite au contact",
          "Des résultats mesurables dès le premier jour",
        ],
        deliveryTime: "3 – 7 jours",
      },
      ar: {
        title: "تطوير صفحة هبوط",
        summary: "صفحة واحدة عالية التحويل لمنتج أو خدمة أو حملة أو حدث.",
        description:
          "عندما تحتاج صفحة واحدة لهدف واحد — جمع بيانات، بيع منتج، الترويج لحدث — فإن صفحة الهبوط هي الحل الأسرع. أبني معك الهيكل، أصمّم الصفحة، أطوّرها، وأربطها بنموذج التواصل وواتساب وأدوات القياس لتتابعي كل زيارة.",
        features: [
          "صفحة واحدة موجّهة للتحويل",
          "هيكل النصوص واستراتيجية الدعوة للإجراء",
          "نموذج بيانات محفوظ في قاعدة بيانات",
          "تنبيهات واتساب وبريد إلكتروني",
          "تحميل سريع وتصميم للهاتف أولاً",
          "جاهزية لتتبع الحملات",
        ],
        benefits: ["إطلاق الحملة في أيام", "مسار واضح من الزيارة إلى التواصل", "نتائج قابلة للقياس"],
        deliveryTime: "3 – 7 أيام",
      },
    },
  },
  {
    slug: "website-redesign",
    icon: "RefreshCw",
    startingPrice: 2500,
    sortOrder: 6,
    translations: {
      en: {
        title: "Website Redesign",
        summary: "A modern rebuild of an existing website: new design, better speed, same content.",
        description:
          "If your current website looks dated, loads slowly or is impossible to use on a phone, a redesign solves it without losing your history. I audit the existing pages, keep the content that works, rebuild the design and code with a modern stack, and preserve your URLs and SEO where possible.",
        features: [
          "Full audit of the current website",
          "Modern responsive redesign",
          "Performance and accessibility improvements",
          "Content restructuring and clearer navigation",
          "URL and SEO preservation",
          "Migration of existing content",
        ],
        benefits: [
          "A trustworthy image immediately",
          "Faster pages and better rankings",
          "Keep your existing traffic and history",
        ],
        deliveryTime: "10 – 20 days",
      },
      fr: {
        title: "Refonte de site web",
        summary: "Une reconstruction moderne d'un site existant : nouveau design, meilleure vitesse, mêmes contenus.",
        description:
          "Si votre site actuel paraît daté, se charge lentement ou est inutilisable sur mobile, une refonte règle le problème sans perdre votre historique. J'audite les pages existantes, garde les contenus qui fonctionnent, reconstruis le design et le code avec une stack moderne, et préserve vos URL et votre référencement.",
        features: [
          "Audit complet du site actuel",
          "Refonte moderne et responsive",
          "Améliorations de performance et d'accessibilité",
          "Restructuration du contenu et navigation claire",
          "Préservation des URL et du SEO",
          "Migration des contenus existants",
        ],
        benefits: [
          "Une image crédible immédiatement",
          "Des pages plus rapides et mieux positionnées",
          "Vous conservez votre trafic et votre historique",
        ],
        deliveryTime: "10 – 20 jours",
      },
      ar: {
        title: "إعادة تصميم الموقع",
        summary: "إعادة بناء حديثة لموقع قائم: تصميم جديد، سرعة أفضل، ونفس المحتوى.",
        description:
          "إذا كان موقعك الحالي يبدو قديماً، بطيئاً، أو يصعب استخدامه على الهاتف، فإن إعادة التصميم تحل المشكلة دون فقدان تاريخك. أُدقّق الصفحات الحالية، أحتفظ بالمحتوى الناجح، أعيد بناء التصميم والكود بتقنيات حديثة، وأحافظ على الروابط وترتيب محركات البحث.",
        features: [
          "تدقيق كامل للموقع الحالي",
          "تصميم حديث ومتجاوب",
          "تحسين الأداء وسهولة الاستخدام",
          "إعادة تنظيم المحتوى وتوضيح التنقل",
          "الحفاظ على الروابط والسيو",
          "نقل المحتوى الحالي",
        ],
        benefits: ["صورة موثوقة فوراً", "صفحات أسرع وترتيب أفضل", "الاحتفاظ بزوارك وتاريخك"],
        deliveryTime: "10 – 20 يوماً",
      },
    },
  },
  {
    slug: "admin-dashboard",
    icon: "LayoutDashboard",
    startingPrice: 7000,
    sortOrder: 7,
    translations: {
      en: {
        title: "Admin Dashboard Development",
        summary: "A private back office to manage your content, orders, requests and statistics.",
        description:
          "Stop depending on a developer for every small change. I build secure admin dashboards with login, roles and clean CRUD interfaces so you can manage products, articles, requests, prices and media yourself — with validation, permissions and a clean audit trail in the database.",
        features: [
          "Secure authentication and roles",
          "CRUD interfaces for your data",
          "Image and file uploads",
          "Statistics and recent activity overview",
          "Multilingual content management",
          "Role-based access and session management",
        ],
        benefits: [
          "Full autonomy over your content",
          "Fewer developer costs for small updates",
          "Data stored securely in your own database",
        ],
        deliveryTime: "3 – 6 weeks",
      },
      fr: {
        title: "Développement de tableau de bord d'administration",
        summary: "Un back-office privé pour gérer vos contenus, commandes, demandes et statistiques.",
        description:
          "Arrêtez de dépendre d'un développeur pour chaque petit changement. Je construis des tableaux de bord sécurisés avec connexion, rôles et interfaces CRUD propres pour gérer vous-même produits, articles, demandes, prix et médias — avec validation, permissions et un historique fiable en base de données.",
        features: [
          "Authentification sécurisée et rôles",
          "Interfaces CRUD pour vos données",
          "Téléversement d'images et de fichiers",
          "Statistiques et activité récente",
          "Gestion de contenus multilingues",
          "Accès par rôle et gestion des sessions",
        ],
        benefits: [
          "Autonomie totale sur vos contenus",
          "Moins de coûts de développement pour les petites mises à jour",
          "Des données stockées dans votre propre base",
        ],
        deliveryTime: "3 – 6 semaines",
      },
      ar: {
        title: "تطوير لوحة تحكم للإدارة",
        summary: "لوحة تحكم خاصة لإدارة المحتوى والطلبات والرسائل والإحصائيات.",
        description:
          "لا تعتمدي على مطوّر لكل تعديل صغير. أبني لوحات تحكم آمنة مع تسجيل دخول وأدوار وواجهات إدارة واضحة لتديري المنتجات والمقالات والطلبات والأسعار والصور بنفسك — مع تحقق من المدخلات وصلاحيات وسجل موثوق في قاعدة البيانات.",
        features: [
          "مصادقة آمنة وأدوار مستخدمين",
          "واجهات إضافة وتعديل وحذف للبيانات",
          "رفع الصور والملفات",
          "إحصائيات ونظرة على النشاط الأخير",
          "إدارة محتوى متعدد اللغات",
          "صلاحيات حسب الدور وإدارة الجلسات",
        ],
        benefits: ["استقلالية كاملة في المحتوى", "تكاليف أقل للتعديلات الصغيرة", "بياناتك في قاعدة بياناتك الخاصة"],
        deliveryTime: "3 – 6 أسابيع",
      },
    },
  },
  {
    slug: "website-maintenance",
    icon: "Wrench",
    startingPrice: 400,
    sortOrder: 8,
    translations: {
      en: {
        title: "Website Maintenance",
        summary: "Monthly care for your website: updates, backups, monitoring and small changes.",
        description:
          "A website needs to be maintained like any other asset. My maintenance service covers dependency and framework updates, security checks, performance monitoring, content edits and priority support, so your website keeps working while you run your business.",
        features: [
          "Monthly technical update report",
          "Dependency and security updates",
          "Backup before every intervention",
          "Small content and design edits included",
          "Uptime and performance monitoring",
          "Priority response for incidents",
        ],
        benefits: [
          "No surprises or downtime",
          "A developer who already knows your code",
          "Predictable monthly cost",
        ],
        deliveryTime: "Monthly plan",
      },
      fr: {
        title: "Maintenance de site web",
        summary: "Un suivi mensuel de votre site : mises à jour, sauvegardes, supervision et petites modifications.",
        description:
          "Un site web se maintient comme n'importe quel autre actif. Mon service de maintenance couvre les mises à jour des dépendances et du framework, les contrôles de sécurité, la supervision des performances, les modifications de contenu et un support prioritaire, pour que votre site continue de fonctionner pendant que vous gérez votre activité.",
        features: [
          "Rapport technique mensuel",
          "Mises à jour des dépendances et sécurité",
          "Sauvegarde avant chaque intervention",
          "Petites modifications de contenu incluses",
          "Supervision de disponibilité et performance",
          "Réponse prioritaire en cas d'incident",
        ],
        benefits: [
          "Aucune mauvaise surprise ni interruption",
          "Une développeuse qui connaît déjà votre code",
          "Un coût mensuel prévisible",
        ],
        deliveryTime: "Formule mensuelle",
      },
      ar: {
        title: "صيانة المواقع",
        summary: "متابعة شهرية لموقعك: تحديثات، نسخ احتياطية، مراقبة وتعديلات صغيرة.",
        description:
          "الموقع يحتاج صيانة مثل أي أصل آخر. تشمل خدمة الصيانة تحديث المكتبات والإطار، فحوصات الأمان، مراقبة الأداء، تعديلات المحتوى، ودعم ذو أولوية، ليظل موقعك يعمل بينما تديرين عملك.",
        features: [
          "تقرير تقني شهري",
          "تحديثات المكتبات والأمان",
          "نسخة احتياطية قبل كل تدخل",
          "تعديلات صغيرة على المحتوى والتصميم",
          "مراقبة التوفر والأداء",
          "استجابة سريعة للمشاكل",
        ],
        benefits: ["بدون مفاجآت أو توقّف", "مطوّرة تعرف كودك مسبقاً", "تكلفة شهرية ثابتة"],
        deliveryTime: "خطة شهرية",
      },
    },
  },
];

export const seedProject = {
  slug: "bella-pizza",
  category: "restaurant",
  technologies: ["Next.js", "TypeScript", "Tailwind CSS", "PostgreSQL"],
  externalUrl: "",
  repositoryUrl: "",
  coverImageUrl: "/images/bella-pizza.jpg",
  featured: true,
  published: true,
  sortOrder: 1,
  translations: {
    en: {
      title: "Bella Pizza",
      summary:
        "A restaurant website concept with a structured digital menu, photo gallery and direct WhatsApp ordering.",
      description:
        "Bella Pizza is a restaurant project built around one goal: let a hungry visitor see the menu, the photos and the phone number within seconds. The layout is mobile-first, the menu is structured by categories with prices, and ordering happens either through a request form or directly on WhatsApp. Screenshots and the public link are placeholders until the client approves the final release.",
      features: [
        "Digital menu structured by categories",
        "Photo gallery of dishes",
        "Reservation and order request form",
        "WhatsApp ordering button",
        "Multilingual interface (FR / AR / EN)",
        "Admin area to update menu items",
      ],
    },
    fr: {
      title: "Bella Pizza",
      summary:
        "Un projet de site pour restaurant avec menu digital structuré, galerie photos et commande WhatsApp directe.",
      description:
        "Bella Pizza est un projet de restaurant construit autour d'un objectif : permettre à un visiteur affamé de voir le menu, les photos et le numéro de téléphone en quelques secondes. La mise en page est mobile-first, le menu est structuré par catégories avec prix, et la commande se fait par formulaire ou directement sur WhatsApp. Les captures d'écran et le lien public sont des espaces réservés jusqu'à la validation finale du client.",
      features: [
        "Menu digital structuré par catégories",
        "Galerie photos des plats",
        "Formulaire de réservation et de commande",
        "Bouton de commande WhatsApp",
        "Interface multilingue (FR / AR / EN)",
        "Espace d'administration pour modifier le menu",
      ],
    },
    ar: {
      title: "بيلا بيتزا",
      summary: "مشروع موقع لمطعم مع قائمة رقمية منظمة، معرض صور، وطلب مباشر عبر واتساب.",
      description:
        "بيلا بيتزا مشروع مطعم مبني على هدف واحد: أن يرى الزائر الجائع القائمة والصور ورقم الهاتف في ثوانٍ. التصميم مخصص للهاتف أولاً، والقائمة منظمة بالتصنيفات والأسعار، والطلب يتم عبر نموذج أو مباشرة على واتساب. لقطات الشاشة والرابط العام عناصر مؤقتة إلى حين اعتماد النسخة النهائية من العميل.",
      features: [
        "قائمة رقمية منظمة بالتصنيفات",
        "معرض صور للأطباق",
        "نموذج حجز وطلب",
        "زر الطلب عبر واتساب",
        "واجهة متعددة اللغات (FR / AR / EN)",
        "لوحة إدارة لتحديث أصناف القائمة",
      ],
    },
  },
};

export const seedPackages: {
  planKey: string;
  price: number;
  popular: boolean;
  sortOrder: number;
  translations: Record<"en" | "fr" | "ar", SeedTranslation>;
}[] = [
  {
    planKey: "basic",
    price: 2500,
    popular: false,
    sortOrder: 1,
    translations: {
      en: {
        name: "Basic",
        description: "A clean, professional one-page or small website to establish your online presence.",
        features: [
          "1 – 3 pages, custom design",
          "Mobile & desktop responsive",
          "Contact form with database storage",
          "WhatsApp button",
          "Basic SEO metadata",
          "Delivery in 7 days",
        ],
        deliveryTime: "7 days",
        revisions: "2 rounds of revisions",
      },
      fr: {
        name: "Basique",
        description: "Un site d'une à trois pages, propre et professionnel, pour presence en ligne.",
        features: [
          "1 à 3 pages, design sur mesure",
          "Responsive mobile et ordinateur",
          "Formulaire de contact enregistré en base",
          "Bouton WhatsApp",
          "Métadonnées SEO de base",
          "Livraison en 7 jours",
        ],
        deliveryTime: "7 jours",
        revisions: "2 séries de révisions",
      },
      ar: {
        name: "أساسي",
        description: "موقع من صفحة إلى ثلاث صفحات، نظيف واحترافي لبناء حضورك على الإنترنت.",
        features: [
          "1 – 3 صفحات بتصميم مخصص",
          "متجاوب للهاتف والحاسوب",
          "نموذج اتصال محفوظ في قاعدة بيانات",
          "زر واتساب",
          "بيانات SEO أساسية",
          "التسليم في 7 أيام",
        ],
        deliveryTime: "7 أيام",
        revisions: "جولتا تعديلات",
      },
    },
  },
  {
    planKey: "standard",
    price: 5500,
    popular: true,
    sortOrder: 2,
    translations: {
      en: {
        name: "Standard",
        description: "A complete multi-section business website with a small back office for your content.",
        features: [
          "Up to 6 pages, custom design",
          "Admin dashboard for content updates",
          "Multilingual setup (EN / FR / AR)",
          "Advanced SEO and performance work",
          "Gallery, menu or catalogue section",
          "30 days post-launch support",
        ],
        deliveryTime: "2 – 3 weeks",
        revisions: "3 rounds of revisions",
      },
      fr: {
        name: "Standard",
        description: "Un site vitrine complet multi-sections avec un petit back-office pour vos contenus.",
        features: [
          "Jusqu'à 6 pages, design sur mesure",
          "Tableau de bord pour mettre à jour le contenu",
          "Version multilingue (EN / FR / AR)",
          "SEO avancé et optimisation des performances",
          "Section galerie, menu ou catalogue",
          "30 jours de support après la mise en ligne",
        ],
        deliveryTime: "2 – 3 semaines",
        revisions: "3 séries de révisions",
      },
      ar: {
        name: "متقدّم",
        description: "موقع شركة كامل متعدد الأقسام مع لوحة تحكم بسيطة لإدارة المحتوى.",
        features: [
          "حتى 6 صفحات بتصميم مخصص",
          "لوحة تحكم لتحديث المحتوى",
          "نسخة متعددة اللغات (EN / FR / AR)",
          "سيو متقدم وتحسين الأداء",
          "قسم معرض أو قائمة أو كتالوج",
          "30 يوماً دعم بعد الإطلاق",
        ],
        deliveryTime: "2 – 3 أسابيع",
        revisions: "3 جولات تعديلات",
      },
    },
  },
  {
    planKey: "premium",
    price: 9500,
    popular: false,
    sortOrder: 3,
    translations: {
      en: {
        name: "Premium",
        description: "A full e-commerce solution: catalogue, cart, orders dashboard and payment integration.",
        features: [
          "Unlimited pages and products",
          "Complete online store functionality",
          "Admin dashboard for products and orders",
          "Payment / cash-on-delivery integration",
          "Multilingual store with RTL support",
          "60 days support and one training session",
        ],
        deliveryTime: "4 – 6 weeks",
        revisions: "Unlimited revisions during the project",
      },
      fr: {
        name: "Premium",
        description: "Une solution e-commerce complète : catalogue, panier, tableau de bord et paiement.",
        features: [
          "Pages et produits illimités",
          "Fonctionnalités de boutique complètes",
          "Tableau de bord produits et commandes",
          "Intégration paiement / paiement à la livraison",
          "Boutique multilingue avec support RTL",
          "60 jours de support et une session de formation",
        ],
        deliveryTime: "4 – 6 semaines",
        revisions: "Révisions illimitées pendant le projet",
      },
      ar: {
        name: "متميّز",
        description: "حل تجارة إلكترونية كامل: كتالوج، سلة، لوحة طلبات وربط الدفع.",
        features: [
          "صفحات ومنتجات غير محدودة",
          "وظائف متجر إلكتروني كاملة",
          "لوحة تحكم للمنتجات والطلبات",
          "ربط الدفع الإلكتروني أو عند التسليم",
          "متجر متعدد اللغات مع دعم العربية",
          "60 يوماً دعم وجلسة تدريب",
        ],
        deliveryTime: "4 – 6 أسابيع",
        revisions: "تعديلات غير محدودة أثناء المشروع",
      },
    },
  },
];

export const seedFaqs: { sortOrder: number; translations: Record<"en" | "fr" | "ar", SeedTranslation> }[] = [
  {
    sortOrder: 1,
    translations: {
      en: {
        question: "How much does a website cost?",
        answer:
          "Prices depend on the number of pages and the features you need. The packages on the pricing page are configurable example prices in Moroccan Dirhams: a simple landing page starts lower, while a full online store costs more. After a short conversation I send a written quote with a fixed price before any work begins.",
      },
      fr: {
        question: "Combien coûte un site web ?",
        answer:
          "Le prix dépend du nombre de pages et des fonctionnalités nécessaires. Les formules de la page tarifs sont des prix d'exemple configurables en dirhams marocains : une landing page simple coûte moins, une boutique complète coûte plus. Après une courte discussion, j'envoie un devis écrit à prix fixe avant de commencer.",
      },
      ar: {
        question: "كم يكلف الموقع الإلكتروني؟",
        answer:
          "السعر يعتمد على عدد الصفحات والميزات المطلوبة. الباقات في صفحة الأسعار هي أسعار أمثلة قابلة للتعديل بالدرهم المغربي: صفحة الهبوط البسيطة أقل تكلفة، والمتجر الكامل أعلى. بعد نقاش قصير أرسل عرض سعر مكتوباً بسعر ثابت قبل بدء العمل.",
      },
    },
  },
  {
    sortOrder: 2,
    translations: {
      en: {
        question: "How long does development take?",
        answer:
          "A landing page takes 3 to 7 days, a business website 1 to 3 weeks, and an online store 3 to 6 weeks. The timeline is confirmed in the quote and depends mainly on how quickly texts, photos and feedback are provided.",
      },
      fr: {
        question: "Combien de temps prend le développement ?",
        answer:
          "Une landing page prend 3 à 7 jours, un site vitrine 1 à 3 semaines, une boutique en ligne 3 à 6 semaines. Le calendrier est confirmé dans le devis et dépend surtout de la rapidité d'envoi des textes, photos et retours.",
      },
      ar: {
        question: "كم تستغرق مدة التطوير؟",
        answer:
          "صفحة الهبوط من 3 إلى 7 أيام، موقع الشركة من أسبوع إلى 3 أسابيع، والمتجر الإلكتروني من 3 إلى 6 أسابيع. يُحدَّد الجدول الزمني في عرض السعر ويعتمد أساساً على سرعة إرسال النصوص والصور والملاحظات.",
      },
    },
  },
  {
    sortOrder: 3,
    translations: {
      en: {
        question: "What features can my website include?",
        answer:
          "Contact forms saved in a database, WhatsApp buttons, photo galleries, digital menus, product catalogues, cart and checkout, reservation forms, an admin dashboard, multilingual versions and blog or news sections. Tell me the goal and I propose the features that serve it.",
      },
      fr: {
        question: "Quelles fonctionnalités mon site peut-il inclure ?",
        answer:
          "Formulaires enregistrés en base de données, boutons WhatsApp, galeries photos, menus digitaux, catalogues produits, panier et paiement, formulaires de réservation, tableau de bord d'administration, versions multilingues et sections d'actualités. Dites-moi votre objectif et je propose les fonctionnalités utiles.",
      },
      ar: {
        question: "ما الميزات التي يمكن أن يشملها موقعي؟",
        answer:
          "نماذج تواصل محفوظة في قاعدة بيانات، أزرار واتساب، معارض صور، قوائم رقمية، كتالوج منتجات، سلة ودفع، نماذج حجز، لوحة تحكم، نسخ متعددة اللغات، وأقسام أخبار أو مقالات. أخبريني بالهدف وأقترح الميزات المناسبة.",
      },
    },
  },
  {
    sortOrder: 4,
    translations: {
      en: {
        question: "How many revisions are included?",
        answer:
          "Every package includes a defined number of revision rounds (two for Basic, three for Standard, unlimited during the Premium project). A revision covers adjustments to the agreed scope; brand-new features are quoted separately.",
      },
      fr: {
        question: "Combien de révisions sont incluses ?",
        answer:
          "Chaque formule comprend un nombre défini de séries de révisions (deux pour Basique, trois pour Standard, illimitées pendant le projet Premium). Une révision couvre les ajustements du périmètre convenu ; les nouvelles fonctionnalités sont chiffrées à part.",
      },
      ar: {
        question: "كم عدد التعديلات المشمولة؟",
        answer:
          "كل باقة تتضمن عدداً محدداً من جولات التعديل (جولتان للباقة الأساسية، ثلاث للمتقدّمة، وغير محدودة خلال مشروع المتميّزة). التعديل يغطي التغييرات داخل نطاق العمل المتفق عليه؛ والميزات الجديدة تُسعَّر بشكل منفصل.",
      },
    },
  },
  {
    sortOrder: 5,
    translations: {
      en: {
        question: "Can I manage an online store myself?",
        answer:
          "Yes. E-commerce projects include an admin dashboard where you add products, update prices and stock, follow orders and change photos. I also give a short training session so you are autonomous from the launch day.",
      },
      fr: {
        question: "Puis-je gérer ma boutique moi-même ?",
        answer:
          "Oui. Les projets e-commerce incluent un tableau de bord où vous ajoutez des produits, modifiez prix et stocks, suivez les commandes et changez les photos. Une courte session de formation est également prévue pour être autonome dès le lancement.",
      },
      ar: {
        question: "هل أستطيع إدارة المتجر بنفسي؟",
        answer:
          "نعم. مشاريع التجارة الإلكترونية تتضمن لوحة تحكم تضيفين فيها المنتجات، وتحدّثين الأسعار والمخزون، وتتابعين الطلبات، وتغيّرين الصور. وأقدّم أيضاً جلسة تدريب قصيرة لتكوني مستقلة من يوم الإطلاق.",
      },
    },
  },
  {
    sortOrder: 6,
    translations: {
      en: {
        question: "Do you work with international clients?",
        answer:
          "Yes. I am based in Temara, Morocco and work remotely with clients anywhere. Communication happens by WhatsApp or email, and the website can be delivered in English, French or Arabic with full RTL support.",
      },
      fr: {
        question: "Travaillez-vous avec des clients internationaux ?",
        answer:
          "Oui. Je suis basée à Temara, au Maroc, et je travaille à distance avec des clients partout. Les échanges se font par WhatsApp ou e-mail, et le site peut être livré en anglais, français ou arabe avec support RTL complet.",
      },
      ar: {
        question: "هل تعملين مع عملاء من الخارج؟",
        answer:
          "نعم. مقرّي في تمارة بالمغرب وأعمل عن بُعد مع عملاء من أي مكان. التواصل يكون عبر واتساب أو البريد الإلكتروني، ويمكن تسليم الموقع بالإنجليزية أو الفرنسية أو العربية مع دعم كامل للكتابة من اليمين إلى اليسار.",
      },
    },
  },
  {
    sortOrder: 7,
    translations: {
      en: {
        question: "Do you provide maintenance after the launch?",
        answer:
          "Yes. A monthly maintenance plan covers updates, backups, monitoring, small content edits and priority support. You can also request one-off interventions whenever you need them.",
      },
      fr: {
        question: "Proposez-vous une maintenance après la mise en ligne ?",
        answer:
          "Oui. Une formule mensuelle de maintenance couvre les mises à jour, les sauvegardes, la supervision, les petites modifications de contenu et un support prioritaire. Vous pouvez aussi demander des interventions ponctuelles.",
      },
      ar: {
        question: "هل توفّرين صيانة بعد الإطلاق؟",
        answer:
          "نعم. خطة الصيانة الشهرية تشمل التحديثات، النسخ الاحتياطية، المراقبة، التعديلات الصغيرة على المحتوى، ودعماً ذا أولوية. ويمكنك أيضاً طلب تدخلات عند الحاجة فقط.",
      },
    },
  },
  {
    sortOrder: 8,
    translations: {
      en: {
        question: "Who owns the website and the code?",
        answer:
          "You do. Once the project is paid, the design, the code and the content belong to you, and you receive access to the hosting, the domain and the repository.",
      },
      fr: {
        question: "À qui appartient le site et le code ?",
        answer:
          "À vous. Une fois le projet payé, le design, le code et les contenus vous appartiennent, et vous recevez les accès à l'hébergement, au domaine et au dépôt du code.",
      },
      ar: {
        question: "لمن يعود ملكية الموقع والكود؟",
        answer:
          "لك أنت. بعد سداد قيمة المشروع، يصبح التصميم والكود والمحتوى ملكك، وتحصلين على بيانات النفاذ إلى الاستضافة والنطاق ومستودع الكود.",
      },
    },
  },
  {
    sortOrder: 9,
    translations: {
      en: {
        question: "How do payments work?",
        answer:
          "Projects start with a deposit and the balance is paid at delivery, agreed in advance in the quote. Bank transfer and cash are accepted for Moroccan clients; international clients receive an invoice with the payment details that suit them.",
      },
      fr: {
        question: "Comment se passent les paiements ?",
        answer:
          "Les projets démarrent avec un acompte, le solde est réglé à la livraison, le tout précisé dans le devis. Virement bancaire et espèces sont acceptés pour les clients marocains ; les clients internationaux reçoivent une facture avec les modalités qui leur conviennent.",
      },
      ar: {
        question: "كيف تتم عمليات الدفع؟",
        answer:
          "يبدأ المشروع بدفعة مقدّمة ويُسدَّد الباقي عند التسليم، مع تحديد ذلك مسبقاً في عرض السعر. أقبل التحويل البنكي والنقد للعملاء المغاربة، ويتسلّم العملاء الدوليون فاتورة بوسيلة الدفع المناسبة لهم.",
      },
    },
  },
];

export const seedSkills: {
  category: string;
  name: string;
  level: number;
  sortOrder: number;
}[] = [
  { category: "frontend", name: "HTML", level: 92, sortOrder: 1 },
  { category: "frontend", name: "CSS", level: 88, sortOrder: 2 },
  { category: "frontend", name: "JavaScript", level: 85, sortOrder: 3 },
  { category: "frontend", name: "TypeScript", level: 78, sortOrder: 4 },
  { category: "frontend", name: "React", level: 84, sortOrder: 5 },
  { category: "frontend", name: "Next.js", level: 82, sortOrder: 6 },
  { category: "frontend", name: "Tailwind CSS", level: 88, sortOrder: 7 },
  { category: "backend", name: "Node.js", level: 72, sortOrder: 8 },
  { category: "backend", name: "Backend Development", level: 70, sortOrder: 9 },
  { category: "backend", name: "Database Integration", level: 72, sortOrder: 10 },
  { category: "tools", name: "Git", level: 82, sortOrder: 11 },
  { category: "tools", name: "GitHub", level: 82, sortOrder: 12 },
  { category: "tools", name: "Vercel", level: 78, sortOrder: 13 },
  { category: "design", name: "UI/UX Design", level: 76, sortOrder: 14 },
  { category: "design", name: "Responsive Web Design", level: 90, sortOrder: 15 },
];
