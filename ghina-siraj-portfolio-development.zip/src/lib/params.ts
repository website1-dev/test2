import { notFound } from "next/navigation";
import { isLocale, type Locale } from "@/lib/i18n/config";

/** Validates a dynamic `[locale]` segment, rendering 404 for unknown locales. */
export function toLocale(value: string): Locale {
  if (!isLocale(value)) notFound();
  return value;
}
