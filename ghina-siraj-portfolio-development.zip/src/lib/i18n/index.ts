import { ar } from "./ar";
import { en, type Dictionary } from "./en";
import { fr } from "./fr";
import { defaultLocale, isLocale, resolveLocale, type Locale } from "./config";

export * from "./config";
export type { Dictionary };

export const dictionaries: Record<Locale, Dictionary> = { en, fr, ar };

export function getDictionary(locale: string | undefined | null): Dictionary {
  return dictionaries[resolveLocale(locale)];
}

export function getLocaleFromParam(value: string | undefined): Locale {
  return isLocale(value) ? value : defaultLocale;
}

/** Resolves a dotted path inside a dictionary, returning undefined when missing. */
export function lookup(dict: Dictionary, path: string): unknown {
  let node: unknown = dict;
  for (const segment of path.split(".")) {
    if (node && typeof node === "object" && segment in (node as Record<string, unknown>)) {
      node = (node as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return node;
}

/** Admin-editable content overrides keyed by dictionary path. */
export type ContentOverrides = Record<string, string>;

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

/**
 * Returns a dictionary where every path present in `overrides` replaces the
 * bundled translation. Unknown paths are ignored so the site never breaks.
 */
export function applyContent(dict: Dictionary, overrides: ContentOverrides = {}): Dictionary {
  const merged = clone(dict) as unknown as Record<string, unknown>;
  for (const [path, value] of Object.entries(overrides)) {
    if (typeof value !== "string" || value.trim() === "") continue;
    const segments = path.split(".");
    let node: Record<string, unknown> | undefined = merged;
    for (let i = 0; i < segments.length - 1; i += 1) {
      const next = node?.[segments[i]];
      if (next && typeof next === "object" && !Array.isArray(next)) {
        node = next as Record<string, unknown>;
      } else {
        node = undefined;
        break;
      }
    }
    if (!node) continue;
    const last = segments[segments.length - 1];
    const current = node[last];
    if (typeof current === "string") node[last] = value;
  }
  return merged as unknown as Dictionary;
}

/** Picks the row for `locale`, falling back to English then to the first row. */
export function pickLocalized<T extends { locale: string }>(rows: T[], locale: Locale): T | undefined {
  return (
    rows.find((row) => row.locale === locale) ??
    rows.find((row) => row.locale === defaultLocale) ??
    rows[0]
  );
}
