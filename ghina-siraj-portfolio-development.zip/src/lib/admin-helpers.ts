import { eq } from "drizzle-orm";
import { db } from "@/db";
import { serviceTranslations, services } from "@/db/schema";

/** Maps service slugs to their English titles for the admin inbox. */
export async function getServiceTitle(): Promise<Record<string, string>> {
  try {
    const rows = await db
      .select({
        slug: services.slug,
        title: serviceTranslations.title,
        locale: serviceTranslations.locale,
      })
      .from(services)
      .leftJoin(serviceTranslations, eq(serviceTranslations.serviceId, services.id));

    const map: Record<string, string> = {};
    for (const row of rows) {
      if (!row.slug) continue;
      if (row.locale === "en" || !(row.slug in map)) {
        map[row.slug] = row.title ?? row.slug;
      }
    }
    return map;
  } catch {
    return {};
  }
}
