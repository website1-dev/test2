import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  adminUsers,
  faqTranslations,
  faqs,
  pricingPackages,
  pricingTranslations,
  projectTranslations,
  projects,
  serviceTranslations,
  services,
  siteSettings,
  skills,
} from "@/db/schema";
import { seedFaqs, seedPackages, seedProject, seedServices, seedSkills } from "@/db/seed-data";
import { hashPassword } from "@/lib/auth";

const SEED_VERSION = "2026.02.1";

let seedPromise: Promise<void> | null = null;

/**
 * Idempotent bootstrap: creates the admin account from environment variables
 * and inserts the initial multilingual content when the database is empty.
 * Safe to call on every request — it short-circuits once seeded.
 */
export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      console.error("[seed] failed:", error);
    });
  }
  return seedPromise;
}

async function runSeed(): Promise<void> {
  const [marker] = await db
    .select()
    .from(siteSettings)
    .where(sql`${siteSettings.key} = 'seedVersion'`)
    .limit(1);
  if (marker?.value === SEED_VERSION) return;

  await createAdminFromEnv();
  await seedContent();
  await db
    .insert(siteSettings)
    .values({ key: "seedVersion", value: SEED_VERSION })
    .onConflictDoUpdate({ target: siteSettings.key, set: { value: SEED_VERSION } });
}

async function createAdminFromEnv(): Promise<void> {
  const email = (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD ?? "";
  if (!email || !password) {
    console.warn(
      "[seed] ADMIN_EMAIL / ADMIN_PASSWORD are not set — no admin account was created. See README.md",
    );
    return;
  }
  const existing = await db
    .select({ id: adminUsers.id })
    .from(adminUsers)
    .where(sql`${adminUsers.email} = ${email}`)
    .limit(1);
  if (existing[0]) return;
  await db.insert(adminUsers).values({
    email,
    name: process.env.ADMIN_NAME ?? "Ghina Siraj",
    passwordHash: await hashPassword(password),
    role: "owner",
  });
}

async function seedContent(): Promise<void> {
  /* services */
  for (const service of seedServices) {
    const inserted = await db
      .insert(services)
      .values({
        slug: service.slug,
        icon: service.icon,
        startingPrice: service.startingPrice,
        currency: "MAD",
        sortOrder: service.sortOrder,
        visible: true,
      })
      .onConflictDoNothing({ target: services.slug })
      .returning({ id: services.id });
    const serviceId = inserted[0]?.id;
    if (!serviceId) continue;
    await db
      .insert(serviceTranslations)
      .values(
        (["en", "fr", "ar"] as const).map((locale) => ({
          serviceId,
          locale,
          title: service.translations[locale].title ?? service.slug,
          summary: service.translations[locale].summary ?? "",
          description: service.translations[locale].description ?? "",
          features: service.translations[locale].features ?? [],
          benefits: service.translations[locale].benefits ?? [],
          deliveryTime: service.translations[locale].deliveryTime ?? "",
        })),
      )
      .onConflictDoNothing();
  }

  /* projects */
  const projectInserted = await db
    .insert(projects)
    .values({
      slug: seedProject.slug,
      category: seedProject.category,
      technologies: seedProject.technologies,
      externalUrl: seedProject.externalUrl || null,
      repositoryUrl: seedProject.repositoryUrl || null,
      coverImageUrl: seedProject.coverImageUrl,
      featured: seedProject.featured,
      published: seedProject.published,
      sortOrder: seedProject.sortOrder,
    })
    .onConflictDoNothing({ target: projects.slug })
    .returning({ id: projects.id });
  const projectId = projectInserted[0]?.id;
  if (projectId) {
    await db
      .insert(projectTranslations)
      .values(
        (["en", "fr", "ar"] as const).map((locale) => ({
          projectId,
          locale,
          title: seedProject.translations[locale].title ?? seedProject.slug,
          summary: seedProject.translations[locale].summary ?? "",
          description: seedProject.translations[locale].description ?? "",
          features: seedProject.translations[locale].features ?? [],
        })),
      )
      .onConflictDoNothing();
  }

  /* pricing */
  for (const pack of seedPackages) {
    const inserted = await db
      .insert(pricingPackages)
      .values({
        planKey: pack.planKey,
        price: pack.price,
        currency: "MAD",
        popular: pack.popular,
        enabled: true,
        sortOrder: pack.sortOrder,
      })
      .onConflictDoNothing({ target: pricingPackages.planKey })
      .returning({ id: pricingPackages.id });
    const packageId = inserted[0]?.id;
    if (!packageId) continue;
    await db
      .insert(pricingTranslations)
      .values(
        (["en", "fr", "ar"] as const).map((locale) => ({
          packageId,
          locale,
          name: pack.translations[locale].name ?? pack.planKey,
          description: pack.translations[locale].description ?? "",
          features: pack.translations[locale].features ?? [],
          deliveryTime: pack.translations[locale].deliveryTime ?? "",
          revisions: pack.translations[locale].revisions ?? "",
        })),
      )
      .onConflictDoNothing();
  }

  /* faqs */
  const [existingFaq] = await db.select({ id: faqs.id }).from(faqs).limit(1);
  if (!existingFaq) {
    for (const faq of seedFaqs) {
      const inserted = await db
        .insert(faqs)
        .values({ sortOrder: faq.sortOrder, published: true })
        .returning({ id: faqs.id });
      const faqId = inserted[0]?.id;
      if (!faqId) continue;
      await db
        .insert(faqTranslations)
        .values(
          (["en", "fr", "ar"] as const).map((locale) => ({
            faqId,
            locale,
            question: faq.translations[locale].question ?? "",
            answer: faq.translations[locale].answer ?? "",
          })),
        )
        .onConflictDoNothing();
    }
  }

  /* skills */
  const [existingSkill] = await db.select({ id: skills.id }).from(skills).limit(1);
  if (!existingSkill) {
    await db.insert(skills).values(seedSkills.map((skill) => ({ ...skill, visible: true })));
  }
}
