import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { sql } from "drizzle-orm";

export const SETTING_KEYS = [
  "contactEmail",
  "whatsappNumber",
  "locationLabel",
  "availabilityLabel",
  "avatarUrl",
  "ogImageUrl",
  "siteUrl",
  "seoKeywords",
  "socialGithub",
  "socialLinkedin",
  "socialInstagram",
  "socialX",
  "socialBehance",
  "featurePricing",
  "featureFaq",
  "featureWhatsAppFloat",
  "analyticsId",
] as const;

export type SettingKey = (typeof SETTING_KEYS)[number];

export const defaultSettings: Record<SettingKey, string> = {
  contactEmail: "ghinasiraj911@gmail.com",
  whatsappNumber: "+212723657384",
  locationLabel: "Temara, Morocco",
  availabilityLabel: "Available for new projects",
  avatarUrl: "/images/avatar.png",
  ogImageUrl: "/images/og.png",
  siteUrl: "https://ghinasiraj.com",
  seoKeywords:
    "Ghina Siraj, web developer Morocco, e-commerce developer Temara, Next.js developer, restaurant website, fashion store website",
  socialGithub: "https://github.com/",
  socialLinkedin: "https://www.linkedin.com/",
  socialInstagram: "https://www.instagram.com/",
  socialX: "",
  socialBehance: "",
  featurePricing: "1",
  featureFaq: "1",
  featureWhatsAppFloat: "1",
  analyticsId: "",
};

export type SiteSettings = Record<string, string>;

/** Returns settings merged over safe defaults (never throws). */
export async function getSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(siteSettings);
    const merged: SiteSettings = { ...defaultSettings };
    for (const row of rows) {
      if (row.value !== "") merged[row.key] = row.value;
    }
    return merged;
  } catch {
    return { ...defaultSettings };
  }
}

export async function saveSettings(entries: Record<string, string>): Promise<void> {
  const values = Object.entries(entries).map(([key, value]) => ({
    key,
    value: value ?? "",
    updatedAt: new Date(),
  }));
  if (values.length === 0) return;
  await db
    .insert(siteSettings)
    .values(values)
    .onConflictDoUpdate({
      target: siteSettings.key,
      set: { value: sql`excluded.value`, updatedAt: sql`excluded.updated_at` },
    });
}

/** Builds a wa.me link with a prefilled professional message. */
export function whatsappLink(number: string, message?: string): string {
  const digits = (number || "").replace(/[^\d]/g, "");
  const text = message ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${digits}${text}`;
}

export function mailtoLink(email: string, subject?: string): string {
  const query = subject ? `?subject=${encodeURIComponent(subject)}` : "";
  return `mailto:${email}${query}`;
}

export function formatPrice(amount: number, currency = "MAD"): string {
  return `${new Intl.NumberFormat("en-US").format(amount)} ${currency}`;
}
