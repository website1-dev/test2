import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  contactMessages,
  faqTranslations,
  faqs,
  pricingPackages,
  pricingTranslations,
  projectImages,
  projectTranslations,
  projects,
  serviceTranslations,
  services,
  skills,
} from "@/db/schema";
import { pickLocalized } from "@/lib/i18n";
import { defaultLocale, type Locale } from "@/lib/i18n/config";
import { getSettings, type SiteSettings } from "@/lib/settings";
import { getContentOverrides } from "@/lib/content";
import { applyContent, getDictionary, type Dictionary } from "@/lib/i18n";

export type LocaleData = {
  locale: Locale;
  dict: Dictionary;
  settings: SiteSettings;
};

/** Loads dictionary + settings + admin overrides for a locale (never throws). */
export async function loadLocaleData(locale: Locale): Promise<LocaleData> {
  const [settings, overrides] = await Promise.all([
    getSettings(),
    getContentOverrides(locale),
  ]);
  const dict = applyContent(getDictionary(locale), overrides);
  return { locale, dict, settings };
}

/* -------------------------------- services -------------------------------- */

export type ServiceView = {
  id: number;
  slug: string;
  icon: string;
  startingPrice: number;
  currency: string;
  visible: boolean;
  sortOrder: number;
  title: string;
  summary: string;
  description: string;
  features: string[];
  benefits: string[];
  deliveryTime: string;
};

type ServiceRow = typeof services.$inferSelect;

function mapService(
  service: ServiceRow,
  translations: (typeof serviceTranslations.$inferSelect)[],
  locale: Locale,
): ServiceView {
  const row = pickLocalized(translations, locale);
  return {
    id: service.id,
    slug: service.slug,
    icon: service.icon,
    startingPrice: service.startingPrice,
    currency: service.currency,
    visible: service.visible,
    sortOrder: service.sortOrder,
    title: row?.title ?? service.slug,
    summary: row?.summary ?? "",
    description: row?.description ?? "",
    features: row?.features ?? [],
    benefits: row?.benefits ?? [],
    deliveryTime: row?.deliveryTime ?? "",
  };
}

export async function getServices(
  locale: Locale,
  options: { includeHidden?: boolean } = {},
): Promise<ServiceView[]> {
  try {
    const rows = await db
      .select()
      .from(services)
      .where(options.includeHidden ? sql`true` : eq(services.visible, true))
      .orderBy(asc(services.sortOrder), asc(services.id));
    if (rows.length === 0) return [];
    const translations = await db.select().from(serviceTranslations).where(
      inArray(
        serviceTranslations.serviceId,
        rows.map((row) => row.id),
      ),
    );
    return rows.map((row) =>
      mapService(
        row,
        translations.filter((t) => t.serviceId === row.id),
        locale,
      ),
    );
  } catch {
    return [];
  }
}

export async function getServiceBySlug(slug: string, locale: Locale): Promise<ServiceView | null> {
  try {
    const rows = await db.select().from(services).where(eq(services.slug, slug)).limit(1);
    const service = rows[0];
    if (!service) return null;
    const translations = await db
      .select()
      .from(serviceTranslations)
      .where(eq(serviceTranslations.serviceId, service.id));
    return mapService(service, translations, locale);
  } catch {
    return null;
  }
}

/* -------------------------------- projects -------------------------------- */

export type ProjectView = {
  id: number;
  slug: string;
  category: string;
  technologies: string[];
  externalUrl: string | null;
  repositoryUrl: string | null;
  coverImageUrl: string | null;
  featured: boolean;
  published: boolean;
  sortOrder: number;
  title: string;
  summary: string;
  description: string;
  features: string[];
  images: { id: number; url: string; alt: string }[];
};

type ProjectRow = typeof projects.$inferSelect;

function mapProject(
  project: ProjectRow,
  translations: (typeof projectTranslations.$inferSelect)[],
  images: (typeof projectImages.$inferSelect)[],
  locale: Locale,
): ProjectView {
  const row = pickLocalized(translations, locale);
  return {
    id: project.id,
    slug: project.slug,
    category: project.category,
    technologies: project.technologies ?? [],
    externalUrl: project.externalUrl,
    repositoryUrl: project.repositoryUrl,
    coverImageUrl: project.coverImageUrl,
    featured: project.featured,
    published: project.published,
    sortOrder: project.sortOrder,
    title: row?.title ?? project.slug,
    summary: row?.summary ?? "",
    description: row?.description ?? "",
    features: row?.features ?? [],
    images: images
      .filter((image) => image.projectId === project.id)
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((image) => ({ id: image.id, url: image.url, alt: image.alt })),
  };
}

async function decorateProjects(rows: ProjectRow[], locale: Locale): Promise<ProjectView[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((row) => row.id);
  const [translations, images] = await Promise.all([
    db.select().from(projectTranslations).where(inArray(projectTranslations.projectId, ids)),
    db.select().from(projectImages).where(inArray(projectImages.projectId, ids)),
  ]);
  return rows.map((row) =>
    mapProject(
      row,
      translations.filter((t) => t.projectId === row.id),
      images,
      locale,
    ),
  );
}

export async function getProjects(
  locale: Locale,
  options: { includeHidden?: boolean; featuredOnly?: boolean; limit?: number } = {},
): Promise<ProjectView[]> {
  try {
    const filters = [
      options.includeHidden ? sql`true` : eq(projects.published, true),
      options.featuredOnly ? eq(projects.featured, true) : sql`true`,
    ];
    const query = db
      .select()
      .from(projects)
      .where(and(...filters))
      .orderBy(asc(projects.sortOrder), desc(projects.id));
    const rows = options.limit ? await query.limit(options.limit) : await query;
    return await decorateProjects(rows, locale);
  } catch {
    return [];
  }
}

export async function getProjectBySlug(slug: string, locale: Locale): Promise<ProjectView | null> {
  try {
    const rows = await db.select().from(projects).where(eq(projects.slug, slug)).limit(1);
    if (!rows[0]) return null;
    const [view] = await decorateProjects(rows, locale);
    return view ?? null;
  } catch {
    return null;
  }
}

/* --------------------------------- pricing -------------------------------- */

export type PackageView = {
  id: number;
  planKey: string;
  price: number;
  currency: string;
  popular: boolean;
  enabled: boolean;
  name: string;
  description: string;
  features: string[];
  deliveryTime: string;
  revisions: string;
};

export async function getPackages(
  locale: Locale,
  options: { includeDisabled?: boolean } = {},
): Promise<PackageView[]> {
  try {
    const rows = await db
      .select()
      .from(pricingPackages)
      .where(options.includeDisabled ? sql`true` : eq(pricingPackages.enabled, true))
      .orderBy(asc(pricingPackages.sortOrder), asc(pricingPackages.id));
    if (rows.length === 0) return [];
    const translations = await db.select().from(pricingTranslations).where(
      inArray(
        pricingTranslations.packageId,
        rows.map((row) => row.id),
      ),
    );
    return rows.map((row) => {
      const text = pickLocalized(
        translations.filter((t) => t.packageId === row.id),
        locale,
      );
      return {
        id: row.id,
        planKey: row.planKey,
        price: row.price,
        currency: row.currency,
        popular: row.popular,
        enabled: row.enabled,
        name: text?.name ?? row.planKey,
        description: text?.description ?? "",
        features: text?.features ?? [],
        deliveryTime: text?.deliveryTime ?? "",
        revisions: text?.revisions ?? "",
      };
    });
  } catch {
    return [];
  }
}

export async function getAllPackagesWithTranslations() {
  try {
    const packages = await db
      .select()
      .from(pricingPackages)
      .orderBy(asc(pricingPackages.sortOrder), asc(pricingPackages.id));
    const translations = await db.select().from(pricingTranslations);
    return packages.map((row) => ({
      ...row,
      translations: translations.filter((t) => t.packageId === row.id),
    }));
  } catch {
    return [];
  }
}

/* ----------------------------------- faq ---------------------------------- */

export type FaqView = { id: number; question: string; answer: string };

export async function getFaqs(
  locale: Locale,
  options: { includeHidden?: boolean } = {},
): Promise<FaqView[]> {
  try {
    const rows = await db
      .select()
      .from(faqs)
      .where(options.includeHidden ? sql`true` : eq(faqs.published, true))
      .orderBy(asc(faqs.sortOrder), asc(faqs.id));
    if (rows.length === 0) return [];
    const translations = await db.select().from(faqTranslations).where(
      inArray(
        faqTranslations.faqId,
        rows.map((row) => row.id),
      ),
    );
    return rows.map((row) => {
      const text = pickLocalized(
        translations.filter((t) => t.faqId === row.id),
        locale,
      );
      return {
        id: row.id,
        question: text?.question ?? "",
        answer: text?.answer ?? "",
      };
    });
  } catch {
    return [];
  }
}

/* ---------------------------------- skills --------------------------------- */

export type SkillView = {
  id: number;
  category: string;
  name: string;
  level: number;
  visible: boolean;
  sortOrder: number;
};

export async function getSkills(options: { includeHidden?: boolean } = {}): Promise<SkillView[]> {
  try {
    const rows = await db
      .select()
      .from(skills)
      .where(options.includeHidden ? sql`true` : eq(skills.visible, true))
      .orderBy(asc(skills.sortOrder), asc(skills.id));
    return rows.map((row) => ({
      id: row.id,
      category: row.category,
      name: row.name,
      level: row.level,
      visible: row.visible,
      sortOrder: row.sortOrder,
    }));
  } catch {
    return [];
  }
}

/* --------------------------------- messages -------------------------------- */

export async function getContactMessages(limit = 100) {
  try {
    return await db
      .select()
      .from(contactMessages)
      .orderBy(desc(contactMessages.submittedAt))
      .limit(limit);
  } catch {
    return [];
  }
}

export async function getDashboardStats() {
  try {
    const [projectCount] = await db.select({ count: sql<number>`count(*)::int` }).from(projects);
    const [serviceCount] = await db.select({ count: sql<number>`count(*)::int` }).from(services);
    const [messageCount] = await db.select({ count: sql<number>`count(*)::int` }).from(contactMessages);
    const [unreadCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(contactMessages)
      .where(eq(contactMessages.status, "new"));
    const recent = await db
      .select()
      .from(contactMessages)
      .orderBy(desc(contactMessages.submittedAt))
      .limit(5);
    return {
      projects: projectCount?.count ?? 0,
      services: serviceCount?.count ?? 0,
      messages: messageCount?.count ?? 0,
      unread: unreadCount?.count ?? 0,
      recent,
    };
  } catch {
    return { projects: 0, services: 0, messages: 0, unread: 0, recent: [] };
  }
}

export const CATEGORY_KEYS = [
  "website",
  "ecommerce",
  "restaurant",
  "fashion",
  "landing",
  "redesign",
  "dashboard",
] as const;

export function categoryLabel(dict: Dictionary, key: string): string {
  const categories = dict.projects.categories as Record<string, string>;
  return categories[key] ?? key;
}

export { defaultLocale };
