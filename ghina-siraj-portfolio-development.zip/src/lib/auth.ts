import { createHmac, randomBytes, scrypt as nodeScrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt } from "drizzle-orm";
import { cache } from "react";
import { db } from "@/db";
import { adminSessions, adminUsers } from "@/db/schema";
import { SESSION_COOKIE } from "@/lib/i18n/config";

const scrypt = promisify(nodeScrypt) as (
  password: string,
  salt: string,
  keylen: number,
) => Promise<Buffer>;

const SESSION_TTL_DAYS = 7;

function appSecret(): string {
  return (
    process.env.AUTH_SECRET ??
    process.env.SESSION_SECRET ??
    // Local/dev fallback only. Production deployments must set AUTH_SECRET.
    "ghina-siraj-portfolio-development-secret"
  );
}

/* ------------------------------- passwords -------------------------------- */

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, salt, hash] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

/* -------------------------------- sessions -------------------------------- */

function sign(sessionId: string): string {
  return createHmac("sha256", appSecret()).update(sessionId).digest("base64url");
}

export function serializeSessionToken(sessionId: string): string {
  return `${sessionId}.${sign(sessionId)}`;
}

/** Verifies the HMAC envelope of a session cookie without touching the database. */
export function isValidTokenShape(token: string | undefined): string | null {
  if (!token) return null;
  const [id, signature] = token.split(".");
  if (!id || !signature) return null;
  const expected = sign(id);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  return timingSafeEqual(a, b) ? id : null;
}

export async function createSession(userId: number, userAgent?: string | null): Promise<void> {
  const sessionId = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(adminSessions).values({
    id: sessionId,
    userId,
    userAgent: userAgent?.slice(0, 300) ?? null,
    expiresAt,
  });
  const store = await cookies();
  store.set(SESSION_COOKIE, serializeSessionToken(sessionId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export type AdminIdentity = {
  id: number;
  email: string;
  name: string;
  role: string;
};

/** Resolves the signed-in admin for the current request (memoised per request). */
export const getCurrentAdmin = cache(async (): Promise<AdminIdentity | null> => {
  const store = await cookies();
  const sessionId = isValidTokenShape(store.get(SESSION_COOKIE)?.value);
  if (!sessionId) return null;
  try {
    const rows = await db
      .select({
        id: adminUsers.id,
        email: adminUsers.email,
        name: adminUsers.name,
        role: adminUsers.role,
      })
      .from(adminSessions)
      .innerJoin(adminUsers, eq(adminUsers.id, adminSessions.userId))
      .where(and(eq(adminSessions.id, sessionId), gt(adminSessions.expiresAt, new Date())))
      .limit(1);
    const user = rows[0];
    if (!user) return null;
    if (user.role !== "admin" && user.role !== "owner") return null;
    return user;
  } catch {
    return null;
  }
});

/**
 * Page-level guard. Next.js renders layouts and pages in parallel, so every
 * admin page must verify the session itself (not only the layout / proxy).
 */
export async function requireAdminPage(): Promise<AdminIdentity> {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin");
  return admin as AdminIdentity;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const sessionId = isValidTokenShape(store.get(SESSION_COOKIE)?.value);
  if (sessionId) {
    await db.delete(adminSessions).where(eq(adminSessions.id, sessionId));
  }
  store.delete(SESSION_COOKIE);
}

export async function authenticate(
  email: string,
  password: string,
): Promise<{ ok: true; user: AdminIdentity } | { ok: false; error: string }> {
  const normalized = email.trim().toLowerCase();
  const rows = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.email, normalized))
    .limit(1);
  const user = rows[0];
  if (!user) return { ok: false, error: "INVALID_CREDENTIALS" };
  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return { ok: false, error: "INVALID_CREDENTIALS" };
  await db.update(adminUsers).set({ lastLoginAt: new Date() }).where(eq(adminUsers.id, user.id));
  return {
    ok: true,
    user: { id: user.id, email: user.email, name: user.name, role: user.role },
  };
}
