import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { contentBlocks } from "@/db/schema";
import { getDictionary, type ContentOverrides, type Locale } from "@/lib/i18n";

export type ContentFieldType = "text" | "textarea";

export type ContentField = {
  key: string;
  label: string;
  type: ContentFieldType;
  help?: string;
};

export type ContentGroup = {
  id: string;
  title: string;
  description: string;
  fields: ContentField[];
};

/**
 * Manifest of every editable multilingual content block. Each key maps to a
 * dictionary path used by the public website, so translations always have a
 * complete fallback.
 */
export const CONTENT_GROUPS: ContentGroup[] = [
  {
    id: "hero",
    title: "Homepage — hero section",
    description: "The first screen visitors see on every language version.",
    fields: [
      { key: "home.badge", label: "Badge / status line", type: "text" },
      { key: "home.tagline", label: "Professional tagline", type: "text" },
      { key: "home.intro", label: "Professional introduction", type: "textarea" },
    ],
  },
  {
    id: "home-sections",
    title: "Homepage — sections",
    description: "Section headings for the featured projects, services and call-to-action blocks.",
    fields: [
      { key: "home.servicesTitle", label: "Services section title", type: "text" },
      { key: "home.servicesSubtitle", label: "Services section subtitle", type: "textarea" },
      { key: "home.projectsTitle", label: "Projects section title", type: "text" },
      { key: "home.projectsSubtitle", label: "Projects section subtitle", type: "textarea" },
      { key: "home.ctaTitle", label: "Final call-to-action title", type: "text" },
      { key: "home.ctaText", label: "Final call-to-action text", type: "textarea" },
    ],
  },
  {
    id: "about",
    title: "About page",
    description: "Professional profile, approach and interests.",
    fields: [
      { key: "about.profileTitle", label: "Profile heading", type: "text" },
      { key: "about.profileText", label: "Profile text", type: "textarea" },
      { key: "about.storyTitle", label: "Approach heading", type: "text" },
      { key: "about.storyText", label: "Approach text", type: "textarea" },
      { key: "about.interestsTitle", label: "Interests heading", type: "text" },
      { key: "about.interestsText", label: "Interests text", type: "textarea" },
    ],
  },
  {
    id: "brand",
    title: "Brand & identity",
    description: "Name and professional title shown in the hero, navbar and footer.",
    fields: [
      { key: "home.name", label: "Full name", type: "text" },
      { key: "home.badgeRole", label: "Professional title", type: "text", help: "Shown in the hero badge area." },
      { key: "footer.about", label: "Footer description", type: "textarea" },
    ],
  },
  {
    id: "seo",
    title: "SEO & metadata",
    description: "Per-language meta title and description used across the site.",
    fields: [
      { key: "meta.siteTitle", label: "Meta title", type: "text" },
      { key: "meta.siteDescription", label: "Meta description", type: "textarea" },
    ],
  },
  {
    id: "contact",
    title: "Contact page",
    description: "Introductory copy of the contact page.",
    fields: [
      { key: "contact.title", label: "Contact heading", type: "text" },
      { key: "contact.subtitle", label: "Contact subtitle", type: "textarea" },
    ],
  },
];

export const CONTENT_KEYS = CONTENT_GROUPS.flatMap((group) =>
  group.fields.map((field) => field.key),
);

export async function getContentOverrides(locale: Locale): Promise<ContentOverrides> {
  try {
    const rows = await db
      .select({ key: contentBlocks.key, value: contentBlocks.value })
      .from(contentBlocks)
      .where(eq(contentBlocks.locale, locale));
    const map: ContentOverrides = {};
    for (const row of rows) {
      if (row.value && row.value.trim() !== "") map[row.key] = row.value;
    }
    return map;
  } catch {
    return {};
  }
}

export async function getAllContent(): Promise<Record<string, Record<string, string>>> {
  try {
    const rows = await db.select().from(contentBlocks);
    const result: Record<string, Record<string, string>> = {};
    for (const row of rows) {
      result[row.key] = result[row.key] ?? {};
      if (row.value !== "") result[row.key][row.locale] = row.value;
    }
    return result;
  } catch {
    return {};
  }
}

export async function saveContentEntry(
  key: string,
  locale: Locale,
  value: string,
): Promise<void> {
  const existing = await db
    .select({ id: contentBlocks.id })
    .from(contentBlocks)
    .where(and(eq(contentBlocks.key, key), eq(contentBlocks.locale, locale)))
    .limit(1);

  if (existing[0]) {
    await db
      .update(contentBlocks)
      .set({ value, updatedAt: new Date() })
      .where(eq(contentBlocks.id, existing[0].id));
    return;
  }
  await db.insert(contentBlocks).values({ key, locale, value });
}

/** Default (English dictionary) value shown as a placeholder in the admin editor. */
export function contentDefaultValue(key: string): string {
  const dict = getDictionary("en") as unknown as Record<string, unknown>;
  let node: unknown = dict;
  for (const segment of key.split(".")) {
    if (node && typeof node === "object" && segment in (node as Record<string, unknown>)) {
      node = (node as Record<string, unknown>)[segment];
    } else {
      return "";
    }
  }
  return typeof node === "string" ? node : "";
}
