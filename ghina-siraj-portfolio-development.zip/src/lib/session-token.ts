import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Session cookie envelope: `<sessionId>.<hmac>`.
 * The signature lets the network proxy reject forged cookies without a
 * database round-trip; the database remains the source of truth.
 */
export function sessionSecret(): string {
  return (
    process.env.AUTH_SECRET ??
    process.env.SESSION_SECRET ??
    "ghina-siraj-portfolio-development-secret"
  );
}

export function signSessionId(sessionId: string): string {
  return createHmac("sha256", sessionSecret()).update(sessionId).digest("base64url");
}

export function serializeSessionToken(sessionId: string): string {
  return `${sessionId}.${signSessionId(sessionId)}`;
}

export function readSessionId(token: string | undefined | null): string | null {
  if (!token) return null;
  const [id, signature] = token.split(".");
  if (!id || !signature) return null;
  const expected = Buffer.from(signSessionId(id));
  const provided = Buffer.from(signature);
  if (expected.length !== provided.length) return null;
  return timingSafeEqual(expected, provided) ? id : null;
}
